#include<stdio.h>
#include<string.h>
#include<ctype.h>

#define N 1100

void OperA(char AI[],char User[]);
void OperB(char User[]);
void OperC(char User[]);
void OperD(char User[]);
void OperE(char User[]);

int main(void)
{
    char User[N];
    printf("If you don't want to talk,just input \"I don't want to talk\"\n");
    while(1)
    {
        gets(User);
        char AI[N]={"AI:"};
        OperB(User);
        char *p=User;p++;
        if(!strcmp(p,"I don't want to talk"))
            break;
        OperC(User);
        OperE(User);
        OperD(User);
	    OperA(AI,User);
        puts(AI);
    }
    return 0;
}

void OperA(char AI[],char User[])
{
	strncat(AI,User,strlen(User));
}

void OperB(char User[])
{
	char str[N];
	char *pstr;
	char *p;
	for(pstr=str,p=User;isprint(*p);p++)
	{
		*pstr = ' ';
		pstr++;
		for(;isspace(*p);p++);
		for(;!isspace(*p);pstr++,p++)
		{
			if(ispunct(*p))
            {
				if(*(pstr-1)==' ')
				    pstr--;
                *pstr = *p;
                if(*pstr=='?')
                    *pstr = '!';
			}
			else
			    *pstr = *p;
		}
	}
	pstr++;
	*pstr = '\0';
	strcpy(User,str);
}

void OperC(char User[])
{
	char *p;
	for(p=User;isprint(*p);p++)
	{
		if(isupper(*p)&&*p!='I')
		    *p += 'a'-'A';
	}
}

void OperD(char User[])
{
	char *p;
	p = strstr(User,"can you");
	if(p)
	{
		*p = 'I';p++;
		*p = ' ';p++;
	    *p = 'c';p++;
		*p = 'a';p++;
	    *p = 'n';p++;
		*p = ' ';p++;
		*p = ' ';p++;
	}
	p = strstr(User,"could you");
	if(p)
	{
		*p = 'I';p++;
		*p = ' ';p++;
	    *p = 'c';p++;
		*p = 'o';p++;
        *p = 'u';p++;
	    *p = 'l';p++;
		*p = 'd';p++;
		*p = ' ';p++;
		*p = ' ';p++;
	}
	OperB(User);
}

void OperE(char User[])
{
	char *pstr;
	char str[N];
	strcpy(str,User);
	for(pstr=str;*pstr!='\0';pstr++)
	{
		if(*pstr=='I'&&(isspace(*(pstr-1))||ispunct(*(pstr-1)))&&(isspace(*(pstr+1))||ispunct(*(pstr+1)))) 
		{
			int n = strlen(str);
			*pstr = '\0';
			int i = strlen(str)+1;
			*pstr = 'y';pstr++;
			*pstr = 'o';pstr++;
			*pstr = 'u';pstr++;
			char *p;
			for(p=User;i<=n;pstr++,i++)
			{
				*pstr = *(p+i);
			}
			strcpy(User,str);
		}
		if(!strncmp(pstr,"me",2)&&(isspace(*(pstr-1))||ispunct(*(pstr-1)))&&(isspace(*(pstr+2))||ispunct(*(pstr+2))))
		{
			int n = strlen(str);
			*pstr = '\0';
			int i = strlen(str)+2;
			*pstr = 'y';pstr++;
			*pstr = 'o';pstr++;
			*pstr = 'u';pstr++;
			char *p;
			for(p=User;i<=n;pstr++,i++)
			{
				*pstr = *(p+i);
			}
			strcpy(User,str);
		}
	}
}
