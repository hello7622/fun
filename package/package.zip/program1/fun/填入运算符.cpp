#include<stdio.h>
#include<stdlib.h>

char OP(int op)
{
	switch(op)
	{
		case 0:                               // + �� 
			return '+';
			break;
		case 1:                               // - �� 
			return '-';
			break;
		case 2:                               // ���� 
			return '*';
			break;
		case 3:                               // �³� 
			return '/';
			break;
		default:
			printf("Currently only addition,'+','-','*','/' are supported!\n");
			return '?';
			break;
	}
}

double Oper(double data1,int op,double data2)
{
	if(EOF==data2||EOF==data1)
	{
		return EOF;
	}
	switch(op)
	{
		case 0:                                      // +  �� 
			return data1+data2;
			break;
		case 1:                                      // -  �� 
			return data1-data2;
			break;
		case 2:                                      // �� �� 
			return data1*data2;
			break;
		case 3:                                      // �� �� 
			if(0==data2)                             // ����Ϊ0 
			{
				printf("The divisor is zero!\n");
				return EOF;
			}
			return data1/data2;
			break;
		default:
			printf("Currently only addition,'+','-','*','/' are supported!\n");
			return EOF;
			break;
	}
}


//5 5 5 5 5=5
int main(void)
{
	int op1,op2,op3,op4,count = 0;
	double result;
    
	//ֻ�мӼ�
	for(op1=0;op1<2;op1++)
	{
		for(op2=0;op2<2;op2++)
		{
			for(op3=0;op3<2;op3++)
			{
				for(op4=0;op4<2;op4++)
				{
					result = Oper(Oper(Oper(Oper(5,op4,5),op3,5),op2,5),op1,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	} 
	
	//ֻ�г˳�
    for(op1=2;op1<4;op1++)
	{
		for(op2=2;op2<4;op2++)
		{
			for(op3=2;op3<4;op3++)
			{
				for(op4=2;op4<4;op4++)
				{
					result = Oper(Oper(Oper(Oper(5,op4,5),op3,5),op2,5),op1,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	} 
	
	//һ���˳�
	//op1
    for(op1=2;op1<4;op1++)
	{
		for(op2=0;op2<2;op2++)
		{
			for(op3=0;op3<2;op3++)
			{
				for(op4=0;op4<2;op4++)
				{
					result = Oper(Oper(Oper(Oper(5,op1,5),op2,5),op3,5),op4,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	} 
	//op2
    for(op1=0;op1<2;op1++)
	{
		for(op2=2;op2<4;op2++)
		{
			for(op3=0;op3<2;op3++)
			{
				for(op4=0;op4<2;op4++)
				{
					result = Oper(Oper(Oper(5,op1,Oper(5,op2,5)),op3,5),op4,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}
	//op3
    for(op1=0;op1<2;op1++)
	{
		for(op2=0;op2<2;op2++)
		{
			for(op3=2;op3<4;op3++)
			{
				for(op4=0;op4<2;op4++)
				{
					result = Oper(Oper(Oper(5,op2,Oper(5,op3,5)),op1,5),op4,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}
	//op4
    for(op1=0;op1<2;op1++)
	{
		for(op2=0;op2<2;op2++)
		{
			for(op3=0;op3<2;op3++)
			{
				for(op4=2;op4<4;op4++)
				{
					result = Oper(Oper(Oper(5,op3,Oper(5,op4,5)),op2,5),op1,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}    		
	
	//�����˳�
	//op1+op2
    for(op1=2;op1<4;op1++)
	{
		for(op2=2;op2<4;op2++)
		{
			for(op3=0;op3<2;op3++)
			{
				for(op4=0;op4<2;op4++)
				{
					result = Oper(Oper(Oper(Oper(5,op1,5),op2,5),op3,5),op4,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	} 	
	//op1+op3
    for(op1=2;op1<4;op1++)
	{
		for(op2=0;op2<2;op2++)
		{
			for(op3=2;op3<4;op3++)
			{
				for(op4=0;op4<2;op4++)
				{
					result = Oper(Oper(Oper(5,op1,5),op2,Oper(5,op3,5)),op4,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	} 	
	//op1+op4
    for(op1=2;op1<4;op1++)
	{
		for(op2=0;op2<2;op2++)
		{
			for(op3=0;op3<2;op3++)
			{
				for(op4=2;op4<4;op4++)
				{
					result = Oper(Oper(Oper(5,op1,5),op2,5),op3,Oper(5,op4,5));
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	} 	
	//op2+op3
    for(op1=0;op1<2;op1++)
	{
		for(op2=2;op2<4;op2++)
		{
			for(op3=2;op3<4;op3++)
			{
				for(op4=0;op4<2;op4++)
				{
					result = Oper(Oper(5,op1,Oper(Oper(5,op2,5),op3,5)),op4,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}	
	//op2+op4
    for(op1=0;op1<2;op1++)
	{
		for(op2=2;op2<4;op2++)
		{
			for(op3=0;op3<2;op3++)
			{
				for(op4=2;op4<4;op4++)
				{
					result = Oper(Oper(5,op1,Oper(5,op2,5)),op3,Oper(5,op4,5));
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}		
	//op3+op4 
    for(op1=0;op1<2;op1++)
	{
		for(op2=0;op2<2;op2++)
		{
			for(op3=2;op3<4;op3++)
			{
				for(op4=2;op4<4;op4++)
				{
					result = Oper(Oper(5,op1,5),op2,Oper(Oper(5,op3,5),op4,5));
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}	
	
	//�����˳�
	//op4�Ӽ�
    for(op1=2;op1<4;op1++)
	{
		for(op2=2;op2<4;op2++)
		{
			for(op3=2;op3<4;op3++)
			{
				for(op4=0;op4<2;op4++)
				{
					result = Oper(Oper(Oper(Oper(5,op1,5),op2,5),op3,5),op4,5);
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}		 
	//op3�Ӽ� 
    for(op1=2;op1<4;op1++)
	{
		for(op2=2;op2<4;op2++)
		{
			for(op3=0;op3<2;op3++)
			{
				for(op4=2;op4<4;op4++)
				{
					result = Oper(Oper(Oper(5,op1,5),op2,5),op3,Oper(5,op4,5));
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}		
	//op2�Ӽ� 
    for(op1=2;op1<4;op1++)
	{
		for(op2=0;op2<2;op2++)
		{
			for(op3=2;op3<4;op3++)
			{
				for(op4=2;op4<4;op4++)
				{
					result = Oper(Oper(5,op1,5),op2,Oper(Oper(5,op3,5),op4,5));
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	}	
	//op1�Ӽ�
    for(op1=0;op1<2;op1++)
	{
		for(op2=2;op2<4;op2++)
		{
			for(op3=2;op3<4;op3++)
			{
				for(op4=2;op4<4;op4++)
				{
					result = Oper(5,op1,Oper(Oper(Oper(5,op2,5),op3,5),op4,5));
					if(5==result)
					{
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++count);
					}
				}
			}
		}
	} 
    return 0;
}
