#include<stdio.h>

void Re(char *a,int n)/*�ظ�*/
{
    printf("%c%c%c%c",a[0],a[0],a[0],a[1]);
    if(1!=n) 
	    Re(a,n-1);
	else
		printf("\n");
}

void Tab(int n,int m)/*����*/
{
	char even[]={' ','|'},odd[]={'-','+'};
	int i;
	for(i=0;i<n+1;i++)
	{
	    Re(even,m+1);
		Re(odd,m+1);
	}
}

int main()
{
	Tab(20,20);
	return 0;
}
