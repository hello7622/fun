#include <stdio.h>
#include <math.h>
float result,i;
float inswap()
{
    result=0;
	i=0;
	char c;
	c=getchar();
	if('\n'!=c)
	{
		inswap();
	    if('0'<=c&&'9'>=c) result+=(c-'0')*pow(16,i);
		else if('A'<=c&&'F'>c) result+=(c-'A'+10)*pow(16,i);
		i++;
	}
	return result;
}

float outswap(float a)
{
	int temp=a,rest=1;
    float data=0,count=0;
    while(0!=rest)
    {
	    rest=temp%8;
	    temp=temp/8;
	    data+=rest*pow(10,count);
	    count++;
    }
    return data;
}

int main()
{
	int j,n;
	scanf("%d ",&n);
	float in[n],out[n];
	for(j=0;j<n;j++)
	{
		in[j]=inswap();
		out[j]=outswap(in[j]);
	}
	for(j=0;j<n;j++)
	{
		printf("%.0f\n",out[j]);
	}
    return 0;
}

  
