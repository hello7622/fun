#include<stdio.h>
#include<stdlib.h>

//������ת��Ϊ������ַ� 
char OP(int op)
{
	switch(op)
	{
		case 0:                               // + �� 
			return '+';
			break;
		case 1:                               // - �� 
			return '-';
			break;
		case 2:                               // ���� 
			return '*';
			break;
		case 3:                               // �³� 
			return '/';
			break;
		default:
			printf("Currently only addition,'+','-','*','/' are supported!\n");
			return '?';
			break;
	}
}

//�������㣬�β�����������ִ��� 
double Oper(double data1,int op,double data2)
{
	if(EOF==data2||EOF==data1)
	{
		return EOF;
	}
	switch(op)
	{
		case 0:                                      // +  �� 
			return data1+data2;
			break;
		case 1:                                      // -  �� 
			return data1-data2;
			break;
		case 2:                                      // �� �� 
			return data1*data2;
			break;
		case 3:                                      // �� �� 
			if(0==data2)                             // ����Ϊ0 
			{
				printf("The divisor is zero!\n");
				return EOF;
			}
			return data1/data2;
			break;
		default:
			printf("Currently only addition,'+','-','*','/' are supported!\n");
			return EOF;
			break;
	}
}

void ENUM(int a,int b,int c,int d,int *count)
{
	int op1,op2,op3,op4;
	double result;
	for(op1=a;op1<a+2;op1++)
	{
		for(op2=b;op2<b+2;op2++)
		{
			for(op3=c;op3<c+2;op3++)
			{
				for(op4=d;op4<d+2;op4++)
				{
					if(     0==a&&2==b&&2==c&&2==d)
					{
					    result = Oper(5,op1,Oper(Oper(Oper(5,op2,5),op3,5),op4,5));
					}
					else if(0==a&&2==b&&2==c&&0==d)
					{
						result = Oper(Oper(5,op1,Oper(Oper(5,op2,5),op3,5)),op4,5);
					}
					else if(2==a&&      0==c&&2==d)
					{
						result = Oper(Oper(Oper(5,op1,5),op2,5),op3,Oper(5,op4,5));
					}
					else if(      0==b&&2==c&&2==d)
					{
						result = Oper(Oper(5,op1,5),op2,Oper(Oper(5,op3,5),op4,5));
					}
					else if(2==a&&0==b&&2==c&&0==d)
					{
						result = Oper(Oper(Oper(5,op1,5),op2,Oper(5,op3,5)),op4,5);
					}
					else if(0==a&&2==b&&0==c&&2==d)
					{
						result = Oper(Oper(5,op1,Oper(5,op2,5)),op3,Oper(5,op4,5));
					}
					else if(0==a&&2==b&&0==c&&0==d)
					{
						result = Oper(Oper(Oper(5,op1,Oper(5,op2,5)),op3,5),op4,5);
					}
					else if(0==a&&0==b&&2==c&&0==d)
					{
						result = Oper(Oper(Oper(5,op2,Oper(5,op3,5)),op1,5),op4,5);
					}
					else if(0==a&&0==b&&0==c&&2==d)
					{ 
						result = Oper(Oper(Oper(5,op3,Oper(5,op4,5)),op2,5),op1,5);
					}
					else
					{
						result = Oper(Oper(Oper(Oper(5,op1,5),op2,5),op3,5),op4,5);
					}
					if(5==result)
    	            {
						printf("5 %c 5 %c 5 %c 5 %c 5 = 5%5d\n",OP(op1),OP(op2),OP(op3),OP(op4),++(*count));
					}
				}	
			}
			
		}
	}	
	
}

//5 5 5 5 5=5
int main(void)
{
	int op1,op2,op3,op4;
	int count = 0;
	for(op1=0;op1<=2;op1+=2)
	{
		for(op2=0;op2<=2;op2+=2)
		{
			for(op3=0;op3<=2;op3+=2)
			{
				for(op4=0;op4<=2;op4+=2)
				{
					ENUM(op1,op2,op3,op4,&count);
				}
			}
		}
	}
	return 0;
}
