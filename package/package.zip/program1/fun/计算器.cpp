#include<stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
int main(void)
{
	double a,b;
	char c;
	for(int i=1;i<1000;i++)
	{
		scanf("%lf %c%lf",&a,&c,&b);
		switch(c)
		{
			case '+':					
			    printf("%lf\n",a+b);
				break;
			case '/':
				printf("%lf\n",a/b);
			    break;
			case '*':
				printf("%lf\n",a*b);
				break;
			case '-':
				printf("%lf\n",a-b);
				break;
			case '^':
				printf("%lf\n",pow(a,b));
				break;
			case '%':
				printf("%lf\n",fmod(a,b));
				break;	
			default:
				printf("Please input again\n");
				break;			
		}
	}
	return 0;
}
