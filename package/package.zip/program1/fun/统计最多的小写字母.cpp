#include <stdio.h>
int main()
{
    int i,letter[26]={0},a[2]={0,1};
	char c;
	while('\n'!=c)
	{
		c = getchar();
		letter[c-97]++;
	}
	for(i=0;i<26;i++)
	{
		if(letter[i]>=a[1])
		{
			a[1]=letter[i];
			a[0]=i;
		}
	}
	printf("%c\n",a[0]+97);
	printf("%d",a[1]);
    return 0;
}    
