#include <stdio.h>

double fac(int n)/*�׳�*/ 
{
	int i;
    double result=1;
	for(i=1;i<=n;i++)
	{
		result *= i;
	}
	return result;
}

int C(int n,int m)/*������Ϸ���*/ 
{
	int result;
	result = fac(n)/fac(m)/fac(n-m);
	return result;
}

int main()
{
	int a,b;
	for(a=0;a<20;a++)
	{
		printf("%d��",a);
		for(b=0;b<=a;b++)
		{
			printf("%d  ",C(a,b));
		}
		printf("\n\n");
	}
	return 0;
}
