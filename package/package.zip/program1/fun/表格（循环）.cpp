#include<stdio.h>
int pil[]={0,0,0};
void Hano(int n,int *pil,int a,int b,int c)/*0,1,2*/
{
	pil[a]=n;
	if(1==n)
	{
		pil[a]--;
		pil[b]++;
	}
	else
	{
		Hano(n-1,pil,a,c,b);
		//pil[a]--;
		pil[c]++;
		Hano(n-1,pil,c,b,a);
	} 
	   
}

int main()
{
	int n;
	n=2;
	Hano(n,pil,0,1,2);
	return 0;
}
  
