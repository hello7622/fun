#include<stdio.h>
int main(void)
{
    int a,b,answer;
    for(a=1;a<10;a++)
    {
    	for(b=1;b<=a;b++)
    	{
			answer = a*b;
    		printf("%d*%d=%d ",a,b,answer);
    	}
    	printf("\n\n");
    }
	return 0;
}		
