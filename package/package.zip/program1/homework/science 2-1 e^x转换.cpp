#include <stdio.h>
#include <math.h>
double fac(int n)
{
	double result=1;
	for(int i=2;i<=n;i++)
	{
		result*=i;
	}
	return result;
}

double F(double x,int n)
{
	double result=0;
	for(int i=0;i<=n;i++)
	{
		result+=pow(x,(double)i)/fac(i);
	}
	return result;
}

int main()
{
	double x;
	int n;
	printf("e^x=1+x+x^2/2!+...+x^n/n!\n");
	printf("Input x,n:");
	scanf("%lf,%d",&x,&n);
	printf("e^x~%lf",F(x,n));
    return 0; 
}
