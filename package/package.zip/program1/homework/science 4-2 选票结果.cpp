#include<stdio.h>
#include<string.h>

typedef struct candidate
{
	int zhang=0;
	int li=0;
	int wang=0;
	int invalid=0;
}CANDIDATE;

int main(void)
{
	char note[6];
	CANDIDATE vote;
	int i;
	for(i=0;i<10;i++)
	{
		gets(note);
		if(0==strcmp(note,"zhang"))
		    vote.zhang++;
        else if(0==strcmp(note,"li"))
            vote.li++;
        else if(0==strcmp(note,"wang"))
            vote.wang++;
        else
            vote.invalid++;
	}
	printf("\nVoting Result:\n");
	printf("li             %d\n",vote.li);
	printf("wang           %d\n",vote.wang);
	printf("zhang          %d\n",vote.zhang);
	printf("invalid ticket %d",vote.invalid);
	return 0; 
}
/*
li
ahng
wang
zhang
fghj
u
wang
zhang
wang
li
*/
