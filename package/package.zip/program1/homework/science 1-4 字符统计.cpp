#include<stdio.h>
int main(void)
{
    char c;
    int letter=0,blank=0,number=0,rest=0;
    while('#'!=c)
	{
		scanf("%1c",&c);
		if(((65<=c)&&(90>=c))||((97<=c)&&(122>=c)))
		    letter++;
		else if(32==c)
		    blank++;
		else if((48<=c)&&(57>=c))
		    number++;
		else 
		    rest++;
	}
	printf("letter = %d\n",letter);
	printf("blank  = %d\n",blank);
	printf("number = %d\n",number);
    printf("rest   = %d\n",rest);
	return 0;
}	
