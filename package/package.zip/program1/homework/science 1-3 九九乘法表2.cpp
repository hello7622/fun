#include <stdio.h>
int main(void)
{
	int a,b,i;
	printf("   ");
	for(a=1;a<10;a++)
	{
		printf("|%-4d",a);
	}
	for(b=1;b<10;b++)
	{
		printf("\n");
		for(i=0;i<a+2;i++)
		{
			printf("____");
		}
		printf("\n");
		printf("%-3d",b);
		for(a=1;a<10;a++) 
		{
			printf("|%-4d",a*b);
		}
		printf("\n");
	}	
	return 0;
}
