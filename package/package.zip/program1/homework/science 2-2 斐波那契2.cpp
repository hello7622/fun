#include <stdio.h>
double fib(int a)
{
	if(0==a)
	    return 0;
	else if(1==a||2==a)
        return 1;
    else
    {
		static double a=1,b=1,c;
		c=a+b;
		a=b;
		b=c;
		return c;
	}
}
int main()
{
	int i;
	for(i=1;i<50;i++)
	{
		printf("%.0lf\n",fib(i));
	}
    return 0;
}

  
