#include<stdio.h>

typedef struct birthday//�������� 
{
	int year;//�� 
	int month;//�� 
	int day;//�� 
}BIRTHDAY;

typedef struct occupation//ְҵ״�� 
{
	char college[20];//����ѧԺ 
	char position[20];//ְ�� 
	char job[20];//ְ�� 
}OCCUPATION;

typedef struct regist//�Ǽ�
{
	char name[20];//����
	char sex[20];//�Ա�
    BIRTHDAY birthday;//�������� 
    OCCUPATION occupation;//ְҵ״�� 
}REGIST; 

typedef struct Birthday
{
	int year;
	int month;
	int day;
}Birthday;

typedef struct Occupation
{
	const char * college;
	const char * position;
	const char * job;
}Occupation;

enum Gender
{
	Male,
	Female
};

typedef struct Regist
{
	const char * name;
	Gender gender;
    Birthday birthday;
    Occupation occupation;
}Regist; 

Regist get(FILE *input);
void setName(Regist *regist, const char *name);
void setGender(Regist *regist, Gender gender);
void setBirthday(Regist *regist, Birthday birthday);
void setOccupation(Regist *regist, Occupation occupation);

int main(void)
{
	Regist form;
	char buffer[1024];
	gets(buffer);
	form.name = buffer;
	puts(form.name);
//	gets(form.sex);
//	scanf("%d%d%d",
// 	    &form.birthday.year,
//	    &form.birthday.month,
//	    &form.birthday.day);
//	getchar();
//	gets(form.occupation.college);
//	gets(form.occupation.position);
//	gets(form.occupation.job);
//	
//	printf("\nregist��\n");
//	puts(form.name);
//	puts(form.sex);
//	printf("%4d/%02d/%02d\n",form.birthday.year,
//	                         form.birthday.month,
//							 form.birthday.day);
//	puts(form.occupation.college);
//	puts(form.occupation.position);
//	puts(form.occupation.job);
	return 0; 
}
/*
Li meng-yi
female
2000 9 12
Science Computer
Primary
President
*/
