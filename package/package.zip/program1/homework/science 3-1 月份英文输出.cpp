#include <stdio.h>

const char *month[]={"January"  ,"February","March"   ,"April"   ,
                     "May"      ,"June"    ,"July"    ,"August"  ,
					 "September","October" ,"November","December"};

int main()
{
	int n;
    scanf("%d",&n);
    while(0>n||12<n)
    {
    	fflush(stdin);
		printf("Illegal month\n");
    	scanf("%d",&n);
    }
    printf("%s",month[n-1]);
	return 0;
}
