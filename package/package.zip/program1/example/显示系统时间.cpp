#include<stdio.h>
#include<conio.h>
#include<windows.h>
#include<time.h>

//Tue Jan 31 19:56:00 2023
void DisplayTime(void)//��ʾϵͳʱ�� 
{
    time_t rawtime;
    struct tm *info;
    time(&rawtime);
    info = localtime(&rawtime);
    printf("%s",asctime(info));
}

int main(void)
{
    DisplayTime();
    return 0;
}
