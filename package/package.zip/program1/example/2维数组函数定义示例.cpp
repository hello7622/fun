#include <stdio.h>

void trans(int (*s)[2])//��ά���飬����Ϊ2
{
	s[0][0]=1;
	s[0][1]=2;
	s[1][0]=3;
	s[1][1]=4;
	s[2][0]=5;
	s[2][1]=6;
	//return (*s)[2];
}

int main()
{
	int a[3][2]={0,0,0,0,0,0};
	printf("%d,%d\n",a[0][0],a[0][1]);
	printf("%d,%d\n",a[1][0],a[1][1]);
	printf("%d,%d\n",a[2][0],a[2][1]);
	trans(a);
	printf("%d,%d\n",a[0][0],a[0][1]);
	printf("%d,%d\n",a[1][0],a[1][1]);
	printf("%d,%d\n",a[2][0],a[2][1]);
    return 0;
}

/*
#include<stdio.h>

void dataSort(int data[]);//�˴�data[]��*p�ȼ�,�����ˣ�*pҲ�����ά�ȼ� 

int main(void)
{
	int data[][5]={
		4,6,72,67,23,
		76,34,3,8,3456,
		90,354,87,45,5
	};
	int (*p)[5];//�൱�ڶ����ά����,�������p[i*n+j]����ʽ��ʾ 
	int i;
	for(p=data;p<data+3;p++)
	{
		dataSort(*p);
		for(i=0;i<5;i++)
		{
			printf("%5d",*((*p)+i));
		}
		printf("\n");
	}
    return 0;
}

void dataSort(int *p)
{
	int i,j,k;
	for(i=0;i<4;i++)
	{
		k = i;
		for(j=i+1;j<5;j++)
		{
			if(*(p+j)>*(p+k))
			    k = j;
		}
		if(k!=i)
		{
			*(p+k) ^= *(p+i);
			*(p+i) ^= *(p+k);
			*(p+k) ^= *(p+i);
		}
	}
}
*/
