#include<stdio.h>

int isPrime(int n);//��������1,���򷵻�0 

int main(void)
{
    int n;
    scanf("%d",&n);
    if(isPrime(n))
        printf("yes");
    else
    {
		int i;
		for(i=2;i<=n;i++)
		{
			while(isPrime(i)&&0==n%i)
			{
				printf("%d",i);
				n /= i;
				if(1!=n)
				    printf(" * ");
			}
			if(1==n)
			    break;
		}
	}
    return 0;
}

int isPrime(int n)
{
	if(2>n)
	    return 0;
    int i;
    for(i=2;i*i<=n;i++)
    {
		if(0==n%i)
		    return 0;
	}
	return 1;
}
