#include<stdio.h>
#include<windows.h>//���� 
int main(void)
{
	Beep(494, 200);//1
	Beep(523, 300);//2
	Beep(578, 400);//3
	Beep(659, 500);//4
	Beep(698, 600);//5
	Beep(784, 700);//6
	Beep(880, 800);//7
	Beep(932, 900);//8
    return 0; 
}
/*
Beep(Ƶ��(Hz),����ʱ��(ms)) 
*/
