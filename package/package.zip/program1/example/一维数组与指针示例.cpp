#include<stdio.h>

int main()
{
    int a[4]={8764,578,496,6};
    int *p = NULL;
    p = a+1;
	printf("%d",p[1]);
	for(p=a;p<a+4;p++)
	{
		scanf("%d",p);
	}
	for(p=a;p<a+4;p++)
	{
		printf("%d",*p);
	}
    return 0;
}
