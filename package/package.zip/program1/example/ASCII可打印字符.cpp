#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int main(void)
{
	FILE *fp;
	if((fp = fopen("demo.bin","wb"))==NULL)
	{
		printf("Failure to open demo.bin!\n");
		exit(0);
	}
	int i;
	for(i=0;i<128;i++)
	{
		fputc(i,fp);
	}
	fclose(fp);
	printf("\t\t\t\t\t\tASCII�ɴ�ӡ�ַ�\n\n\n");
	if((fp = fopen("demo.bin","rb"))==NULL)
	{
		printf("Failure to open demo.bin!\n");
		exit(0);
	}
	char ch;
	for(i=1;(ch = fgetc(fp))!=EOF;i++)
	{
		if(isprint(ch))
		    printf("%7d %5c",ch,ch);
        else
            printf("%7d %5d",ch,ch);
        if(0==(i%8))
            printf("\n\n");
	}
	fclose(fp);
	return 0;
}
