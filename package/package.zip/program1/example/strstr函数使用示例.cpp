#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main(void)
{
	char str[1000]={"hello everyone balabala?"};
	char *p = strstr(str,"can you");
	if(!p)
	    printf("1");
    else
	    printf("%c",*p);
    strcpy(str,"hello everyone can you balabala?");
    p = strstr(str,"can you");
	if(NULL==p)
	    printf("1");
    else
    {
	    printf("\n%c\n",*p);
        *p = 'I';
	}
	puts(str);
	return 0;
}
