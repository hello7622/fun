#include<iostream>
#include<fstream>
#include<string>
#include<windows.h>
#include<conio.h>
#include<cstdlib>
#include<ctime>
using namespace std;

int main(void)
{
	string inputFilename(__FILE__);
	string temp,output;
	
	ifstream fin(inputFilename);
	if(!fin.is_open())
	{
		cout << inputFilename << "��ʧ�ܣ�";
		return 0;
	}
	while(!fin.eof())
	{
		getline(fin,temp);
		temp += "\n";
		output += temp;
	}
	fin.close();
	
	string outputFilename("0123456789.cpp");
	srand(time(NULL));
	for(int i = 0;i < 10;i++)
	{
		swap(outputFilename[rand() % 10],outputFilename[rand() % 10]);
	}
	Sleep(500);
	if(kbhit())
	{
		cin >> outputFilename;
		outputFilename += ".cpp";
	}
	ofstream fout(outputFilename);
	if(!fout.is_open())
	{
		cout << outputFilename << "��ʧ�ܣ�";
		return 0;
	}
	fout << output;
	fout.close();
	cout << "��鿴�ļ�" << outputFilename;
	return 0;
}
