#include<stdio.h>
#include<windows.h>
using namespace std;

#define ROW 6
#define COL 10
#define SECOND 500
#define BEFORE 5
#define AFTER 6

void gotoxy(int x,int y)//�ƶ���� 
{
 COORD pos;
 pos.X = x;
 pos.Y = y;
 SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos); 
}

void SetColor(int ForgC)//�ı���ɫ 
{
    WORD wColor;
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
}

int findPath(int maze[][COL],int visit[][COL],int x,int y);//���� 

int main(void)
{
 int maze[ROW][COL]={
   {1,0,0,0,0,0,0,0,0,0},
   {1,0,1,1,0,1,1,1,1,0},
   {1,1,1,0,0,1,1,0,1,0},
   {1,0,0,1,1,1,0,0,1,0},
   {1,1,1,1,0,1,1,1,1,0},
   {0,0,0,0,0,0,0,0,1,1}
  };
 SetColor(BEFORE);
 printf("1000000000\n");
 printf("1011011110\n");
 printf("1110011010\n");
 printf("1001110010\n");
 printf("1111011110\n");
 printf("0000000011\n");
 Sleep(SECOND);
 int visit[ROW][COL]={0};
 int x=0;
 int y=0;
 printf("\n%d",findPath(maze,visit,x,y));
 return 0;
}
void before(int ss,int bef,int x,int y,int maze[][COL])
{
 Sleep(ss);
 SetColor(bef);
 gotoxy(y,x);
 printf("%d",maze[x][y]);
}

int findPath(int maze[][COL],int visit[][COL],int x,int y)
{
    SetColor(AFTER);
    gotoxy(y,x);
 printf("%d",maze[x][y]);
 visit[x][y] = 1;
 if(1==maze[x+1][y]&&!visit[x+1][y])//�� 
 {    
  before(SECOND,BEFORE,x,y,maze);
  return 1 + findPath(maze,visit,x+1,y);
 }
 if(1==maze[x-1][y]&&!visit[x-1][y])//�� 
    {
     before(SECOND,BEFORE,x,y,maze);
  return 1 + findPath(maze,visit,x-1,y);
    }
 if(1==maze[x][y+1]&&!visit[x][y+1])//�� 
    {
     before(SECOND,BEFORE,x,y,maze);
     return 1 + findPath(maze,visit,x,y+1);
    }
 if(1==maze[x][y-1]&&!visit[x][y-1])//�� 
    {
     before(SECOND,BEFORE,x,y,maze);
     return 1 + findPath(maze,visit,x,y-1);
    }
 if(ROW-1==x&&COL-1==y)
    {
     before(SECOND,BEFORE,x,y,maze);
     return 1;
    }
 else
    {
     before(SECOND,BEFORE,x,y,maze);
     return 0;
    }
}
