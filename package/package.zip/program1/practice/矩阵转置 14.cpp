#include <stdio.h>
#define M 10
#define N 10

//����ת��
void trans(int data[M][N],int row,int col)
{
	int i,j,temp;
	for(i=0;i<col;i++)
	{
		for(j=0;j<row;j++)
		{
			temp = data[j][i];
			data[j][i] = data[i][j];
			data[i][j] = temp;
		}
	}
} 

int main()
{
	int data[M][N]={0};
	int row,col,i,j;
	scanf("%d%d",&row,&col);
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			scanf("%d",&data[i][j]);
		}
	}
	trans(data,row,col);
	for(i=0;i<col;i++)
	{
		for(j=0;j<row;j++)
		{
			printf("%d ",data[i][j]);
		}
		printf("\n");
	}
	return 0;
}
