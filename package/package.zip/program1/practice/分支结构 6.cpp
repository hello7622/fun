#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void)
{
	srand(time(NULL));
	int a,b,x,op,i,counter=1;
	double c;
	while(1000>counter)
	{
		counter++;
		printf("Please enter the correct result.\n");
	    a = rand()%10;
	    b = rand()%10;
		switch(i=rand()%4)
	    {
			case 0:
				op = '+';
				printf("%d%c%d=",a,op,b);
				c = a+b;
				break;
			case 1:
				op = '-';
				printf("%d%c%d=",a,op,b);
				c = a-b;
				break;
			case 2:
				op = '*';
				printf("%d%c%d=",a,op,b);
				c = a*b;
				break;
			case 3:
				if(0==b) continue;
				else
				{
					op = '/';
					printf("%d%c%d=",a,op,b);
					c = (float)a/b;
				}
				break;		
		}
		while(1)
		{    
			scanf("%d",&x);
		    if(c==x)
		    {
			    printf("Correct!\n");
			    break;
		    }
		    else
		    {
			    printf("Wrong!Try again!\n");
			    printf("%d%c%d=",a,op,b);
		    }
	    }
		printf("������0��");
		scanf("%d",&counter);
		if(0==counter) break;
	}
	return 0;
}
