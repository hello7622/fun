#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
int main(void)
{
	srand(time(NULL));
	int counter,a,b;
	float answer,x;
	char arr[4]={'+','-','*','/'};
	char op;
	printf("��������");
	scanf("%d",&counter);/*���뽫���ֵ���Ŀ��*/
	while(0<counter)
	{ 
		a = rand()%101;
		b = rand()%101;
		op = arr[rand()%4];
		switch(op)
		{
			case '+':
				printf("%d%c%d=",a,op,b);
				answer = a+b;
				break;
			case '-':
				printf("%d%c%d=",a,op,b);
				answer = a-b;
				break;
			case '*':
				printf("%d%c%d=",a,op,b);
				answer = a*b;
				break;
			case '/':
				if(0==b)
				    continue;
				else
				{
					printf("%d%c%d=",a,op,b);
					answer = (float)a/b;/*���С��*/ 
				} 
				break;				
		}
		for(int i=0;i<2;i++)
		{
			scanf("%f",&x);
			if(answer==x)
			{
				printf("��\n");
				break;
			}		   
			else if(0==i) 
			{
				printf("����\n");
				printf("%d%c%d=",a,op,b);
			}
			else 
			{
				if('+'==op||'-'==op||'*'==op) printf("answer = %.0f\n",answer);
				if('/'==op) printf("answer = %f\n",answer);
				printf("��һ����\n");
			}   
		}		    
		counter--;
	}
	return 0;
}
