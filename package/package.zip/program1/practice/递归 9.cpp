#include <stdio.h>

void swap()
{
	char c;
	c = getchar();
	if('\n'!=c)
	{
		swap();
		printf("%c",c);
	}
}

int  main()
{   
    swap();
	return 0;
}
