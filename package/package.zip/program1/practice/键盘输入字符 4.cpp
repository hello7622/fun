#include<stdio.h>
#include<math.h>
int main()
{
    char a,b,c,d,e;
    printf("Input a,b,c,d:");
	scanf("%c,%c,%c,%c",&a,&b,&c,&d);
	printf("a = %c b = %c c = %c d = %c\n",a,b,c,d);  
	printf("Perform Actions:b = a,c = b,d = c,a = d\n");
	e = a;
	a = d;
	d = c;
	c = b;
	b = e;
	printf("a = %c b = %c c = %c d = %c",a,b,c,d);  
	return 0;
}
