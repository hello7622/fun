#include <stdio.h>
#include <stdlib.h>
int main()
{
	int a = 5,b = 2;
	double x = 5.0;
	printf("a/b   %d\n",a/b);
	printf("x/b   %f\n",x/b);
	return 0;
}
