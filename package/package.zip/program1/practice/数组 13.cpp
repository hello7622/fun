#include <stdio.h>
#define N 10

//ʵ������
int findMax(float data[N])
{
	int i,max;
	max = 0;
	for(i=1;i<N;i++)
	{
		if(data[i]>data[max])
		{
			max = i;
		}
	}
	return max;
} 

int main()
{
	float data[N];
	int i;
	for(i=0;i<10;i++)
	{
		scanf("%f",&data[i]);
	}
	int max;
	max = findMax(data);
	printf("%f\n",data[max]);
	return 0;
}
