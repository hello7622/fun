#include<stdio.h>
#include<stdlib.h>
int main()
{
	int x;
	printf("Input An Integer:");
	scanf("%d",&x);
	if(x%60==0)
	{
		printf("Yes\n");
	}
	else
	{
		printf("No");
	}
	return 0;
}
