#include<stdio.h>
#include<stdlib.h>
#include<time.h>

struct Node
{
	int data;
	struct Node *left = NULL;   //��ڵ��ʾ��2 
	struct Node *right = NULL;  //�ҽڵ��ʾ- 1 
	int sign =0;
};
typedef struct Node NODE;

NODE *AppendNode(NODE *node,int b)//���ӽڵ㣬�β�b Ϊ1�����㣩��ʾ������ڵ㣬Ϊ0��ʾ�����ҽڵ� 
{
	NODE *p = NULL;
	p = (NODE *)malloc(sizeof(NODE));
	if(p==NULL)
	{
		printf("No enough memory!\n");
		exit(0);
	} 
	p->left = NULL;
	p->right = NULL;
	p->sign = 0;
	if(node==NULL)
	{
		p->data = 2;
		node = p;
		return node;
	}
	if(b==0)
	{
		node->right = p;
		p->data = node->data-1;
	}
	else
	{
		node->left = p;
		p->data = node->data*2; 
	}
	return node;
}

NODE *GenerTree(Node *node,int bar,int flower)//������ 
{
	if(node==NULL)
	{
		printf("The root is NULL!\n");
		return NULL;
	}
	int n_bar = bar,n_flower = flower;
	if((n_bar==0&&n_flower==0)||node->data==0)
	{
		node->data = -1;
		return node;
	}
	NODE *p_node = node;
	if(n_bar!=0)
	{
		p_node->sign = 1;
		p_node = AppendNode(p_node,1);
		GenerTree(p_node->left,n_bar-1,n_flower);//��ڵ� 
	}
	if(n_flower!=0)
	{
		p_node->sign = 1;
		p_node = AppendNode(p_node,0);
		GenerTree(p_node->right,n_bar,n_flower-1);//�ҽڵ� 
	}
	return node;
} 

int PreOrderTraverse(NODE *node)//������� 
{
	if(node==NULL)
	{
		return 1;
	}
	static int PreOrderTraverseTreeNodeCount = 0;
	if(node->data==2)
	{
		printf("\n");
	}
	//if(node->data>0)
	{
		printf("%3d",node->data);
		PreOrderTraverseTreeNodeCount++;
	}
	if(node->data==-1)
	{
		printf("\n");
	}
	if(PreOrderTraverseTreeNodeCount==15)
	{
		printf("\n");
	}
	if(PreOrderTraverse(node->left))
	{
		if(PreOrderTraverse(node->right))
		{
			return 1;
		}
	}
	return 0;
}

int main(void)
{
	NODE *head = NULL;
	head = AppendNode(head,1);
	head->data = 2;      //��ʼֵ��Ϊ2
	head->left = NULL;
	head->right = NULL;
	int bar = 5,flower = 10;
	GenerTree(head,bar,flower);
	PreOrderTraverse(head); 
	return 0;
}
