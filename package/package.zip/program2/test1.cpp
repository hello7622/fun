#include<iostream>
#include<iomanip>
#include<fstream>
#include<sstream>
#include<windows.h>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<map>
#include<algorithm>
#include<limits>
#include<string>
#include<cstdlib>
#include<cstring>
#include<conio.h>
#include<ctime>
#include<cmath>
#include<random>
#include<typeinfo>
#include<utility>
#include<sys/stat.h>
#include<direct.h>
#include<numeric>
#include<list>
#include <type_traits>
using namespace std;
//#include"commonReserve.h"
//#include "utils/MyOutput.hpp"
#include "utils/ExtendVector.hpp"
#include "utils/MyRand.hpp"
#include "utils/MyAlgorithm.hpp"
//#include "utils/MyConsole.hpp"

const int MAX_SIZE = 10002;
const int MAX_LEN = 1e9;

vector<int>& operator+=(vector<int>& data, const initializer_list<int>& extend) {
	for (const int& elem: extend) {
		data.push_back(elem);
	}
	return data;
}

void func(int x, int y) {
	cout << x << "." << y << "\n";
}

int main(void) {
	cout << (!!-2);
	return 0;
}
//#include <stdio.h>
//int main(int argc,char* argv[]) {
//	if(argc > 0) {
//		printf("%d\n",argc);
//		for(int i = 0;i < argc;i++) printf("%s\n",argv[i]);
//	} else {
//		printf("hello\n");
//	}
//	return 0;
//}
