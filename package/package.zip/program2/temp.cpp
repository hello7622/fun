#include <iostream>
#include <vector>
using namespace std;

std::vector<int> Vector() {
	std::cout << "?";
	return {1, 2, 3, 4, 5};
}

int main() {
	for (const auto& val : Vector()) {
		cout << val << " ";
	}
	return 0;
}
