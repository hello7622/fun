#ifndef __KNAPSACK_H__
#define __KNAPSACK_H__

// item -> (weight: int, value: double)
// solution(capacity: int, items) -> (max_value: double, max_weight: int)
// 分数背包：可以选择物品的部分放入，引入价值密度ratio = value / weight
// 0-1背包：选择放入或不放入
// 约束(constraint) capacity >= 0
/*
weights = [10, 10, 30]
values = [60, 100, 120]
capacity = 50
上述用例可使用贪心算法求解0-1背包问题得到最优解
下面为反例，此时解不最优 
weights = [10, 20, 30]
values = [60, 100, 120]
capacity = 50
*/

#include <vector>		// std::vector<Item>
#include <algorithm>	// std::max
#include <tuple>		// std::tuple<int, int> -> (i, remain_capacity)
#include <map>			// std::map<std::tuple<int, int>, Item>
#include <iostream>		// operator<<

struct Item {
	double value;
	int weight;
	Item(double v = 0, int w = 0): value(v), weight(w) {}
	double Ratio() const {
		return value / weight;
	}
};

Item GreadyFractionalKnapsack(int capacity, std::vector<Item> items);	// nlogn, 1
Item Gready0_1Kanpsack(int capacity, std::vector<Item> items);			// nlogn, 1
Item Brute0_1Knapsack(int capacity, std::vector<Item> items);			// n^2, n
Item Dynamic0_1Knapsack(int capacity, std::vector<Item> items);			// n * capacity, n * capacity
Item DynamicImprove0_1Knapsack(int capacity, std::vector<Item> items);	// n * capacity, capacity
Item DynamicMemory0_1Knapsack(int capacity, std::vector<Item> items);	// n * capacity, n * capacity
std::ostream& operator<<(std::ostream& outo, const Item& item);

Item GreadyFractionalKnapsack(int capacity, std::vector<Item> items) {
	int max_weight = capacity;
	// 按价值密度从高到低排序
	std::sort(items.begin(), items.end(), [](const Item & a, const Item & b) {
		return (a.Ratio() > b.Ratio());
	});
	double max_value = 0;
	for (const Item& item : items) {
		if (capacity == 0) {
			// 背包已满
			break;
		}
		if (item.weight <= capacity) {
			// 物品可完全放入
			max_value += item.value;
			capacity -= item.weight;
		} else {
			// 不可完全放入
			max_value += item.Ratio() * capacity;
			capacity = 0;
		}
	}
	return Item(max_value, max_weight);
}

Item Gready0_1Kanpsack(int capacity, std::vector<Item> items) {
	// 按价值密度从高到低排序
	std::sort(items.begin(), items.end(), [](const Item & a, const Item & b) {
		return (a.Ratio() > b.Ratio());
	});
	double max_value = 0;
	int max_weight = 0;
	for (const Item& item : items) {
		if (max_weight + item.weight <= capacity) {
			// 可以放入
			max_value += item.value;
			max_weight += item.weight;
		}
	}
	return Item(max_value, max_weight);
}

Item Brute0_1Knapsack(int capacity, std::vector<Item> items) {
	int n = items.size();
	double max_value = 0;
	int max_weight;
	double total_value = 0;
	int total_weight = 0;
	for (int i = 0; i < (1 << n); i++) {
		// 生成所有可能的组合
		total_value = 0;
		total_weight = 0;
		for (int j = 0; j < n; j++) {
			// 检查第j个物品是否被选择
			if (i & (1 << j)) {
				total_value += items[j].value;
				total_weight += items[j].weight;
			}
		}
		if (total_weight <= capacity && max_value < total_value) {
			// 未超过背包容量 且 总价值最大
			max_value = total_value;
			max_weight = total_weight;
		}
	}
	return Item(max_value, max_weight);
}

Item Dynamic0_1Knapsack(int capacity, std::vector<Item> items) {
	int n = items.size();
	double total_value;
	std::vector<std::vector<double>> dpV(n + 1, std::vector<double>(capacity + 1, 0));
	std::vector<std::vector<double>> dpW(n + 1, std::vector<double>(capacity + 1, 0));
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= capacity; j++) {
			total_value = dpV[i - 1][j - items[i - 1].weight] + items[i - 1].value;
			if (items[i - 1].weight <= j && dpV[i - 1][j] < total_value) {
				dpV[i][j] = total_value;
				dpW[i][j] = dpW[i - 1][j - items[i - 1].weight] + items[i - 1].weight;
			} else {
				dpV[i][j] = dpV[i - 1][j];
				dpW[i][j] = dpW[i - 1][j];
			}
		}
	}
	return Item(dpV[n][capacity], dpW[n][capacity]);
}

Item DynamicImprove0_1Knapsack(int capacity, std::vector<Item> items) {
    int n = items.size();
    std::vector<double> dpV(capacity + 1, 0);
    std::vector<double> dpW(capacity + 1, 0);

    for (int i = 0; i < n; i++) {
        for (int j = capacity; j >= items[i].weight; j--) {
            double total_value = dpV[j - items[i].weight] + items[i].value;
            if (dpV[j] < total_value) {
                dpV[j] = total_value;
                dpW[j] = dpW[j - items[i].weight] + items[i].weight;
            }
        }
    }
    return Item(dpV[capacity], dpW[capacity]);
}

Item _knapsack(int i, int remain_capacity, const int& n, std::map<std::tuple<int, int>, Item>& memo, const std::vector<Item>& items) {
	if (i >= n || remain_capacity <= 0) {
		return Item(0, 0);
	} 
	// 检查是否已经计算过
	if (memo.count({i, remain_capacity})) {
		return memo[{i, remain_capacity}];
	} 
	// 不选择当前物品
	Item not_taken = _knapsack(i + 1, remain_capacity, n, memo, items);
	// 选择当前物品（如果可以放入背包）
	Item taken(0, 0);
	if (items[i].weight <= remain_capacity) {
		Item tmp = _knapsack(i + 1, remain_capacity - items[i].weight, n, memo, items);
		taken.value = items[i].value + tmp.value;
		taken.weight = items[i].weight + tmp.weight;
	} 
	// 选择最大值
	memo[{i, remain_capacity}] = std::max(not_taken, taken, [](const Item& a, const Item& b){
		return (a.value < b.value);
	});
	return memo[{i, remain_capacity}]; 
}
Item DynamicMemory0_1Knapsack(int capacity, std::vector<Item> items) {
	int n = items.size();
	std::map<std::tuple<int, int>, Item> memo;
	return _knapsack(0, capacity, n, memo, items);
}

std::ostream& operator<<(std::ostream& outo, const Item& item) {
	outo << "Item(value: " << item.value
	     << ", weight: " << item.weight
	     << ", ratio: " << item.Ratio()
	     << ")";
	return outo;
}

#endif
