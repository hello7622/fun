#include "knapsack.h"
#include <string>
using namespace std;

typedef Item (*knapsack)(int, vector<Item>);

class Solution {
        int capacity;
        vector<Item> items;
        tuple<int, vector<Item>, vector<Item>> instance;
        knapsack func[6];
    public:
        Solution()
        : instance(50, {Item(120, 30), Item(100, 20), Item(60, 10)}, {Item(120, 30), Item(100, 10), Item(60, 10)}) 
        , func{GreadyFractionalKnapsack, Gready0_1Kanpsack, Brute0_1Knapsack, Dynamic0_1Knapsack, DynamicImprove0_1Knapsack, DynamicMemory0_1Knapsack} {}
        bool IsNumber(const std::string& str) {
            for (char ch: str) {
                if (!isdigit(ch)) {
                    return false;
                }
            }
            return true;
        }
        void SetProblem(const vector<Item>& _items) {
            items = _items;
        }
        void InputProblem() {
            int item_num, weight;
            double value;    
            cout << "---输入背包问题实例---\n"
                 << "背包容量：";
            cin >> capacity;
            cout << "物品数量：";
            cin >> item_num;
            items.clear();
            cout << "请输入" << item_num << "个物品的价值（double）和重量（int）：\n";
            for (int i = 1; i <= item_num; i++) {
                cout << "物品" << i << "的价值（double）和重量（int）：";
                cin >> value >> weight;
                items.push_back(Item(value, weight));
            }
            cout << "---输入完毕---\n\n";
        }
        Item SoluteKnapsack(int index) {
            return func[index](capacity, items);
        }
        int Prompt() {
            int optionNum = 11;
            cout << "---求解背包问题---\n"
                 << "0.贪心算法求解分数背包问题-最优解\n"
                 << "1.贪心算法求解0-1背包问题-近似解\n"
                 << "2.暴力算法求解0-1背包问题-最优解\n"
                 << "3.动态规划求解0-1背包问题-最优解\n"
                 << "4.动态规划（空间优化，只存储两行状态）求解0-1背包问题-最优解\n"
                 << "5.动态规划（记忆功能，使用递归）求解0-1背包问题-最优解\n"
                 << "6.获取当前实例\n"
                 << "7.输入实例\n"
                 << "8.贪心算法——0-1背包——正例\n"
                 << "9.贪心算法——0-1背包——反例\n"
                 << "10.退出\n"
                 << "---求解背包问题---\n"
                 << "请输入0~" << optionNum - 1 << "编号：";
            int index;
            string input;
            cin >> input;
            if (!IsNumber(input)) {
                index = 10;
            } else {
                index = stoi(input);
            }
            cout << endl;
            return (index % optionNum + optionNum) % optionNum;
        }
        void OutputInstance(const int& c, const vector<Item>& _items) {
            cout << "背包容量：" << c << endl
                 << "物品数量：" << _items.size() << endl;
            for (const Item& item: _items) {
                cout << item << endl;
            }
        }
        bool Execute(int index) {
            int c;
            vector<Item> _items;
            switch (index) {
                case 6:
                    cout << "---当前实例---\n";
                    OutputInstance(capacity, items);
                    cout << "---当前实例---\n\n";
                    break;
                case 7:
                    InputProblem();
                    break;
                case 8:
                    cout << "---正例---\n";
                    c = get<0>(instance);
                    _items = get<2>(instance);
                    OutputInstance(c, _items);
                    cout << "求解结果：" << Gready0_1Kanpsack(c, _items) << endl
                         << "蛮力求解：" << Brute0_1Knapsack(c, _items) << endl
                         << "---正例---\n\n";
                    break;
                case 9:
                    cout << "---反例---\n";
                    c = get<0>(instance);
                    _items = get<1>(instance);
                    OutputInstance(c, _items);
                    cout << "求解结果：" << Gready0_1Kanpsack(c, _items) << endl
                         << "蛮力求解：" << Brute0_1Knapsack(c, _items) << endl
                         << "---反例---\n\n";
                    break;
                case 10:
                    return false; 
                    break;
                default:
                    cout << "---求解---\n"
                         << func[index](capacity, items) << endl
                         << "---求解---\n\n";
                    break;
            }
            return true;
        }
}; 

int main() {
    Solution s;
    while (s.Execute(s.Prompt()));
    return 0;
}
