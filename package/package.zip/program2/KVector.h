#ifndef __KVECTOR_H__
#define __KVECTOR_H__

#include <memory>
#include <initializer_list>
#include <stdexcept>
#include <utility>
#include <iterator>

template <typename T, typename Allocator = std::allocator<T>>
class KVector {
public:
    // 类型定义
    using value_type = T;
    using allocator_type = Allocator;
    using size_type = size_t;
    using difference_type = ptrdiff_t;
    using reference = T&;
    using const_reference = const T&;
    using pointer = typename std::allocator_traits<Allocator>::pointer;
    using const_pointer = typename std::allocator_traits<Allocator>::const_pointer;
    
    // 迭代器定义
    class iterator {
    public:
        using iterator_category = std::random_access_iterator_tag;
        using value_type = T;
        using difference_type = ptrdiff_t;
        using pointer = T*;
        using reference = T&;
        
        iterator(pointer ptr = nullptr);
        reference operator*() const;
        pointer operator->() const;
        iterator& operator++();
        iterator operator++(int);
        iterator& operator--();
        iterator operator--(int);
        iterator operator+(difference_type n) const;
        iterator operator-(difference_type n) const;
        difference_type operator-(const iterator& other) const;
        bool operator==(const iterator& other) const;
        bool operator!=(const iterator& other) const;
        
    private:
        pointer m_pPtr;
    };
    
    class const_iterator {
    public:
        using iterator_category = std::random_access_iterator_tag;
        using value_type = const T;
        using difference_type = ptrdiff_t;
        using pointer = const T*;
        using reference = const T&;
        
        const_iterator(pointer ptr = nullptr);
        const_iterator(iterator it);
        reference operator*() const;
        pointer operator->() const;
        const_iterator& operator++();
        const_iterator operator++(int);
        const_iterator& operator--();
        const_iterator operator--(int);
        const_iterator operator+(difference_type n) const;
        const_iterator operator-(difference_type n) const;
        difference_type operator-(const const_iterator& other) const;
        bool operator==(const const_iterator& other) const;
        bool operator!=(const const_iterator& other) const;
        
    private:
        pointer m_pPtr;
    };
    
    // 构造函数
    explicit KVector(const Allocator& alloc = Allocator());
    explicit KVector(size_type count, const T& value = T(), const Allocator& alloc = Allocator());
    template <typename InputIt>
    KVector(InputIt first, InputIt last, const Allocator& alloc = Allocator());
    KVector(std::initializer_list<T> init, const Allocator& alloc = Allocator());

    template <typename InputIt>
    void assign(InputIt first, InputIt last);

    // 拷贝控制
    KVector(const KVector& other);
    KVector(KVector&& other) noexcept;
    ~KVector();
    KVector& operator=(const KVector& other);
    KVector& operator=(KVector&& other) noexcept;
    
    // 元素访问
    reference operator[](size_type pos);
    const_reference operator[](size_type pos) const;
    reference at(size_type pos);
    const_reference at(size_type pos) const;
    reference front();
    const_reference front() const;
    reference back();
    const_reference back() const;
    
    // 迭代器
    iterator begin() noexcept;
    const_iterator begin() const noexcept;
    const_iterator cbegin() const noexcept;
    iterator end() noexcept;
    const_iterator end() const noexcept;
    const_iterator cend() const noexcept;
    
    // 容量
    bool empty() const noexcept;
    size_type size() const noexcept;
    size_type capacity() const noexcept;
    void reserve(size_type new_cap);
    void shrink_to_fit();
    
    // 修改器
    void clear() noexcept;
    iterator insert(const_iterator pos, const T& value);
    iterator insert(const_iterator pos, T&& value);
    template <typename... Args>
    iterator emplace(const_iterator pos, Args&&... args);
    iterator erase(const_iterator pos);
    iterator erase(const_iterator first, const_iterator last);
    void push_back(const T& value);
    void push_back(T&& value);
    template <typename... Args>
    reference emplace_back(Args&&... args);
    void pop_back();
    void resize(size_type count);
    void resize(size_type count, const value_type& value);
    void swap(KVector& other) noexcept;
    
    // 分配器访问
    allocator_type get_allocator() const noexcept;
    
private:
    Allocator m_alloc;        // 分配器实例
    T* m_pData;               // 数据指针
    size_type m_nSize;        // 当前元素数量
    size_type m_nCapacity;    // 当前容量
    
    // 辅助函数
    void construct(pointer p, const T& value);
    void construct(pointer p, T&& value);
    template <typename... Args>
    void construct(pointer p, Args&&... args);
    void destroy(pointer p);
    void reallocate(size_type new_capacity);
};

#endif // __KVECTOR_H__
