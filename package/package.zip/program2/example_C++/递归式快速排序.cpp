#include<iostream>
using namespace std;

void QuickSort(int *a,int beg,int end)
{
	if(beg>=end)
	{
		return ;
	}
	int i = beg,j = end;
	int key = a[beg];
	while(i<j)
	{
		while(a[j]>=key&&i<j)
		{
			j--;
		}
		swap(a[j],a[i]);
		while(a[i]<=key&&i<j)
		{
			i++;
		}
		swap(a[i],a[j]);
	}
	QuickSort(a,beg,j-1);
	QuickSort(a,i+1,end);
}

int main(void)
{
	
	int a[] = {5,3,7,6,4,1,0,2,9,10,8};
	QuickSort(a,0,10);
	int i;
	for(i=0;i<11;i++)
	{
		cout<<a[i]<<' ';
	}
	return 0;
}
