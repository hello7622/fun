char** CreateChar(int x, int y) {
	char** p = new char*[x];
	while (x--) p[x] = new char[y];
	return p;
}
bool DeleteChar(char** p, int x) {
	while (x--) delete[] p[x];
	delete[] p;
	return true;
}
