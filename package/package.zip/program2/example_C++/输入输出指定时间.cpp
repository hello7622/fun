#include <iostream>
#include <iomanip>
#include <ctime>

int main() {
    std::tm time = {};
    std::cout << "Enter date and time in format (YYYY-MM-DD HH:MM:SS): ";
    std::cin >> std::get_time(&time, "%Y-%m-%d %H:%M:%S");
    if (std::cin.fail()) {
        std::cerr << "Invalid date/time input\n";
        return 1;
    }
/*
    std::tm time = {};
    std::cout << "Enter year: ";
    std::cin >> time.tm_year;
    time.tm_year -= 1900;
    std::cout << "Enter month (1-12): ";
    std::cin >> time.tm_mon;
    time.tm_mon -= 1;
    std::cout << "Enter day of month (1-31): ";
    std::cin >> time.tm_mday;
    std::cout << "Enter hour (0-23): ";
    std::cin >> time.tm_hour;
    std::cout << "Enter minute (0-59): ";
    std::cin >> time.tm_min;
    std::cout << "Enter second (0-60): ";
    std::cin >> time.tm_sec;
*/    
    std::time_t timestamp = std::mktime(&time);
    std::tm* timeptr = std::localtime(&timestamp);
    std::cout << "Specified time: " << std::put_time(timeptr, "%Y-%m-%d %H:%M:%S") << '\n';    
    return 0;
}
/*
int main(void) 
{
    std::tm time = {};
    std::cout << "Enter date and time in format (YYYY-MM-DD HH:MM:SS): ";
    std::cin >> std::get_time(&time, "%Y-%m-%d %H:%M:%S");
    if (std::cin.fail()) {
        std::cerr << "Invalid date/time input\n";
        return 1;
    }
    	
    std::cout << "Specified time: " << std::put_time(&time, "%Y-%m-%d %H:%M:%S") << '\n';
	return 0;
}
*/
