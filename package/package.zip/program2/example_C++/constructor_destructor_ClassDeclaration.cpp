//p60~p74
#include<iostream>
using namespace std;

class Test
{
	private:
		int x;
		int y;
	public:
		Test(int px = 0,int py = 0);                      //�������캯��
		~Test();                                          //������������ 
		void ShowData();
};

int main(void)
{
	Test A(2,3);
	A.ShowData();
	return 0;
}

Test::Test(int px,int py)
{
	x = px;
	y = py;
	cout<<"Constructor called."<<endl;
}

Test::~Test()
{
	cout<<"Destructor called."<<endl;
}

void Test::ShowData()
{
	cout<<"x = "<<x<<" y = "<<y<<endl;
}

/*
class String_data
{
    private:
        char *str;
	public:
        String_data(char *s)                              //���캯�� 
        {
            str = new char[strlen(s)+1];
            strcpy(str,s);
        }
        ~String_data()                                    //�������� 
        {
            delete str;
        }
        void get_info(char *);
        void sent_info(char *);
}; 
*/
