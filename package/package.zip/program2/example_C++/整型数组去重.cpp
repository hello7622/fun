#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<ctime>
#include"IntSort.h"
using namespace std;

// �����ظ�
int DeleteRepet(int* begin,int* end)
{
	int count = 0;
	for(int* p1 = begin;p1 <= end - 1 - count;p1++)
	{
		for(int* p2 = p1 + 1;p2 <= end - count;p2++)
		{
			if(*p2 == *p1)
			{
				++count;
				for(int* p3 = p2;p3 <= end - count;p3++)
				{
					*p3 = *(p3 + 1);
				}
				--p2;
			}
		}
	}
	return count;
} 

const int MAX_SIZE = 100;

int main(void)
{
	srand(time(NULL));
	int a[MAX_SIZE] = {0};
	for(int i = 0;i < MAX_SIZE;i++)
	{
		a[i] = rand() % 100;
	}
	for(int i = 0;i < MAX_SIZE;i++)
	{
		cout << setw(4) << a[i];
	}
	cout << endl;
	Sort4(a,a + MAX_SIZE);
	for(int i = 0;i < MAX_SIZE;i++)
	{
		cout << setw(4) << a[i];
	}
	cout << endl;
	int n = MAX_SIZE - DeleteRepet(a,a + MAX_SIZE);	
	for(int i = 0;i < n;i++)
	{
		cout << setw(4) << a[i];
	}
	cout << endl;	
	return 0;
}
