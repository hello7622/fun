#include<iostream>
using namespace std;

int gcf(int a, int b) {
	if (b == 0) {
		return a;
	} else {
		return gcf(b, a % b);
	}
}

int main(void) {
	for(int i = 1;i < 100;i++) {
		for(int j = i + 1;j < 100;j++) {
			printf("%d\t%d\t%d\t",i,j,gcf(i,j));
		}
	}
	return 0;
}
