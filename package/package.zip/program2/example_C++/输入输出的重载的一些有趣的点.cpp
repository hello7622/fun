#include<iostream>

class Complex
{
	private:
		double real, imag;						// ʵ�����鲿 
	public:
		Complex(double r=0, double i=0);
		Complex operator+(Complex others);		// ˫Ŀ�����+����
		Complex operator-(Complex others); 		// ˫Ŀ�����-���� 
		friend std::istream& operator>>(std::istream&, Complex&);
		friend std::ostream& operator<<(std::ostream&, Complex);
};

int main(void)
{
    Complex c1(2.5,3.7), c2(4.2,6.5), c3;
    std::cout << c1 << c2 << c3;
    std::cout << c1 - c2;
    std::cin >> c3;
    std::cout << c3;
    return 0;
}

Complex::Complex(double r, double i)
    : real(r), imag(i)
{
	//std::cout << "\nConstructing!\n";
}
Complex Complex::operator+(Complex others)
{
	return Complex(real+others.real,imag+others.imag);
} 
Complex Complex::operator-(Complex others)
{
	return Complex(real-others.real,imag-others.imag);
} 
std::istream& operator>>(std::istream& into, Complex& c)
{
	char op,i;
	into >> c.real >> op >> c.imag >> i;
	if(op=='-')
	{
		c.imag = -c.imag;
	}
	return into;
}
std::ostream& operator<<(std::ostream& outo, Complex c)
{
	outo << c.real;
	if(c.real==0&&c.imag==0)
	{
		outo << std::endl;
		return outo;
	}
	if(c.imag>0)
	{
		outo << '+';
	}
	outo << c.imag << "i\n";
	return outo;
}
