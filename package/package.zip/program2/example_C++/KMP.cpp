#include<iostream>
#include<vector>

// KMP
// ����next����
std::vector<int> BuildNext(const char* pattern) {
	int m = 0;
	for(;pattern[m];m++);
	
	std::vector<int> pi(m, 0);

	for (int i = 1, j = 0; i < m; ) {
		if (pattern[i] == pattern[j]) {
			pi[i] = j + 1;
			i++;
			j++;
		} else {
			if (j != 0) {
				j = pi[j - 1];
			} else {
				pi[i] = 0;
				i++;
			}
		}
	}

	return pi;
}

// ʹ��KMP�㷨�������в����Ӵ�
bool KMP(const char* text, const char* pattern) {
	int n = 0;
	for(;text[n];n++);
	int m = 0;
	for(;pattern[m];m++);

	// ����next����
	std::vector<int> pi = BuildNext(pattern);

	for (int i = 0, j = 0; i < n; ) {
		if (text[i] == pattern[j]) {
			i++;
			j++;
			if (j == m) {
				// �Ӵ��ҵ�
				
				return true;
			}
		} else {
			if (j != 0) {
				j = pi[j - 1];
			} else {
				i++;
			}
		}
	}
	return false;
}

/*
string���� 
// KMP
// ����next����
std::vector<int> BuildNext(const std::string& pattern) {
	int m = pattern.size();
	std::vector<int> pi(m, 0);

	for (int i = 1, j = 0; i < m; ) {
		if (pattern[i] == pattern[j]) {
			pi[i] = j + 1;
			i++;
			j++;
		} else {
			if (j != 0) {
				j = pi[j - 1];
			} else {
				pi[i] = 0;
				i++;
			}
		}
	}

	return pi;
}

// ʹ��KMP�㷨�������в����Ӵ�
bool KMP(const std::string& text, const std::string& pattern, int& col) {
	int n = text.size();
	int m = pattern.size();

	// ����next����
	std::vector<int> pi = BuildNext(pattern);

	for (int i = 0, j = 0; i < n; ) {
		if (text[i] == pattern[j]) {
			i++;
			j++;
			if (j == m) {
				// �Ӵ��ҵ�
				col = i - j + 1;
				return true;
			}
		} else {
			if (j != 0) {
				j = pi[j - 1];
			} else {
				i++;
			}
		}
	}
	return false;
}

*/
