#include<iostream>
#include<fstream>
#include<string> 
#include<stack>
using namespace std;


void TransSystem(stack<char>& store,long long num,int ending)
{
	int temp;
	
	stack<char> clear;
	store.swap(clear);					// ջ��� 
	
	if(num == 0)
	{
		store.push('0');
		return ;
	}
	
	while(num > 0)
	{
		temp = num % ending; 
		if(temp >= 10)
		{
			temp += 'a' - 10;
		}
		else
		{
			temp += '0';
		}
		store.push(temp);
		num /= ending;
	}
}

void OutSystem(long long num,int ending)
{
	stack<char> temp;
	TransSystem(temp,num,ending);
	while(!temp.empty())
	{
		cout << temp.top();
		temp.pop();
	}
	cout << endl;
}

int main(void)
{	
	long long n;
	cin >> n;
	cout << "ʮ���ƣ�  " << n << endl;
	cout << "�����ƣ�  ";
	OutSystem(n,2);
	cout << "�����ƣ�  ";
	OutSystem(n,3);
	cout << "�Ľ��ƣ�  ";
	OutSystem(n,4);
	cout << "�˽��ƣ�  ";
	OutSystem(n,8);
	cout << "ʮ�����ƣ�";
	OutSystem(n,16);
	return 0;
} 
