#include<iostream>
#include<cstdlib>
#include<conio.h>
using namespace std;

int main(void)
{
	int ch;
	do
	{
		if(!kbhit()) cout << '|';
		ch = getch();
		cout << ch << ' ';
	}while(ch != 27);
	return 0;
}
