#pragma once
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;

const int MAX_SIZE = 100000;

// ����Ƿ�����
bool Test(int* begin,int* end)
{
	for(int* p = begin;p < end - 1;p++)
	{
		if(*p > *(p + 1))
		{
			return false;
		}
	}
	return true;
} 

// �����ظ�
int DeleteRepet(int* begin,int* end)
{
	int count = 0;
	for(int* p1 = begin;p1 <= end - 1 - count;p1++)
	{
		for(int* p2 = p1 + 1;p2 <= end - count;p2++)
		{
			if(*p2 == *p1)
			{
				++count;
				for(int* p3 = p2;p3 <= end - count;p3++)
				{
					*p3 = *(p3 + 1);
				}
				--p2;
			}
		}
	}
	return count;
} 

// �������
void OutputArray(int* begin,int* end)
{
	for(int* p = begin;p < end;p++) cout << *p << ' ';
	cout << endl;
}
 
// endһ��Ϊ��ָ����end = begin + length 
// ����Ĭ��Ϊ����
// ѡ������ 
bool Sort1Select(int* begin,int* end)
{
	for(int* p1 = begin;p1 < end - 1;p1++)
	{
		int* temp = p1;
		for(int* p2 = p1 + 1;p2 < end;p2++)
		{
			if(*p2 < *temp)
			{
				temp = p2;
			}
			if(p1 > begin && *temp - *(p1 - 1) <= 1)
			{
	  		    break;
			}			
		}
		if(temp != p1)
		{
			swap(*temp,*p1);
		}
	}
	return true;
}
// ˫ð������
bool Sort2(int* begin,int* end)
{
	int *p1 = begin,*p2 = --end;
	for(;p1 <= p2;p1++,p2--)
	{
		int* p = p1;
		while(p <= p2)
		{
			if(*p1 > *p)
			{
				swap(*p,*p1);
			}
			if(*p2 < *p)
			{
				swap(*p,*p2);
			}
			p++;
		}
	}
	return true;
} 
// ˫ð������2 
bool Sort2Orthodox(int* begin,int* end)
{
	int n = end - begin,i = 0,j = n - 1;
	int* p = begin + i;
	while(i < j)
	{
		while(p < begin + j)
		{
			if(*p > *(p + 1))
			{
				swap(*p,*(p + 1));
			}
			++p;
		}
		--j;
		while(p > begin + i)
		{
			if(*p < *(p - 1))
			{
				swap(*p,*(p - 1));
			}
			--p;
		}
		++i;	
	}
	return true;
}
// ��������
bool Sort3Insert(int* begin,int* end,int gap = 1)
{
	for(int* ans = begin + gap;ans < end;ans += gap)
	{
		int *s = ans,record = *ans;
		for(int* s = ans;s > begin;s -= gap)
		{
			if(*(s - gap) < record) break;
			*s = *(s - gap);
		}
		*s = record;
	}	
	return true;
} 
// ϣ������
bool Sort3Shell(int* begin,int* end)
{
	int gap = (end - begin) / 2;
	while(gap >= 1)
	{
		for(int i = 0;i < gap;i++)
		{
			Sort3Insert(begin + i,end,gap);
		}
		gap /= 2;
	}
	return true;
}  
// ԰������
bool Sort3Gardener(int* begin,int* end)
{
	int* p = begin;
	while(p < end - 1)
	{
		while(p < end - 1 && *p <= *(p + 1))
		{
			++p;
		}
		while(p >= begin && *p > *(p + 1) && p < end - 1)
		{
			swap(*p,*(p + 1));
			--p;
		}
	}
	return true;
} 
// ��������
bool Sort4(int* begin,int* end)
{
	if(end - begin <= 1)
	{
		return true;
	}
	int *p1 = begin,*p2 = end - 1;
	while(p1 < p2)
	{
		while(*p1 <= *p2 && p1 < p2)
		{
			++p1;
		}
		swap(*p1,*p2);
		while(*p1 <= *p2 && p1 < p2)
		{
			--p2;
		}
		swap(*p1,*p2);
	}
	Sort4(begin,p2);
	Sort4(p1,end);
	return true;
} 
// �������� ���ѡȡkeyֵ ��������,��ǰ�������δ֪���˷�ʱ�����Ϊ 
bool Sort4Rand(int* begin,int* end)
{
	srand(time(NULL));
	if(end - begin <= 1)
	{
		return true;
	}
	int *p1 = begin,*p2 = end - 1;
	int *key = begin + rand() % (end - begin);
	while(p1 < p2)
	{
		while(*p1 <= *key && p1 < key)
		{
			++p1;
		}
		swap(*p1,*key);
		key = p1;
		while(*p2 >= *key && key < p2)
		{
			--p2;
		}
		swap(*key,*p2);
		key = p2;
	}
	Sort4Rand(begin,key);
	Sort4Rand(key + 1,end);
	return true;
} //*/
// �鲢����
// �ϲ�����
bool Merge(int* begin,int* mid,int* end)
{
    int *array = new int[end - begin + 1]{0},*temp = array;
    int *p1 = begin,*p2 = mid;
    while(p1 < mid && p2 < end)
    {
		*temp = (*p1 < *p2) ? *(p1++) : *(p2++);
		++temp;
	}
	while(p1 < mid || p2 < end)
	{
		*temp = (p1 < mid) ? *(p1++) : *(p2++);
		++temp;
	}
	for(int* p = begin;p < end;p++)
	{
		*p = array[p - begin];
	}
	delete[] array;
	return true;	
} 
bool Sort5(int* begin,int* end)
{
// �ݹ���ֹ 
	if(end - begin <= 1)
	{
		return true;
	}
// �ֿ�		
	int* mid = begin + (end - begin) / 2;
	Sort5(begin,mid);
	Sort5(mid,end);
// �ϲ�
    Merge(begin,mid,end);
	return true;
} 
// �����������ڴ��ģ�������򣬸о���û����ȫ�㶮
// ���������
void adjustHeap(int arr[], int i, int len) 
{
    int temp = arr[i];
    for (int k = 2 * i + 1; k < len; k = 2 * k + 1) 
	{
        if (k + 1 < len && arr[k] < arr[k + 1]) 
		{
            k++;
        }
        if (arr[k] > temp) 
		{
            arr[i] = arr[k];
            i = k;
        } 
		else 
		{
            break;
        }
    }
    arr[i] = temp;
}
bool Sort6(int* begin,int* end)
{
	int len = end - begin;
// ���������
    for (int i = len / 2 - 1; i >= 0; i--) 
	{
        adjustHeap(begin, i, len);
    }	
// ����
    for (int i = len - 1; i > 0; i--) 
	{
        swap(begin[0], begin[i]);
        adjustHeap(begin, 0, i);
    }    
    return true;
} 
// �������� ����
bool Sort7(int* begin,int* end,int max)
{
	int* counter = new int[max]{0};
	for(int* p = begin;p < end;p++)
	{
		++counter[*p];
	}
	int* p = begin;
	for(int i = 0;i < max && p < end;i++)
	{
		while(counter[i] > 0)
		{
			*p = i;
			--counter[i];
			++p;	
		}
	}
	delete[] counter;
	return true;
} 
// �������� ��
// Ѱ�������е������СԪ�� 
int FindM(int* begin,int* end,int& max,int& min)
{
	max = min = *begin;
	for(int* p = begin + 1;p < end;p++)
	{
		if(*p > max) max = *p;
		if(*p < min) min = *p;
	}
	return max - min + 1;
}
// ���򣬷������������鳤�� 
int Sort7Change(int* begin,int* end)
{
	int max,min;
	int FLAGSIZE = FindM(begin,end,max,min);
	bool* flag = new bool[FLAGSIZE]{0};
	for(int* p = begin;p < end;p++) flag[*p - min] = true;
	int* ptr = begin;
	for(bool* p = flag;p < flag + FLAGSIZE;p++) *(ptr++) = p - flag + min;
	delete[] flag;
	return ptr - begin;
} 
// ��������
// �������ռ����������ޣ�0~MAX_SIZE 
void DisCol(int* begin,int* end,int sign)
{
	int f[10][MAX_SIZE] = {0};
	int e[MAX_SIZE] = {0};
	
	int temp = 0;
	for(int* p = begin;p < end;p++)
	{
		temp = *p % sign / (sign / 10);
		f[temp][e[temp]++] = *p;
	}
	int* p = begin;
	for(int i = 0;i < 10;i++)
	{
		for(int j = 0;j < e[i];j++)
		{
			*(p++) = f[i][j];
		}
	}
}
void Sort8(int* begin,int* end)
{
	for(int i = 10;i <= MAX_SIZE;i *= 10)
	{
		DisCol(begin,end,i);
	}
} 
