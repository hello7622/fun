#include "MyString.h"

MyString::MyString(const char * _str): std::string(_str){}

void MyString::push(int index, char ch) {
	index = (index % std::string::length() + std::string::length()) % std::string::length();
	insert(std::string::begin(), ch);
}
char MyString::pop(int index) {
	index = (index % std::string::length() + std::string::length()) % std::string::length();
	char tmp =  std::string::operator[](index);
	erase(std::string::begin() + index);
	return tmp;
}
