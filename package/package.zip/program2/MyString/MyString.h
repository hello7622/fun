#ifndef MYSTRING_H
#define MYSTRING_H

//为了更方便的字符串操作, string扩展
#include <string>

class MyString: public std::string {
	public:
		MyString(const char * _str = nullptr);
		void push(int index, char ch);
		char pop(int index);

		MyString
};

#endif
