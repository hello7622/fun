#ifndef __MYRAND_HPP__
#define __MYRAND_HPP__

#include <random>
int RandInt(int left, int right);
int RandInt(int right);

int RandInt(int left, int right) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dis(left, right);
    return dis(gen);	
}

int RandInt(int right) {
    return RandInt(0, right);	
}

#endif
