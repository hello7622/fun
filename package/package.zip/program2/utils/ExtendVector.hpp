#ifndef __EXTENDVECTOR_HPP__
#define __EXTENDVECTOR_HPP__

#include <vector>
#include <ostream>

template<typename T>
std::ostream& Output(std::ostream& outo, const std::vector<T>& _vector) {
	outo << "[";
	int n = _vector.size();
	if (n <= 0) {
		if (n < 0) {
			outo << "The size exceeds the limit of int";
		}
		outo << "]\n";
		return outo;
	}
	int count = 0;
	for (const auto& elem : _vector) {
		if ((count++) > 0) {
			outo << ", ";
		}
		outo << elem;
	}
	outo << "]\n";
	return outo;
}

template<typename T>
std::ostream& operator<<(std::ostream& outo, const std::vector<T>& _vector) {
	return Output(outo, _vector);
}

template<typename T>
std::vector<T>& Extend(std::vector<T>& _vector, const std::vector<T>& list) {
	for (const T& elem: list) {
		_vector.push_back(elem);
	}
	return _vector;
}

template<typename T>
std::vector<T>& operator+=(std::vector<T>& _vector, const std::vector<T>& list) {
	return Extend(_vector, list);
}

template<typename T>
std::vector<T> operator+(const std::vector<T>& _vector1, const std::vector<T>& _vector2) {
	std::vector<T> ans(_vector1);
	Extend(ans, _vector2);
	return ans;
}

#endif
