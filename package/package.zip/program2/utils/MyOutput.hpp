#ifndef __MYOUTPUT_HPP__
#define __MYOUTPUT_HPP__

// ostream | iostream
template<typename T>
std::ostream& OutputVector(std::ostream& outo, const T& _vector);
template<typename T>
std::ostream& OutputMap(std::ostream& outo, const T& _map);
template<typename T>
std::ostream& operator<<(std::ostream& outo, const std::vector<T> _vector);

template<typename T>
std::ostream& OutputVector(std::ostream& outo, const T& _vector) {
	outo << "[";
	int n = _vector.size();
	if (n <= 0) {
		if (n < 0) {
			outo << "The size exceeds the limit of int";
		}
		outo << "]\n";
		return outo;
	}
	int count = 0;
	for (const auto& elem: _vector) {
		if ((count++) > 0) {
			outo << ", ";
		}
		outo << elem;
	}
	outo << "]\n";
	return outo;
}

template<typename T>
std::ostream& OutputMap(std::ostream& outo, const T& _map) {
	outo << "{";
	int n = _map.size();
	if (n <= 0) {
		if (n < 0) {
			outo << "The size exceeds the limit of int";
		}
		outo << "}\n";
		return outo;
	}
	int count = 0;
	for (const auto item: _map) {
		if ((count++) > 0) {
			outo << ", ";
		}
		outo << item.first << " : " << item.second;
	}
	outo << "}\n";
	return outo;	
}

template<typename T>
std::ostream& operator<<(std::ostream& outo, const std::vector<T> _vector) {
	return OutputVector(outo, _vector);
}

#endif
