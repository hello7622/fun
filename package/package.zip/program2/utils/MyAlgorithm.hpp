#ifndef __MYALGORITHM_HPP__
#define __MYALGORITHM_HPP__

int GCF(int a, int b);
int LCM(int a, int b);

int GCF(int a, int b) {
	if (b == 0) {
		return a;
	}
	return GCF(b, a % b);
}

int LCM(int a, int b) {
	return a / GCF(a, b) * b;
}

bool IsPrime(int n) {
	if (n < 2) {
		return false;
	}
	for (int i = 2; i * i <= n; i++) {
		if (n % i == 0) {
			return false;
		}
	}
	return true;
}

#endif
