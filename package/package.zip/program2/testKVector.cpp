#include "KVector.h"
#include "KVector.cpp"
#include <iostream>
#include <cassert>

void test_construction() {
    KVector<int> v1;
    assert(v1.empty());
    assert(v1.size() == 0);
    
    KVector<int> v2(5, 10);
    assert(v2.size() == 5);
    assert(v2[0] == 10 && v2[4] == 10);
    
    KVector<int> v3 = {1,2,3,4,5};
    assert(v3.size() == 5);
    assert(v3.front() == 1 && v3.back() == 5);
}

void test_push_pop() {
    KVector<int> vec;
    vec.push_back(1);
    vec.push_back(2);
    assert(vec.size() == 2);
    assert(vec[0] == 1 && vec[1] == 2);
    
    vec.pop_back();
    assert(vec.size() == 1);
    assert(vec.back() == 1);
}

void test_iterator() {
    KVector<int> vec{1,2,3,4,5};
    int sum = 0;
    for(auto it = vec.begin(); it != vec.end(); ++it) {
        sum += *it;
    }
    assert(sum == 15);
    
    sum = 0;
    for(auto n : vec) {
        sum += n;
    }
    assert(sum == 15);
}

void test_resize() {
    KVector<int> vec(3, 100);
    vec.resize(5);
    assert(vec.size() == 5);
    assert(vec[3] == 0 && vec[4] == 0);
    
    vec.resize(2);
    assert(vec.size() == 2);
    assert(vec.back() == 100);
}

void test_exceptions() {
    KVector<int> vec;
    bool caught = false;
    try {
        vec.at(0);
    } catch(const std::out_of_range&) {
        caught = true;
    }
    assert(caught);
}

int main() {
    test_construction();
    test_push_pop();
    test_iterator();
    test_resize();
    test_exceptions();
    
    std::cout << "All tests passed!" << std::endl;
    return 0;
}
