#include <iostream>
#include <vector>
#include <string>
#include "common.h"

std::vector<char> CreateChars() {
	std::vector<char> result;
	for (int i = '0'; i <= '9'; i++) {
		result.push_back(i);
	}
	for (int i = 'a'; i <= 'z'; i++) {
		result.push_back(i);
	}
	for (int i = 'A'; i <= 'Z'; i++) {
		result.push_back(i);
	}
	for (const auto& s : "+-*/<=()[]{}:.;' ") {
		result.push_back(s);
	}
	if (result.back() == 0) {
		result.pop_back();
	}
	return result;
}

int main(void) {
	std::cout << CreateChars();
	return 0;
}
