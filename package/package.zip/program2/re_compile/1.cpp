// 字符映射表
#include <map>
#include <vector>
#include <string>
#include <cctype>

std::map<char, int> CharacterMap(const std::vector<char>& _chars) {
    std::map<char, int> result;
    int i = 2;
    for (const auto& each_char: _chars) {
        if (isdigit(each_char)) {
            result[each_char] = 0;
        } else if (isalpha(each_char)) {
            result[each_char] = 1;
        }
        else {
            result[each_char] = i++;
        }
    }
    return result;
}

std::map<std::string, int> WordMap(const std::vector<std::string>& _word_types) {
    std::map<std::string, int> result;
    result["初态"] = 0;
    int i = 1;
    for (const auto& type: _word_types) {
        result[type] = i++;
    }
    return result;
}
