#include <string>
std::string FSA_status[] = {
	"_start",
	"_identifier",
	"_digit",
	"_single_separator",
	"_double_separator",
	"_string_separator",
	"_comment_separator"
};
#include <map>
std::map<std::string, int> status_map = {
	{"_start", 0},
	{"_identifier", 1},
	{"_digit", 2},
	{"_single_separator", 3},
	{"_double_separator", 4},
	{"_string_separator", 5},
	{"_comment_separator", 6}
};
// 3
// 32~127
// 0-000-0000_0000-0-0-00 1+15
struct table_info {
	int to_status;
	char special_case;
	bool is_expect, is_shift_right;
	int is_end;	// 1 ���� 2 ����
};
table_info LoadTableInfo(int _data) {
	return {
		_data << 1 >> 13,
		char(_data << 4 >> 8),
		bool(_data << 12 >> 15),
		bool(_data << 13 >> 15),
		_data & 0x0003
	};
}
int DumpTableInfo(const table_info& _info) {
	return (_info.to_status << 12
	        | _info.special_case << 4
	        | _info.is_expect << 3
	        | _info.is_shift_right << 2
	        | _info.is_end);
}

#include <cctype>
int table[7][96] = {0};

void InitTable() {
	for (int i = 32; i < 128; i++) {
		if (isdigit(i)) {
			table[0][i - 32] = DumpTableInfo({2, 0, 1, 1, 0});
			table[1][i - 32] = DumpTableInfo({1, 0, 1, 1, 0});
		} else if (isalpha(i)) {
			table[0][i - 32] = DumpTableInfo({1, 0, 1, 1, 0});
			table[1][i - 32] = DumpTableInfo({1, 0, 1, 1, 0});
		} else if (isblank(i)) {
			table[0][i - 32] = DumpTableInfo({0, 0, 0, 1, 1});
		}
	}
}

#include <iostream>
void Write(std::ostream& outo, int _table[7][96]) {
	for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 96; j++) {
				if (j) {
					outo << "^";
				}
				outo << _table[i][j];
			}
			outo << "\n";
		}
}
void Read(std::istream& into, int (*_table)[96]) {
	char tmp;
	for (int i = 0; i < 7; i++) {
		for (int j = 0; j < 96; j++) {
			into >> _table[i][j];
			if (!into.eof()) {
				into >> tmp;
			}
		}
	}
}

std::ostream& operator<<(std::ostream& outo, table_info data) {
	outo << "\ntable_info = {"
	     << "\nFSA_status: " << FSA_status[data.to_status]
	     << "\nspecial_case: " << data.special_case
	     << "\nis_expect: " << ((data.is_expect) ? "true" : "false")
	     << "\nis_shift_right: " << ((data.is_shift_right) ? "true" : "false")
	     << "\nis_end: " << ((data.is_end) ? (data.is_end == 1 ? "end" : "error") : "continue")
	     << "\n}\n";
	return outo;
}
#include <fstream>
int main(void) {
	std::cout << LoadTableInfo(5);
//	InitTable();
//	std::ofstream fout("table0.txt");
//	if (fout.is_open()) {
//		Write(fout, table);
//		fout.close();
//	}
	std::ifstream fin("table0.txt");
	if (fin.is_open()) {
		std::cout << "\n---------\n";
		Read(fin, table);
		fin.close();
	}
	Write(std::cout, table);
	return 0;
}
