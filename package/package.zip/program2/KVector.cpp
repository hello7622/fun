#include "KVector.h"

// ==================== 迭代器实现 ====================
template <typename T, typename Allocator>
KVector<T, Allocator>::iterator::iterator(pointer ptr) : m_pPtr(ptr) {}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator::reference 
KVector<T, Allocator>::iterator::operator*() const { 
    return *m_pPtr; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator::pointer 
KVector<T, Allocator>::iterator::operator->() const { 
    return m_pPtr; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator& 
KVector<T, Allocator>::iterator::operator++() { 
    ++m_pPtr; 
    return *this; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::iterator::operator++(int) { 
    iterator tmp = *this; 
    ++m_pPtr; 
    return tmp; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator& 
KVector<T, Allocator>::iterator::operator--() { 
    --m_pPtr; 
    return *this; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::iterator::operator--(int) { 
    iterator tmp = *this; 
    --m_pPtr; 
    return tmp; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::iterator::operator+(difference_type n) const { 
    return iterator(m_pPtr + n); 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::iterator::operator-(difference_type n) const { 
    return iterator(m_pPtr - n); 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator::difference_type 
KVector<T, Allocator>::iterator::operator-(const iterator& other) const { 
    return m_pPtr - other.m_pPtr; 
}

template <typename T, typename Allocator>
bool KVector<T, Allocator>::iterator::operator==(const iterator& other) const { 
    return m_pPtr == other.m_pPtr; 
}

template <typename T, typename Allocator>
bool KVector<T, Allocator>::iterator::operator!=(const iterator& other) const { 
    return m_pPtr != other.m_pPtr; 
}

// ==================== const_iterator实现 ====================
template <typename T, typename Allocator>
KVector<T, Allocator>::const_iterator::const_iterator(pointer ptr) : m_pPtr(ptr) {}

template <typename T, typename Allocator>
KVector<T, Allocator>::const_iterator::const_iterator(iterator it) : m_pPtr(&(*it)) {}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator::reference 
KVector<T, Allocator>::const_iterator::operator*() const { 
    return *m_pPtr; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator::pointer 
KVector<T, Allocator>::const_iterator::operator->() const { 
    return m_pPtr; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator& 
KVector<T, Allocator>::const_iterator::operator++() { 
    ++m_pPtr; 
    return *this; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator 
KVector<T, Allocator>::const_iterator::operator++(int) { 
    const_iterator tmp = *this; 
    ++m_pPtr; 
    return tmp; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator& 
KVector<T, Allocator>::const_iterator::operator--() { 
    --m_pPtr; 
    return *this; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator 
KVector<T, Allocator>::const_iterator::operator--(int) { 
    const_iterator tmp = *this; 
    --m_pPtr; 
    return tmp; 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator 
KVector<T, Allocator>::const_iterator::operator+(difference_type n) const { 
    return const_iterator(m_pPtr + n); 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator 
KVector<T, Allocator>::const_iterator::operator-(difference_type n) const { 
    return const_iterator(m_pPtr - n); 
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator::difference_type 
KVector<T, Allocator>::const_iterator::operator-(const const_iterator& other) const { 
    return m_pPtr - other.m_pPtr; 
}

template <typename T, typename Allocator>
bool KVector<T, Allocator>::const_iterator::operator==(const const_iterator& other) const { 
    return m_pPtr == other.m_pPtr; 
}

template <typename T, typename Allocator>
bool KVector<T, Allocator>::const_iterator::operator!=(const const_iterator& other) const { 
    return m_pPtr != other.m_pPtr; 
}

// ==================== KVector成员函数实现 ====================
template <typename T, typename Allocator>
KVector<T, Allocator>::KVector(const Allocator& alloc) 
    : m_alloc(alloc), m_pData(nullptr), m_nSize(0), m_nCapacity(0) {}

template <typename T, typename Allocator>
KVector<T, Allocator>::KVector(size_type count, const T& value, const Allocator& alloc)
    : m_alloc(alloc), m_pData(nullptr), m_nSize(0), m_nCapacity(0) {
    resize(count, value);
}

template <typename T, typename Allocator>
template <typename InputIt>
KVector<T, Allocator>::KVector(InputIt first, InputIt last, const Allocator& alloc)
    : m_alloc(alloc), m_pData(nullptr), m_nSize(0), m_nCapacity(0) {
    assign(first, last);
}

template <typename T, typename Allocator>
template <typename InputIt>
void KVector<T, Allocator>::assign(InputIt first, InputIt last) {
    clear();
    size_type count = std::distance(first, last);
    reserve(count);
    for (; first != last; ++first) {
        emplace_back(*first);
    }
}

template <typename T, typename Allocator>
KVector<T, Allocator>::KVector(std::initializer_list<T> init, const Allocator& alloc)
    : m_alloc(alloc), m_pData(nullptr), m_nSize(0), m_nCapacity(0) {
    assign(init.begin(), init.end());
}

template <typename T, typename Allocator>
KVector<T, Allocator>::KVector(const KVector& other)
    : m_alloc(std::allocator_traits<Allocator>::select_on_container_copy_construction(other.m_alloc)),
      m_pData(nullptr), m_nSize(0), m_nCapacity(0) {
    reserve(other.m_nSize);
    for (size_type i = 0; i < other.m_nSize; ++i) {
        construct(m_pData + i, other.m_pData[i]);
    }
    m_nSize = other.m_nSize;
}

template <typename T, typename Allocator>
KVector<T, Allocator>::KVector(KVector&& other) noexcept
    : m_alloc(std::move(other.m_alloc)),
      m_pData(other.m_pData),
      m_nSize(other.m_nSize),
      m_nCapacity(other.m_nCapacity) {
    other.m_pData = nullptr;
    other.m_nSize = 0;
    other.m_nCapacity = 0;
}

template <typename T, typename Allocator>
KVector<T, Allocator>::~KVector() {
    clear();
    if (m_pData) {
        m_alloc.deallocate(m_pData, m_nCapacity);
    }
}

template <typename T, typename Allocator>
KVector<T, Allocator>& KVector<T, Allocator>::operator=(const KVector& other) {
    if (this != &other) {
        if (std::allocator_traits<Allocator>::propagate_on_container_copy_assignment::value) {
            m_alloc = other.m_alloc;
        }
        
        if (m_nCapacity >= other.m_nSize) {
            clear();
            for (size_type i = 0; i < other.m_nSize; ++i) {
                construct(m_pData + i, other.m_pData[i]);
            }
            m_nSize = other.m_nSize;
        } else {
            KVector tmp(other);
            swap(tmp);
        }
    }
    return *this;
}

template <typename T, typename Allocator>
KVector<T, Allocator>& KVector<T, Allocator>::operator=(KVector&& other) noexcept {
    if (this != &other) {
        clear();
        if (m_pData) {
            m_alloc.deallocate(m_pData, m_nCapacity);
        }
        
        if (std::allocator_traits<Allocator>::propagate_on_container_move_assignment::value) {
            m_alloc = std::move(other.m_alloc);
        }
        
        m_pData = other.m_pData;
        m_nSize = other.m_nSize;
        m_nCapacity = other.m_nCapacity;
        
        other.m_pData = nullptr;
        other.m_nSize = 0;
        other.m_nCapacity = 0;
    }
    return *this;
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::reference 
KVector<T, Allocator>::operator[](size_type pos) {
    return m_pData[pos];
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_reference 
KVector<T, Allocator>::operator[](size_type pos) const {
    return m_pData[pos];
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::reference 
KVector<T, Allocator>::at(size_type pos) {
    if (pos >= m_nSize) {
        throw std::out_of_range("KVector::at");
    }
    return m_pData[pos];
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_reference 
KVector<T, Allocator>::at(size_type pos) const {
    if (pos >= m_nSize) {
        throw std::out_of_range("KVector::at");
    }
    return m_pData[pos];
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::reference 
KVector<T, Allocator>::front() {
    return m_pData[0];
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_reference 
KVector<T, Allocator>::front() const {
    return m_pData[0];
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::reference 
KVector<T, Allocator>::back() {
    return m_pData[m_nSize - 1];
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_reference 
KVector<T, Allocator>::back() const {
    return m_pData[m_nSize - 1];
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::begin() noexcept {
    return iterator(m_pData);
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator 
KVector<T, Allocator>::begin() const noexcept {
    return const_iterator(m_pData);
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator 
KVector<T, Allocator>::cbegin() const noexcept {
    return const_iterator(m_pData);
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::end() noexcept {
    return iterator(m_pData + m_nSize);
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator 
KVector<T, Allocator>::end() const noexcept {
    return const_iterator(m_pData + m_nSize);
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::const_iterator 
KVector<T, Allocator>::cend() const noexcept {
    return const_iterator(m_pData + m_nSize);
}

template <typename T, typename Allocator>
bool KVector<T, Allocator>::empty() const noexcept {
    return m_nSize == 0;
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::size_type 
KVector<T, Allocator>::size() const noexcept {
    return m_nSize;
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::size_type 
KVector<T, Allocator>::capacity() const noexcept {
    return m_nCapacity;
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::reserve(size_type new_cap) {
    if (new_cap > m_nCapacity) {
        reallocate(new_cap);
    }
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::shrink_to_fit() {
    if (m_nSize < m_nCapacity) {
        reallocate(m_nSize);
    }
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::clear() noexcept {
    for (size_type i = 0; i < m_nSize; ++i) {
        destroy(m_pData + i);
    }
    m_nSize = 0;
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::insert(const_iterator pos, const T& value) {
    return emplace(pos, value);
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::insert(const_iterator pos, T&& value) {
    return emplace(pos, std::move(value));
}

template <typename T, typename Allocator>
template <typename... Args>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::emplace(const_iterator pos, Args&&... args) {
    difference_type offset = pos - cbegin();
    if (m_nSize == m_nCapacity) {
        reserve(m_nCapacity == 0 ? 1 : m_nCapacity * 2);
    }
    
    iterator it = begin() + offset;
    if (it != end()) {
        construct(m_pData + m_nSize, std::move(m_pData[m_nSize - 1]));
        std::move_backward(it, end() - 1, end());
        destroy(&(*it));
    }
    
    construct(&(*it), std::forward<Args>(args)...);
    ++m_nSize;
    return it;
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::erase(const_iterator pos) {
    return erase(pos, pos + 1);
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::iterator 
KVector<T, Allocator>::erase(const_iterator first, const_iterator last) {
    if (first == last) return begin() + (first - cbegin());
    
    iterator dst = begin() + (first - cbegin());
    iterator src = begin() + (last - cbegin());
    
    for (; src != end(); ++src, ++dst) {
        *dst = std::move(*src);
    }
    
    for (iterator it = dst; it != end(); ++it) {
        destroy(&(*it));
    }
    
    m_nSize -= last - first;
    return begin() + (first - cbegin());
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::push_back(const T& value) {
    emplace_back(value);
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::push_back(T&& value) {
    emplace_back(std::move(value));
}

template <typename T, typename Allocator>
template <typename... Args>
typename KVector<T, Allocator>::reference 
KVector<T, Allocator>::emplace_back(Args&&... args) {
    if (m_nSize == m_nCapacity) {
        reserve(m_nCapacity == 0 ? 1 : m_nCapacity * 2);
    }
    construct(m_pData + m_nSize, std::forward<Args>(args)...);
    ++m_nSize;
    return back();
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::pop_back() {
    if (m_nSize > 0) {
        --m_nSize;
        destroy(m_pData + m_nSize);
    }
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::resize(size_type count) {
    resize(count, T());
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::resize(size_type count, const value_type& value) {
    if (count > m_nSize) {
        reserve(count);
        for (size_type i = m_nSize; i < count; ++i) {
            construct(m_pData + i, value);
        }
    } else if (count < m_nSize) {
        for (size_type i = count; i < m_nSize; ++i) {
            destroy(m_pData + i);
        }
    }
    m_nSize = count;
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::swap(KVector& other) noexcept {
    using std::swap;
    swap(m_pData, other.m_pData);
    swap(m_nSize, other.m_nSize);
    swap(m_nCapacity, other.m_nCapacity);
    if (std::allocator_traits<Allocator>::propagate_on_container_swap::value) {
        swap(m_alloc, other.m_alloc);
    }
}

template <typename T, typename Allocator>
typename KVector<T, Allocator>::allocator_type 
KVector<T, Allocator>::get_allocator() const noexcept {
    return m_alloc;
}

// ==================== 私有辅助函数 ====================
template <typename T, typename Allocator>
void KVector<T, Allocator>::construct(pointer p, const T& value) {
    std::allocator_traits<Allocator>::construct(m_alloc, p, value);
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::construct(pointer p, T&& value) {
    std::allocator_traits<Allocator>::construct(m_alloc, p, std::move(value));
}

template <typename T, typename Allocator>
template <typename... Args>
void KVector<T, Allocator>::construct(pointer p, Args&&... args) {
    std::allocator_traits<Allocator>::construct(m_alloc, p, std::forward<Args>(args)...);
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::destroy(pointer p) {
    std::allocator_traits<Allocator>::destroy(m_alloc, p);
}

template <typename T, typename Allocator>
void KVector<T, Allocator>::reallocate(size_type new_capacity) {
    T* new_data = m_alloc.allocate(new_capacity);
    
    size_type i = 0;
    try {
        for (; i < m_nSize; ++i) {
            construct(new_data + i, std::move(m_pData[i]));
        }
    } catch (...) {
        for (size_type j = 0; j < i; ++j) {
            destroy(new_data + j);
        }
        m_alloc.deallocate(new_data, new_capacity);
        throw;
    }
    
    for (size_type j = 0; j < m_nSize; ++j) {
        destroy(m_pData + j);
    }
    
    if (m_pData) {
        m_alloc.deallocate(m_pData, m_nCapacity);
    }
    
    m_pData = new_data;
    m_nCapacity = new_capacity;
}
