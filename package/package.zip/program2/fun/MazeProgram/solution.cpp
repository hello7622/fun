#include<iostream>
#include<queue>

const int MAX_SIZE = 100;					// �Թ����Χ
int maze[MAX_SIZE][MAX_SIZE];				// ��ͼ��Ϣ��0������1���ߣ�2���
const char symbol[4] = "* -";				// ������Ϣ
const int rows = 10;
const int cols = 50; 

void ReadMaze(int row = 6, int col = 10) {
	char ch;
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			std::cin >> ch;
			maze[i][j] = ch - '0';
		}
	}
}
void PrintMaze(int row = 6, int col = 10) {
	system("cls");
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			std::cout << symbol[maze[i][j]];
		}
		std::cout << std::endl;
	}
}
void Solution(int row = 6, int col = 10, int x = 0, int y = 0) {
	std::queue<std::pair<int, int>> path;
	bool flag = 0;
	maze[x][y] = 2;
	path.push(std::make_pair(x, y));
	while (!path.empty()) {
		flag = 0;
		x = path.front().first;
		y = path.front().second;
		path.pop();
		if (x == row - 1 && y == col - 1) break;
		if (x > 1 && maze[x - 1][y] == 1) {
			maze[x - 1][y] = 2;
			path.push(std::make_pair(x - 1, y));
			flag = 1;
		}
		if (y > 1 && maze[x][y - 1] == 1) {
			maze[x][y - 1] = 2;
			path.push(std::make_pair(x, y - 1));
			flag = 1;
		}
		if (x < row - 1 && maze[x + 1][y] == 1) {
			maze[x + 1][y] = 2;
			path.push(std::make_pair(x + 1, y));
			flag = 1;
		}
		if (y < col - 1 && maze[x][y + 1] == 1) {
			maze[x][y + 1] = 2;
			path.push(std::make_pair(x, y + 1));
			flag = 1;
		}
		if (!flag) maze[x][y] = 1;
	}
}
bool findExit(int x, int y, int desX, int desY) {
	// �����ĸ������ƫ�������ϡ��¡�����
	const int directions[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
	// �жϵ�ǰλ���Ƿ�Ϊ����
	if (x == desX && y == desY) {
		std::cout << "�ɹ��ҵ����ڣ�\n";
		return true;
	}

	// �����ĸ�����
	for (int i = 0; i < 4; ++i) {
		int newX = x + directions[i][0];
		int newY = y + directions[i][1];

		// �ж���λ���Ƿ�Խ�����Ϊǽ
		if (newX >= 0 && newX < rows && newY >= 0 && newY < cols && maze[newX][newY] == 1) {
			// ��ǵ�ǰλ��Ϊ�ѷ���
			maze[x][y] = 2;

			// �ݹ���ã���������
			if (findExit(newX, newY, desX, desY)) {
				return true;
			}
		}
	}

	return false;
}
/*
10000000000000000000000000000000000000000000000000
11111111111111111111111111111111111111111111111110
01000000000000000000000000000000000000000000000010
01000000000000000000000000000000000000000000000010
01000000000000000000000000000000000000000000000010
11111111111111111111111111111111111111111111111110
01000000000000100000000000000000001000000000000000
01111111111110100000000010000000001000000001111111
11101000000001111111111010000000011111111111000010
00100000000000001000000100000000000000000001000011
*/
int main(void) {
	ReadMaze(10, 50);
	PrintMaze(10, 50);
	int flag = findExit(0,0,5,39);
	PrintMaze(10, 50);
	std::cout << flag;
	return 0;
}
