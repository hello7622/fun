#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <tuple>
#include <set>
#include <windows.h>
#include <functional>
#include <sys/stat.h>

std::string ReadAll(std::ifstream& fin);
std::string Split(std::string& str, char delimiter = ' ');
int StringToInt(const std::string& str);
BOOL SetConsoleColor(unsigned int wAttributes = 0x0f);
typedef std::vector<std::string> LineData;
void Traverse(LineData& data, std::function<void(int&, int&)> func, std::function<void()> end_row_func = []() {});
void GetColor(std::vector<std::vector<int>>& color, LineData& data, const std::string& str, std::tuple<int, int> cursor_pos);
void Write(std::ostream& outo, LineData& data, const std::vector<std::vector<int>>& color);
void Search(LineData& data, const std::string& str, std::function<void(int&, int&, int)> func);
void Replace(LineData& data, const std::string& src, const std::string& dest, size_t num = -1);
void Delete(LineData& data, const std::string& src, size_t num = -1);
void AddString(LineData& data, const std::string& str, std::tuple<int, int> cursor_pos);
void MoveCursor(LineData& data, std::tuple<int, int>& cursor_pos, int down_off, int right_off);
void OutputHelp(std::ostream& outo);
bool NoSuchFile(const char * filename);

std::string ReadAll(std::ifstream& fin) {
	std::string ans, tmp;
	while (std::getline(fin, tmp, '\n')) {
		ans += (tmp + "\n");
	}
	return ans;
}

std::string Split(std::string& str, char delimiter) {
	int i = 0, j, ls = str.size();
	for (; i < ls && str[i] == delimiter; i++);
	for (j = i; j < ls && str[j] != delimiter; j++);
	std::string ans = str.substr(i, j - i);
	str = str.substr(j, str.size() - j);
	return ans;
}

int StringToInt(const std::string& str) {
	int ans = 0, i = 0, ls = str.size();
	bool flag = false;
	if (str[i] == '-') {
		flag = true;
		++i;
	}
	for (; i < ls; i++) {
		if (isdigit(str[i])) {
			ans = ans * 10 + (str[i] - '0');
		} else {
			break;
		}
	}
	if (flag) {
		ans = -ans;
	}
	if (i - flag == 0) {
		ans = -1;
	}
	return ans;
}

//字节的高4位控制背景色, 低4位控制前景色
BOOL SetConsoleColor(unsigned int wAttributes) {        //0x0C 黑背亮红前景，0x0E 黑背亮黄前景
	HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hOutput == INVALID_HANDLE_VALUE) {
		return FALSE;
	}
	return SetConsoleTextAttribute(hOutput, wAttributes);
//	0    1     2     3     4      5      6     7     8     9     10   11   12     13     14   15
//	黑，深蓝，暗绿，灰蓝，大红，暗紫红，土黄，灰白，棕灰，海蓝，亮绿，青，橘红，亮紫红，亮黄，白
}

void Traverse(LineData& data, std::function<void(int&, int&)> func, std::function<void()> end_row_func) {
	int i, j, len_rows = data.size();
	for (i = 0; i < len_rows; i++) {
		for (j = 0; j < int(data[i].size()); j++) {
			func(i, j);
		}
		end_row_func();
	}
}

void GetColor(std::vector<std::vector<int>>& color, LineData& data, const std::string& str, std::tuple<int, int> cursor_pos) {
	color.resize(data.size());
	int row_count = color.size();
	for (int i = 0; i < row_count; i++) {
		color[i].resize(data[i].size(), 0x0f);
	}
	Search(data, str, [&](int& i, int& j, int ls) {
		for (int k = j; k < j + ls; k++) {
			color[i][k] &= 0x04;
		}
	});
	int row = std::get<0>(cursor_pos), col = std::get<1>(cursor_pos);
	color[row][col] |= 0x80;
}

void Write(std::ostream& outo, LineData& data, const std::vector<std::vector<int>>& color) {
	int color_last = 0x0f;
	Traverse(data, [&](int i, int j) {
		if (color[i][j] != color_last) {
			color_last = color[i][j];
			SetConsoleColor(color_last);
		}
		outo.put(data[i][j]);
	}, [&]() {
		outo.put('\n');
		SetConsoleColor(0x0f);
	});
}

void Search(LineData& data, const std::string& str, std::function<void(int&, int&, int)> func) {
	int ls = str.size();
	Traverse(data, [&](int& i, int& j) {
		if (!data[i].compare(j, ls, str)) {
			func(i, j, ls);
		}
	});
}

void Replace(LineData& data, const std::string& src, const std::string& dest, size_t num) {
	size_t count = 0;
	int ld = dest.size();
	Search(data, src, [&](int& i, int& j, int ls) {
		if (count++ < num) {
			return ;
		}
		data[i].replace(j, ls, dest);
		j += (ld - 1);
	});
}

void Delete(LineData& data, const std::string& src, size_t num) {
	Replace(data, src, "", num);
}

void AddString(LineData& data, const std::string& str, std::tuple<int, int> cursor_pos) {
	int x = std::get<0>(cursor_pos), y = std::get<1>(cursor_pos);
	data[x].insert(y, str);
}

void MoveCursor(LineData& data, std::tuple<int, int>& cursor_pos, int down_off, int right_off) {
	int row_count = data.size();
	int &x = std::get<0>(cursor_pos), &y = std::get<1>(cursor_pos);
	if (x + down_off >= row_count) {
		x = row_count - 1;
	} else if (x + down_off <= 0) {
		x = 0;
	} else {
		x += down_off;
	}
	if (y + right_off >= int(data[x].size())) {
		y = data[x].size() - 1;
	} else if (y + right_off <= 0) {
		y = 0;
	} else {
		y += right_off;
	}
}

void OutputHelp(std::ostream& outo) {
	outo << "相关指令请参考:\n"
	     << "1.展示 -o\n"
	     << "2.查找 -s str\n"
	     << "3.替换 -r str1 str2 num = -1\n"
	     << "4.删除 -d str\n"
	     << "5.增加 -a str\n"
	     << "6.移动 -m down_off right_off = 0\n"
	     << "  移动光标\n"
	     << "7.帮助 -h\n"
	     << "8.退出 -e\n"
	     << "9.清屏 -c\n";
}

bool NoSuchFile(const char * filename) {
	struct stat statbuf;
	return stat(filename, &statbuf);
}

using namespace std;
int main(void) {
	// 操作文件名
	const char * filename = "file.txt";
	// 存储文本数据
	LineData text;
	// 存储屏幕颜色数据
	vector<vector<int>> color;
	// 存储光标数据
	tuple<int, int> cursor_pos(0, 0);
	// 最大行数
	int max_row_count = 20;
	// 指令集
	set<string> iset = {"-o", "-s", "-r", "-d", "-a", "-m", "-h", "-e", "-c"};

	if (NoSuchFile(filename)) {
		// 创建空文件
		ofstream create(filename);
		if (!create.is_open()) {
			printf("Failure to create %s", filename);
			return 0;
		}
		create.close();
	}

	// 打开读文件
	ifstream fin(filename);
	if (!fin.is_open()) {
		printf("Failure to read %s", filename);
		return 0;
	}

	// 读取数据
	string read_string = ReadAll(fin);
	fin.close();

	// 分割数据
	while (read_string.size()) {
		text.push_back(Split(read_string, '\n'));
	}

	// 行数补齐
	for (int i = text.size(); i < max_row_count; i++) {
		text.push_back("");
	}

//	// Write测试
//	GetColor(color, text, "90", cursor_pos);
//	Write(cout, text, color);

	string itype, tmp;
	int down, right;
	ofstream fout;

	while (true) {
		// 提示输入
		cout << ">> ";
		getline(cin, read_string);

		// 获取指令类型
		itype = Split(read_string);
		// 检查指令正确性
		if (!iset.count(itype)) {
			printf("指令错误\n");
			OutputHelp(cout);
			continue;
		}

		switch (itype[1]) {
			case 'a':
				// 在光标处添加
				AddString(text, Split(read_string), cursor_pos);
				AddString(text, read_string, cursor_pos);
				break;
			case 'c':
				// 清屏
				if (read_string != "") {
					printf("参数过多\n");
					OutputHelp(cout);
				} else {
					system("cls");
				}
				break;
			case 'd':
				// 删除, 双操作数
				Delete(text, Split(read_string), StringToInt(Split(read_string)));
				break;
			case 'e':
				// 保存并退出
				if (read_string != "") {
					printf("参数过多\n");
					OutputHelp(cout);
				} else {
					GetColor(color, text, "", cursor_pos);
					fout.open(filename);
					if (!fout.is_open()) {
						printf("数据保存失败, 请手动保存后退出\n");
						break;
					}
					Write(fout, text, color);
					fout.close();
					// 退出程序
					exit(0);
				}
				break;
			case 'h':
				// 输出帮助
				OutputHelp(cout);
				break;
			case 'm':
				// 移动光标
				down = right = 0;
				if (read_string.size()) {
					down = StringToInt(Split(read_string));
				}
				if (read_string.size()) {
					right = StringToInt(Split(read_string));
				}
				MoveCursor(text, cursor_pos, down, right);
				break;
			case 'o':
				// 输出到屏幕
				GetColor(color, text, "", cursor_pos);
				Write(cout, text, color);
				// 输出到文本文件
				while (read_string.size()) {
					tmp = Split(read_string);
					if (tmp.size()) {
						tmp += ".txt";
						fout.open(tmp);
						if (fout.is_open()) {
							Write(fout, text, color);
							fout.close();
						}
					}
				}
				break;
			case 'r':
				// 替换, 三操作数
				Replace(text, Split(read_string), Split(read_string), StringToInt(Split(read_string)));
				break;
			case 's':
				// 查找, 单操作数
				GetColor(color, text, Split(read_string), cursor_pos);
				Write(cout, text, color);
				break;
			default:
				printf("未知错误\n");
				OutputHelp(cout);
				break;
		}
	}

	return 0;
}
