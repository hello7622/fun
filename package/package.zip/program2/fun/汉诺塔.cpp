#include<iostream>
#include<iomanip>
#include<stack>
#include<cmath>
using namespace std;

//int step = 0;

int H1(char a,char b,char c,int n)
{
	if(n <= 0)
	{
		return 0;
	}
	if(n == 1)
	{
//		cout << a << " -> " << c << endl;
		return 1;
	}
	return H1(a,c,b,n - 1) + H1(a,b,c,1) + H1(b,a,c,n - 1);
}

class Op
{
	char store[3];
	int num;
public:
	Op(char a,char b,char c,int n): store{a,b,c}, num(n) {}
	bool GetABC(char& a,char& b,char& c){
		a = store[0];
		b = store[1];
		c = store[2];
		return true;
	}
	bool SameABC(char a,char b,char c){
		return (a == store[0] && b == store[1] && c == store[2]);
	}
	bool SameNum(int count){
		return (count == num);
	}
	int GetNum(){
		return num;
	}
	char operator[](int n) {
		if(n < 0 || n > 2)
		{
			return '?';
		}
		return store[n];
	}
	Op& operator=(Op& other){
		if(&other == this)
		{
			return* this;
		}
		other.GetABC(store[0],store[1],store[2]);
		num = other.GetNum();
		return* this;
	}
};

int H2(char a,char b,char c,int n)
{
	if(n <= 0)
	{
		return 0;
	}
	stack<Op> cal;
	cal.push(Op(a,b,c,n));
	int step = 0,num = 0;
//	int num = 0;
	char q,w,e;
	while(!cal.empty())
	{
		while((num = cal.top().GetNum()) != 1)
		{
			cal.top().GetABC(q,w,e);
			cal.push(Op(w,q,e,num - 1));
			cal.push(Op(q,'0',e,1));
			cal.push(Op(q,e,w,num - 1));
		}
		while(!cal.empty() && (num = cal.top().GetNum()) == 1)
		{
			cal.top().GetABC(q,w,e);
//			cout << q << "->" << e << endl;
			int count = cal.top().GetNum();
			++step;
			cal.pop();
			while(!cal.empty() && cal.top().SameABC(w,q,e) && !cal.top().SameNum(count))
			{
				cal.top().GetABC(q,w,e);
				count = cal.top().GetNum();
				cal.pop();
			}
		}
	}
	return step;
}

int main(void)
{// 31
	char a[4] = {"abc"};
	int n;
	cin >> n;
	cout << "������\t\t\t�������ٲ���\n";
	for(int i = 0;i <= n;i++)
	{
		cout << setw(4) << i << setw(27) << (1 << i) - 1 << endl;//H1(a[0],a[1],a[2],i) << endl;
	}
//*/
//	cout << H2(a[0],a[1],a[2],5) << endl;	
	return 0;
}
