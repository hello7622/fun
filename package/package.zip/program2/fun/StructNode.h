template<typename T>
struct Node {
	T data;
	Node *prior, *next;
	Node(const T& _data = 0, Node * _prior = nullptr, Node * _next = nullptr)
		: data(_data), prior(_prior), next(_next) {
		if (prior) {
			prior->next = this;
		}
		if (next) {
			next->prior = this;
		}
	}
	~Node() {
		if (prior) {
			prior->next = next;
		}
		if (next) {
			next->prior = prior;
		}
	}
	bool operator==(const T& _data) {
		return (data == _data);
	}
	bool operator==(const Node& other) {
		return (data == other.data);
	}
	bool operator<=(const T& _data) {
		return (data <= _data);
	}
	bool operator<=(const Node& other) {
		return (data <= other.data);
	}
	bool operator<(const T& _data) {
		return (data < _data);
	}
	bool operator<(const Node& other) {
		return (data < other.data);
	}
};
