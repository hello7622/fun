#include "Node.h"

template<typename T>
Node<T>::Node(const T& da)
: data(da), 
  last(nullptr), next(nullptr), 
  parent(nullptr), lchild(nullptr), rchild(nullptr)
{}

template<typename T>
Node<T>::Node(const Node<T>& node)
: data(node.data), 
  last(nullptr), next(nullptr), 
  parent(nullptr), lchild(nullptr), rchild(nullptr)
{}

template<typename T>
Node<T>::~Node()
{}

//����
template<typename T>
Node<T>& Node<T>::operator=(Node<T>& other)
{
	data = other.data;
	return *this;
}

template<typename T>
bool Node<T>::operator==(Node<T>& other)
{
	return (data == other.data);
}

template<typename T>
bool Node<T>::operator<(Node<T>& other)
{
	return (data < other.data);
}

template<typename T>
bool Node<T>::operator>(Node<T>& other)
{
	return (data > other.data);
}

//��Ԫ
template<typename T>
std::istream& operator>>(std::istream& into,Node<T>& node)
{
	into >> node.data;
	return into;
} 

template<typename T>
std::ostream& operator<<(std::ostream& outo,Node<T>& node)
{
	outo << node.data;
	return outo;
} 
