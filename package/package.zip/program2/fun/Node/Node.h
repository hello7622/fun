#ifndef NODE_H
#define NODE_H

#include<iostream>

template<typename T>
struct Node
{
	T data;
	Node<T> *last,*next;
	Node<T> *parent,*lchild,*rchild;
	Node(const T& da);
    Node(const Node<T>& node);
	~Node();
	// ����
	Node<T>& operator=(Node<T>& other);
	bool operator==(Node<T>& other);
	bool operator<(Node<T>& other);
	bool operator>(Node<T>& other);
	// ��Ԫ
	template<typename U>
	friend std::istream& operator>>(std::istream& into,Node<U>& node);
	template<typename U>
	friend std::ostream& operator<<(std::ostream& outo,Node<U>& node);
};

#endif
