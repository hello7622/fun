#include"Node.h"
#include"Node.cpp"
using namespace std;

int main(void)
{
	for(int i = 0;i < 10;i++)
	{
		Node<int> a(i);
		cout << a << ' ';
	}
	return 0;
}
