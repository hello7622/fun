#include<iostream>
using namespace std;

struct LoopNode
{
	int data;
	LoopNode *last,*next;
	LoopNode(int da): data(da), last(this), next(this) {}
	LoopNode(LoopNode& other): data(other.data), last(this), next(this) {}
	LoopNode& operator=(const LoopNode& other)
	{
		if(&other == this)
		{
			return* this;
		}
		data = other.data;
		return* this;
	}
	bool operator==(const LoopNode& other)
	{
		return (data == other.data);
	}
	bool operator<(const LoopNode& other)
	{
		return (data < other.data);
	}
	bool operator>(const LoopNode& other)
	{
		return (data > other.data);
	}
	bool operator<=(const LoopNode& other)
	{
		return (data <= other.data);
	}
	bool operator>=(const LoopNode& other)
	{
		return (data >= other.data);
	}	
	friend bool swap(LoopNode& n1,LoopNode& n2)
	{
		swap(n1.data,n2.data);
		return true;
	}		
};

// �������к����β�n����ʼֵΪ1����ʾ��n��Ԫ�� 
class Loop
{
	private:
		LoopNode* node;
		int count;
	public:
		Loop();
		Loop(initializer_list<int> values);
		Loop(const Loop& other);
		
		~Loop();
		
		bool Insert(int data);								// ��node�ڵ�ǰ����ڵ㣬�ڵ�ֵΪdata 
		bool Insert(int n,int data); 						// ���n��Ԫ��ǰ����ڵ㣬�ڵ�ֵΪdata 
		
		bool Delete(int n);									// ɾ����n���ڵ� 
		bool Delete(LoopNode* other);						// ɾ��ָ����ַ�Ľڵ㣬��Ҫ��� 
		
		int SpeElemValue(int n);							// ��ȡ��n��Ԫ�ص�ֵ 
		int size();											// ��ȡ����Ԫ�ظ��� 
		int length();										// ��ȡ����Ԫ�ظ��� 
		LoopNode* GetNodeAddress();							// Ĭ�ϻ�ȡnode�ڵ��׵�ַ 
		
		bool Modify(int n,int value);						// ����n��Ԫ�ص�ֵ�޸�Ϊvalue 
		
		bool Clear();										// ������� 
		bool swap(Loop& other);								// �������� 
		bool SelectSort();									// ����ѡ�������׽ڵ�Ĭ��Ϊnode
		bool QuickSort();									// �������������׽ڵ�Ĭ��Ϊnode	
};

Loop::Loop(): node(nullptr),count(0) {}
Loop::Loop(initializer_list<int> values): node(nullptr), count(0)
{
	for(const auto& value : values)
	{
		LoopNode* p = new LoopNode(value);
		if(!p)
		{
			cout << "�ڴ����ʧ�ܣ�\n";
			return ;
		}
		if(!node)
		{
			node = p;
		}
		else
		{
			p->last = node->last;
			p->next = node;
			node->last->next = p;
			node->last = p;
		}
		++count;
	}
}
Loop::Loop(const Loop& other): node(nullptr), count(0)
{
	if(!other.node)
	{
		return ;
	}
	for(LoopNode* p = other.node;p->next != other.node;p = p->next)
	{
		LoopNode* temp = new LoopNode(p->data);
		if(!temp)
		{
			cout << "�ڴ����ʧ�ܣ�\n";
			return ;
		}
		if(!node)
		{
			node = temp;
		}
		else
		{
			temp->last = node->last;
			temp->next = node;
			node->last->next = temp;
			node->last = temp;
		}
		++count;		
	}
	if(other.node->next == other.node)
	{
		LoopNode* temp = new LoopNode(other.node->data);
		node = temp;
	}
	else
	{
		LoopNode* temp = new LoopNode(other.node->data);
		temp->last = node->last;
		temp->next = node;
		node->last->next = temp;
		node->last = temp;		
	}
	++count;
}

Loop::~Loop()
{
	if(!node)
	{
		return ;
	}
	LoopNode* p = node,*temp = nullptr;
	while(p->next != node)
	{
		temp = p->next;
		delete p;
		p = temp;
	}
	delete p;
	count = 0;
}

bool Loop::Insert(int data)
{
	LoopNode* p = new LoopNode(data);
	if(!p)
	{
		cout << "�ڴ����ʧ�ܣ�\n";
		return false;
	}
	if(!node)
	{
 	    node = p;
	}
	else
	{
		p->last = node->last;
		p->next = node;
		node->last->next = p;
		node->last = p;
	}
	++count;
	return true;
}
bool Loop::Insert(int n,int data)
{
	LoopNode* temp = new LoopNode(data);
	if(!temp)
	{
		cout << "�ڴ����ʧ�ܣ�\n";
		return false;
	}
	if(!node)
	{
		node = temp;
		return true;
	}
	LoopNode* p = node;
	for(int i = 1;i < n;i++,p = p->next);
	temp->last = p->last;
	temp->next = p;
	p->last->next = temp;
	p->last = temp;
	return true;
}

