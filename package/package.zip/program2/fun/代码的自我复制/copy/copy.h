#ifndef COPY_H
#define COPY_H

#include <sys/stat.h>
#include <direct.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool CreateFolder(const char * folder_name) {
	struct stat statbuf;
	if (stat(folder_name, &statbuf) && _mkdir(folder_name)) {
		perror("Fail to create folder\n");
		return false;
	}
	return true;
}

int GetFileSize(const char *file_name) {
	FILE * file = fopen(file_name, "r");
	if (!file) {
		perror("Fail to read\n");
		return -1;
	}
	fseek(file, 0, SEEK_END);
	int file_size = ftell(file);
	fclose(file);
	return file_size;
}

char * ReadAll(const char * file_name) {
	char * ans = (char*)calloc(GetFileSize(file_name) + 10, sizeof(char));
	char buf[100] = {0};
	FILE * file = fopen(file_name, "r");
	if (!file) {
		perror("Fail to read\n");
		return NULL;
	}
	while (fgets(buf, sizeof(buf), file)) {
		strncat(ans, buf, strlen(buf));
	}
	fclose(file);
	return ans;
}

bool WriteAll(const char * file_name, const char * data) {
	if (!data) {
		perror("No string to write\n");
		return false;
	}
	FILE * file = fopen(file_name, "w");
	if (!file) {
		perror("Fail to write\n");
		return false;
	}
	fprintf(file, data);
	fclose(file);
	return true;
}

#endif
