#include "copy.h"

bool Copy() {
	if (!CreateFolder("copy")) {
		return false;
	}
	
	char * header = ReadAll("copy.h");
	
	if (!WriteAll("copy/copy.h", header)) {
		return false;
	}
	
	if (header) {
		free(header);
		header = NULL;
	} 
	
	char * tmp = ReadAll("main.cpp");
	
	if (!WriteAll("copy/main.cpp", tmp)) {
		return false;
	}
	
	if (tmp) {
		free(tmp);
		tmp = NULL;
	} 
	return true;
}

int main(void) {
	Copy();
	return 0;
}
