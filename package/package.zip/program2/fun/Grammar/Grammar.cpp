#include "Grammar.h"

Element::operator bool() const {
	return isEnd;
}
bool Element::operator==(char ch) {
	return (symbol == ch);
}
bool Element::operator==(char ch) const {
	return (symbol == ch);
}
