#ifndef GRAMMAR_H
#define GRAMMAR_H

#include <utility>
#include <string>

struct Element {
	const char symbol;
	const bool isEnd,isStart;
	operator bool() const;
	bool operator ==(char ch);
	bool operator ==(char ch) const;
};
struct Formula {
	const char left;	// һ���Ƿ��ս�� 
	const std::string right; 
};


#endif
