#include<iostream>
using namespace std;

struct Node
{
	int data;
	Node *prior,*next;
	Node(int da): data(da), prior(nullptr), next(nullptr) {}
	Node(int da,Node* p,Node* n): data(da), prior(p), next(n) {}
}; 
class CircularLink 
{
	Node* head;
	int length;
public:
	CircularLink();
	bool push_front(int data);
	bool push_back(int data);
	bool pop_front(int& data);
	bool pop_back(int& data);
	int front();
	int back();
	int size();
	bool empty();
	~CircularLink(); 
};
CircularLink::CircularLink()
: head(new Node(0)), length(0)
{
	head->prior = head;
	head->next = head;	
}
CircularLink::~CircularLink()
{
	if(head->next == head)
	{
		delete head;
		return ;
	}
	Node *p = head,*temp = p;
	while(p->next != head)
	{
		temp = p;
		p = p->next;
		delete temp;
	}
	delete p;
	return ;
}
bool CircularLink::push_front(int data)
{
	Node* p = new Node(data,head,head->next);
	head->next = p;
	++length;
	return true;
}
bool CircularLink::push_back(int data)
{
	Node* p = new Node(data,head->prior,head);
	head->prior = p;
	++length;
	return true;
}
bool CircularLink::pop_front(int& data)
{
	if(!length)
	{
		cout << "�����գ�\n";
		return false;
	}
	Node* p = head->next;
	data = p->data;
	head->next = p->next;
	p->next->prior = head;
	delete p;
	--length;
	return true;
}
bool CircularLink::pop_back(int& data)
{
	if(!length)
	{
		cout << "�����գ�\n";
		return false;
	}
	Node* p = head->prior;
	data = p->data;
	head->prior = p->prior;
	p->prior->next = head;
	delete p;
	--length;
	return true;
}
int CircularLink::front()
{
	if(!length)
	{
		cout << "�����գ�\n";
		return 0;
	}
	return head->next->data;
}
int CircularLink::back()
{
	if(!length)
	{
		cout << "�����գ�\n";
		return 0;
	}
	return head->prior->data;
}
int CircularLink::size()
{
	return length;
}
bool CircularLink::empty()
{
	return !length;
}
