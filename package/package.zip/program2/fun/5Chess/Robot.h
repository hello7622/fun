#ifndef Robot_h
#define Robot_h

#include<iostream>
#include"Chess.h"

class Robot: virtual public Chess
{
	private:
		int x,y; 
		int num,offset,ch;  	
	public:
		int RobotTurn(int flag);
};

int Robot::RobotTurn(int flag)
{
    const int directions[4][2] = {{0, 1}, {1, 0}, {-1, 1}, {1, 1}};
    const char dirSymbols[4] = {'h', 's', 'p', 'n'};
	
	num = offset = ch = 0;
OTHER:		
	if(num != 0)
	{
		int i = 0;
		for(;i < 4 || dirSymbols[i] != ch;i++);
		int dx = directions[i][0];
		int dy = directions[i][1];
		for(int j = 0;j < 5;j++)
		{
			x = last.X + (offset + j) * dx;
			y = last.Y + (offset + j) * dy;	
			if(Out(x,y))
			{
				for(;offset >= -4;offset--)
				{
					x = last.X + (offset + j) * dx;
					y = last.Y + (offset + j) * dy;	
					if(Out(x,y))
					{
						goto OWN;
					}	
					if(empty(x,y))
					{
						DropChess(x,y,flag);
						return Win(num,offset,ch);
					}
				}
				goto OWN;
			}
			
			if(empty(x,y))
			{
				DropChess(x,y,flag);
				return Win(num,offset,ch);
			}
		}
	}
	
OWN:
	srand(time(NULL));
	do
	{
		x = rand() % 13 + 1;
		Sleep(1);
		y = rand() % 13 + 1;			
	}while(!empty(x,y));
	DropChess(x,y,flag);
	return Win(num,offset,ch);		
}

#endif  /* Robot.h */
