#ifndef Player_h
#define Player_h

#include<iostream>
#include"Chess.h"

class Player: virtual public Chess
{
	private:
 	    int x,y;	
	public:
		int PlayerTurn(int flag);
};

int Player::PlayerTurn(int flag)
{
	do
	{
		Gotoxy(0,30);	
		std::cout << "              ";
		Gotoxy(0,30);
		std::cout << "���룺";
		std::cin >> x >> y;		
	}while(std::cin.fail() || !empty(x,y));	
	
	DropChess(x,y,flag);
	int r;
	return Win(r,r,r);
}

#endif  /* Player.h */
