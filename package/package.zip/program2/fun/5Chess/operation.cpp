#include<iostream>
#include"Game.h"
using namespace std;

int main(void)
{
//	Game game;
	for(int i = 0;i < 100;i++)
	{
		Game game;
		game.Play();
		Sleep(500);
	}
//	game.Play();
	return 0;
}
