#include <random>

int RandInt(int right, int left = 0) {
	std::random_device rd;
	std::mt19937 gen(rd());
	std::uniform_int_distribution<int> dis(left, right);
	return dis(gen);
}

#include <windows.h>

void Gotoxy(int x, int y) {
	COORD pos;
	pos.X = y;
	pos.Y = x;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void HideCursor(void) {
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(handle, &CursorInfo);
	CursorInfo.bVisible = 0;
	SetConsoleCursorInfo(handle, &CursorInfo);
}

struct Pos {
	Pos(int _x = 0, int _y = 0)
		: x(_x)
		, y(_y) {

	}
	Pos operator+(const Pos& _pos) {
		return Pos(x + _pos.x, y + _pos.y);
	}
	Pos& operator+=(const Pos& _pos) {
		x += _pos.x;
		y += _pos.y;
		return *this;
	}
	bool operator<(const Pos& _pos) {
		return x < _pos.x && y < _pos.y;
	}
	bool operator==(const Pos& _pos) {
		return x == _pos.x && y == _pos.y;
	}
	int x, y;
};

struct Map {
	Map(int _height = 10, int _width = 20)
		: bodyLen(4)
		, maxLen(_height * _width)
		, snakeHead(_height / 2, _width / 2)
		, fruit(RandInt(_height - 1), RandInt(_width - 1))
		, upLeft(-1, -1)
		, downRight(_height, _width)
		, dir(0, 0)
		, map(new int[maxLen]) {
		int i = 0;
		while (i < maxLen) {
			map[i++] = 0;
		}
		map[snakeHead.x * downRight.y + snakeHead.y] = bodyLen;
	}
	Map(const Pos& _para)
		: Map(_para.x, _para.y) {

	}
	~Map() {
		if (map) {
			delete[] map;
		}
	}
	bool Update() {
		bool flag = false;
		snakeHead += dir;
		if (snakeHead == fruit) {
			UpdateLen();
			fruit = Pos(RandInt(downRight.x - 1), RandInt(downRight.y - 1));
			flag = true;
		}
		return flag;
	}
	inline void UpdateLen() {

	}
	void ShowMap() {
		Gotoxy(0, 0);
		int i, j;
		for (i = 0; i < downRight.x; i++) {
			for (j = 0; j < downRight.y; j++) {
				OutputIcon(i, j);
			}
			printf("|\n");
		}
		printf("bodyLen=%d", bodyLen);
	}
	void SetDir() {
		int difX = fruit.x - snakeHead.x, difY = fruit.y - snakeHead.y;
		int step = 1;
		dir = Pos((difX >> step) | (!!difX), (difY >> step) | (!!difY));
	}
	void OutputIcon(int x, int y) {
		Pos pos(x, y);
		int index = x * downRight.y + y;
		if (pos == snakeHead) {
			putchar('O');
			map[index] = bodyLen;
		} else if (pos == fruit) {
			putchar('x');
		} else if (map[index]) {
			putchar('o');
			--map[index];
		} else {
			putchar(' ');
		}
	}
	int bodyLen, maxLen;
	Pos snakeHead, fruit, upLeft, downRight, dir;
	int *map;
};

//#include <conio.h>
// 一条先快后慢的小蛇
int main() {
//	getch();
	HideCursor();
	Pos test1(35, 80), test2(42, 135);
	Map map(test1);
	map.ShowMap();
	while (1) {
		map.SetDir();
		map.Update();
		map.ShowMap();
//		if (kbhit()) {
//			getch();
//			HideCursor();
//			getch();
//		}
	}
	return 0;
}
