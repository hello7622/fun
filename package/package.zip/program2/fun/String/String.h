#ifndef __LIN_STRING_H__
#define __LIN_STRING_H__

#include <cstddef>
#include <ostream>

class String {
    public:
        String(const char * str = nullptr, size_t len = -1);
        String(const String & other, size_t len = -1);
        ~String();
        String& operator=(const String& other);
        size_t size() const;
        class Iterator {
            public:
                Iterator(char * _ptr);
                char& operator*();
                Iterator& operator++();
                Iterator operator++(int);
                bool operator==(const Iterator& other);
                bool operator!=(const Iterator& other);
            private:
                char * _ptr;
        };
        Iterator begin();
        Iterator end();
        void push(char c, size_t pos = -1);
        void pop(size_t pos = -1);
        char& operator[](size_t pos);
        const char& operator[](size_t pos) const;
        String operator+(const String& other) const;
        String& operator+=(const String& other);
        String& operator+=(const char * str);
        String& operator+=(char c);
        String slice(size_t begin, size_t end) const;
        String operator()(size_t begin, size_t end) const;
        String reverse() const;
        String operator*(int num) const;
        String& operator*=(int num);
        friend std::ostream& operator<<(std::ostream& os, const String& str);
    protected:
        inline void reallocate(size_t new_capacity);
    private:
        char * ptr;
        size_t length, capacity;
};

#endif // __LIN_STRING_H__