#include "LinkList.h"
#include <iostream>

template<typename T>
LinkNode<T>::LinkNode(T _val, LinkNode * _prior, LinkNode * _next)
	: val(_val)
	, prior(_prior)
	, next(_next) {}
template<typename T>
LinkNode<T>* LinkNode<T>::AddNode(const T& _val) {
	LinkNode<T> * p = new LinkNode<T>(_val, this, this->next);
	if (this->next) {
		this->next->prior = p;
	}
	this->next = p;
	return this;
}
template<typename T>
bool LinkNode<T>::operator==(const LinkNode& other) {
	return val == other.val;
}
template<typename T>
bool LinkNode<T>::operator==(const T& _val) {
	return val == _val;
}
template<typename T>
LinkNode<T>::~LinkNode() {
	if (this->prior) {
		this->prior->next = this->next;
	}
	if (this->next) {
		this->next->prior = this->prior;
	}
}
template<typename T>
void LinkNode<T>::DestroyBackNode(LinkNode * node) {
	if (node->next) {
		DestroyBackNode(node->next);
		delete node->next;
	}
}

template<typename T>
LinkList<T>::LinkList(): head(new LinkNode<T>), tail(head), len(0) {}
template<typename T>
LinkList<T>::LinkList(const std::initializer_list<T>& list): head(new LinkNode<T>), tail(head), len(0) {
	for (const auto& val : list) {
		append(val);
	}
}
template<typename T>
LinkList<T>::LinkList(const LinkList<T>& other): head(new LinkNode<T>), tail(head), len(0) {
	for (const T& val : other) {
		append(val);
	}
}
template<typename T>
LinkList<T>::LinkList(const int& num, const T& val): head(new LinkNode<T>), tail(head), len(0)  {
	for (int i = 0; i < num; i++) {
		append(val);
	}
}
template<typename T>
LinkList<T>::~LinkList() {
	clear();
	delete head;
}
template<typename T>
void LinkList<T>::clear() {
	while (head->next) {
		delete head->next;
	}
	tail = head;
	len = 0;
}
template<typename T>
LinkList<T>& LinkList<T>::operator=(const LinkList<T>& other) {
	if (*this == other) {
		return *this;
	}
	clear();
	for (const T& val : other) {
		append(val);
	}
	return *this;
}
template<typename T>
bool LinkList<T>::operator==(const LinkList<T>& other) {
	LinkNode<T> * ptr = head;
	for (const T& val : other) {
		if (ptr->next == nullptr) {
			return false;
		}
		if (ptr->next->val != val) {
			return false;
		}
		ptr = ptr->next;
	}
	if (ptr->next) {
		return false;
	}
	return true;
}
template<typename T>
void LinkList<T>::append(const T& val) {
	tail->AddNode(val);
	tail = tail->next;
	++len;
}
template<typename T>
void LinkList<T>::remove(const T& val) {
	LinkNode<T> * ptr = head;
	for (; ptr->next; ptr = ptr->next) {
		if (ptr->next->val == val) {
			break;
		}
	}
	if (ptr->next) {
		if (tail == ptr->next) {
			tail = ptr;
		}
		delete ptr->next;
		--len;
	}
}
template<typename T>
int LinkList<T>::size() const {
	return len;
}
template<typename T>
int LinkList<T>::length() const {
	return len;
}
template<typename T>
int LinkList<T>::count(const T& val) const {
	int c = 0;
	for (LinkNode<T> * ptr = head; ptr->next; ptr = ptr->next) {
		if (ptr->next->val == val) {
			++c;
		}
	}
	return c;
}
template<typename T>
T& LinkList<T>::front() const {
	if (head->next) {
		return head->next->val;
	}
	return head->val;
}
template<typename T>
T& LinkList<T>::back() const {
	return tail->val;
}
template<typename T>
LinkList<T>& LinkList<T>::operator<<(const T& val) {
	append(val);
	return *this;
}
template<typename T>
typename LinkList<T>::Iterator LinkList<T>::begin() const {
	return Iterator(head);
}
template<typename T>
typename LinkList<T>::Iterator LinkList<T>::end() const {
	return Iterator(tail);
}
template<typename T>
void LinkList<T>::append(const T& val, const Iterator& pos) {
	pos.cur->AddNode(val);
	if (pos.cur == tail) {
		tail = tail->next;
	}
	++len;
}
template<typename T>
void LinkList<T>::remove(const Iterator& pos) {
	LinkNode<T> * ptr = pos.cur;
	if (ptr->next) {
		if (ptr->next == tail) {
			tail = ptr;
		}
		delete ptr->next;
		--len;
	}
}
template<typename T>
void LinkList<T>::extend(const LinkList<T>& list) {
	for (const T& val: list) {
		append(val);
	}
}
template<typename T>
LinkList<T> LinkList<T>::operator+(const LinkList<T>& list) {
	LinkList<T> ans(*this);
	ans.extend(list);
	return ans;
}
template<typename T>
LinkList<T>& LinkList<T>::operator+=(const LinkList<T>& list) {
	extend(list);
	return *this;
}
template<typename T>
typename LinkList<T>::Iterator LinkList<T>::find(const T& val) {
	for (LinkNode<T> * ptr = head; ptr->next; ptr = ptr->next) {
		if (ptr->next->val == val) {
			return Iterator(ptr);
		}
	}
	return end();
}
template<typename T>
LinkList<T>::Iterator::Iterator(LinkNode<T> * ptr): cur(ptr) {}
template<typename T>
LinkList<T>::Iterator::Iterator(const Iterator& other): cur(other.cur) {}
template<typename T>
T& LinkList<T>::Iterator::operator*() {
	if (cur->next) {
		return cur->next->val;
	}
	return cur->val;
}
template<typename T>
typename LinkList<T>::Iterator& LinkList<T>::Iterator::operator++() {
	if (cur->next) {
		cur = cur->next;
	}
	return *this;
}
template<typename T>
typename LinkList<T>::Iterator& LinkList<T>::Iterator::operator--() {
	if (cur->prior) {
		cur = cur->prior;
	}
	return *this;
}
template<typename T>
typename LinkList<T>::Iterator LinkList<T>::Iterator::operator+(int off) {
	LinkNode<T> * ptr = cur;
	while ((off--) > 0 && ptr->next) {
		ptr = ptr->next;
	}
	return Iterator(ptr);
}
template<typename T>
typename LinkList<T>::Iterator LinkList<T>::Iterator::operator-(int off) {
	LinkNode<T> * ptr = cur;
	while ((off--) > 0 && ptr->prior) {
		ptr = ptr->prior;
	}
	return Iterator(ptr);
}
template<typename T>
bool LinkList<T>::Iterator::operator==(const Iterator& other) {
	return cur == other.cur;
}
template<typename T>
bool LinkList<T>::Iterator::operator!=(const Iterator& other) {
	return cur != other.cur;
}
