#include <vector>
typedef std::vector<std::vector<int>> Matrix;
#include <windows.h>
void Gotoxy(int x, int y) {
	COORD pos;
	pos.X = y;
	pos.Y = x;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
#include <iostream>
#include <fstream>
class LifeGame {
		const char * status;
		Matrix map, initData;
		int updateNum;
		bool end;
	public:
		LifeGame(const Matrix& data = {{10, 10}, {5, 5}})
			: status("+#")
			, map(data[0][0], std::vector<int>(data[0][1], 0))
			, initData(data)
			, updateNum(0)
			, end(false) {
			for (int i = 1; i < int(data.size()); i++) {
				map[data[i][0]][data[i][1]] = 1;
			}
		}
		bool UpdateLifeMatrix() {
			if (end) {
				return false;
			}
			int m = map.size(), n = map[0].size();
			Matrix record(m, std::vector<int>(n, 0)), last = map;
			int i, j;
			for (i = 0; i < m; i++) {
				for (j = 0; j < n; j++) {
					if (i > 0) {
						if (j > 0) {
							record[i - 1][j - 1] += map[i][j];
						}
						if (j < n - 1) {
							record[i - 1][j + 1] += map[i][j];
						}
						record[i - 1][j] += map[i][j];
					}
					if (i < m - 1) {
						if (j > 0) {
							record[i + 1][j - 1] += map[i][j];
						}
						if (j < n - 1) {
							record[i + 1][j + 1] += map[i][j];
						}
						record[i + 1][j] += map[i][j];
					}
					if (j > 0) {
						record[i][j - 1] += map[i][j];
					}
					if (j < n - 1) {
						record[i][j + 1] += map[i][j];
					}
				}
			}
			for (i = 0; i < m; i++) {
				for (j = 0; j < n; j++) {
					switch (record[i][j]) {
						case 2:
							break;
						case 3:
							map[i][j] = 1;
							break;
						default:
							map[i][j] = 0;
							break;
					}
				}
			}
			++updateNum;
			if (last == map || last == Matrix(m, std::vector<int>(n, 0))) {
				end = true;
			}
			return true;
		}
		void Output() const {
			Gotoxy(0, 0);
			std::cout << "---------------" << updateNum << "---------------\n";
			for (const auto& rows : map) {
				for (const auto& elem : rows) {
					putchar(status[elem]);
				}
				putchar('\n');
			}
			std::cout << "---------------------------------------------\n";
		}
		std::vector<int> size() const {
			return {int(map.size()), int(map[0].size())};
		}
		int UpdateCount() const {
			return updateNum;
		}
		~LifeGame() {
			std::ofstream fout("LifeGame.txt", std::ios::app);
			if (fout.is_open()) {
				fout << "(" << initData[0][0] << "," << initData[0][1] << ")_" << initData.size() - 1 << "\n";
				for (int i = 1; i < int(initData.size()); i++) {
					if (i > 1) {
						fout << "_";
					}
					fout << "(" << initData[i][0] << "," << initData[i][1] << ")";
				}
				fout << "\n(" << initData[0][0] << "," << initData[0][1] << ")_" << updateNum << "\n";
				fout.close();
			}
		}
};

#include <random>
// {x: int | min <= x <= max}
std::vector<int> RandList(int min, int max, int num) {
	// 设置随机数种子，可以使用当前时间
	std::random_device rd;
	std::mt19937 gen(rd());

	// 创建一个存储随机数的容器
	std::vector<int> random_numbers;

	// 定义均匀整数分布
	std::uniform_int_distribution<int> dist(min, max);

	// 生成随机数序列
	while (num-- > 0) {
		random_numbers.push_back(dist(gen));  // 将随机数存入容器
	}
	return random_numbers;
}

#include <windows.h>
void HideCursor(void) { //隐藏光标,避免闪烁现象
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(handle, &CursorInfo);         //获得控制台光标信息
	CursorInfo.bVisible = 0;                           //隐藏控制台光标
	SetConsoleCursorInfo(handle, &CursorInfo);         //设置控制台光标状态
}

#include <functional>
void PlayGame(const std::vector<int>& mapSize, int playCount, std::function<bool(const LifeGame& g)> func) {
	while (playCount-- > 0) {
		int posCount = 10;
		Matrix initData(1 + posCount, mapSize);
		int x = mapSize[0], y = mapSize[1];
		auto X = RandList(x / 2 - 2, x / 2 + 2, posCount), Y = RandList(y / 2 - 2, y / 2 + 2, posCount);
		for (int i = 0; i < posCount; i++) {
			initData[i + 1] = {X[i], Y[i]};
		}

		LifeGame game(initData);
		if (func(game)) {
			return ;
		}
		while (game.UpdateLifeMatrix()) {
			if (func(game)) {
				return ;
			}
		}
	}
}
#include <conio.h>
using namespace std;
int main() {
	HideCursor();
	vector<int> size = {20, 40};
	PlayGame(size, 2, [](const LifeGame & game) {
		game.Output();
//		Sleep(100);
		if (kbhit()) {
			return true;
		}
		return false;
	});
	return 0;
}
