#ifndef __LINKLIST_H__
#define __LINKLIST_H__

template<typename T>
struct LinkNode {
	T val;
	LinkNode *prior, *next;
	LinkNode(T _val = T(),
	         LinkNode<T> * _prior = nullptr,
	         LinkNode<T> * _next = nullptr);
	LinkNode<T>* AddNode(const T& _val);
	bool operator==(const LinkNode<T>& other);
	bool operator==(const T& _val);
	~LinkNode();
	static void DestroyBackNode(LinkNode<T> * node);
};

#include <initializer_list>
template<typename T>
class LinkList {
	public:
		LinkList();
		LinkList(const std::initializer_list<T>& list);
		LinkList(const LinkList<T>& other);
		LinkList(const int& num, const T& val = T());
		~LinkList();
		void clear();
		LinkList<T>& operator=(const LinkList<T>& other);
		bool operator==(const LinkList<T>& other);
		void append(const T& val);
		void remove(const T& val);
		int size() const;
		int length() const;
		int count(const T& val) const;
		T& front() const;
		T& back() const;
		LinkList<T>& operator<<(const T& val);
		class Iterator {
			public:
				friend class LinkList;
				Iterator(LinkNode<T> * ptr);
				Iterator(const Iterator& other);
				T& operator*();
				Iterator& operator++();
				Iterator& operator--();
				Iterator operator+(int off);
				Iterator operator-(int off);
				bool operator==(const Iterator& other);
				bool operator!=(const Iterator& other);
			private:
				LinkNode<T> * cur;
		};
		Iterator begin() const;
		Iterator end() const;
		void append(const T& val, const Iterator& pos);
		void remove(const Iterator& pos);
		void extend(const LinkList<T>& list);
		LinkList<T> operator+(const LinkList<T>& list);
		LinkList<T>& operator+=(const LinkList<T>& list);
		Iterator find(const T& val);
	private:
		LinkNode<T> *head, *tail;
		int len;
};

#endif
