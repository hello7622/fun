#include <stdio.h>
int main()
{
	int n;
	double a;
	int arr[2000000] = { 0 };
	int s;
	int t;
	scanf("%d", &n);
	int i, j;
	for (i = 0; i < n; i++)
	{
		scanf("%lf", &a);
		scanf("%d", &t);
		for (j = 1; j <= t; j++)
		{
			s =int( a * j);
			arr[s-1] = 1 - arr[s-1];
		}

	}
	for (j = 0;; j++)
	{
		if (arr[j] == 1)
		{
			printf("%d\n", j + 1);
			return 0;
		}
	}
	return 0;
}
