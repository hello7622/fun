#include <windows.h>	// -> MoveConsoleCursor & HideCursor & SetConsoleColor
#include <stdio.h>		// -> DisplayMonth
#include <time.h>		// -> GetCurTime

void MoveConsoleCursor(int x, int y);
void HideConsoleCursor();
BOOL SetConsoleColor(unsigned int wAttributes);
// 字节的高4位控制背景色，低4位控制前景色
// 0-黑     1-深蓝      2-暗绿  3-灰蓝
// 4-大红   5-暗紫红    6-土黄  7-灰白
// 8-棕灰   9-海蓝      a-亮绿  b-青
// c-橘红   d-亮紫红    e-亮黄  f-白

const int monthDays[][13] = {
	{0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
	{0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
};	// -> IsLegalDate & DifferenceDayCount
const int yearDays[] = {365, 366};	// -> DifferenceDayCount
const char * weeks[] = {"一", "二", "三", "四", "五", "六", "日"};	// -> DisplayMonth

int IsLeapYear(int year);	// -> IsLeagalDate & DifferenceDayCount
int IsLegalDate(int year, int month, int day);			
int DifferenceDayCount(int year, int month, int day);	// 19000101Mon-
void DisplayMonth(int weekIndex, int dayCount);
void GetCurTime(int date[]);

int main() {
	int date[] = {0, 0, 0, 0, 0, 0};
	GetCurTime(date);
	int year = 2024, month = 11, day = 31;
	int weekIndex = DifferenceDayCount(year, month, 1) % 7;
	int dayCount = monthDays[IsLeapYear(year)][month];
	DisplayMonth(weekIndex, dayCount);
	printf("\n%s", weeks[DifferenceDayCount(year, month, day) % 7]);
	return 0;
}

void MoveConsoleCursor(int x, int y) { 
	COORD pos;
	pos.X = y;
	pos.Y = x;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void HideConsoleCursor() { 
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(handle, &CursorInfo);         //获得控制台光标信息
	CursorInfo.bVisible = 0;                           //隐藏控制台光标
	SetConsoleCursorInfo(handle, &CursorInfo);         //设置控制台光标状态
}

BOOL SetConsoleColor(unsigned int wAttributes) { 
	HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	if (hOutput == INVALID_HANDLE_VALUE) {
		return FALSE;
	}
	return SetConsoleTextAttribute(hOutput, wAttributes);
}

int IsLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int IsLegalDate(int year, int month, int day) {
	if (year < 1900 || month < 1 || month > 12 || day < 1) {
		return 0;
	}
	int isLeap = IsLeapYear(year);
	if (day > monthDays[isLeap][month]) {
		return 0;
	}
	return 1;
}

// 19000101Mon-
int DifferenceDayCount(int year, int month, int day) {
	int y, m, isLeap;
	int diff = 0;
	for (y = 1900; y < year; y++) {
		isLeap = IsLeapYear(y);
		diff += yearDays[isLeap];
	}
	isLeap = IsLeapYear(year);
	for (m = 1; m < month; m++) {
		diff += monthDays[isLeap][m];
	}
	diff += day - 1;
	return diff;
}

void DisplayMonth(int weekIndex, int dayCount) {
	// system("cls");
	int i, d;
	for (i = 0; i < 7; i++) {
		printf("%s\t", weeks[i]);
	}
	printf("\n");
	for (i = 0; i < weekIndex; i++) {
		printf("  \t");
	}
	for (d = 1; d <= dayCount; d++) {
		printf("%02d\t", d);
		if ((++i) % 7 == 0) {
			printf("\n");
		}
	}
	printf("\n");
}

void GetCurTime(int date[]) {
	// 获取当前时间
    time_t now = time(NULL);
    // 将时间转换为本地时间
    struct tm *local_time = localtime(&now);

	date[0] = local_time->tm_year + 1900;
	date[1] = local_time->tm_mon + 1;
	date[2] = local_time->tm_mday;
	date[3] = local_time->tm_hour;
	date[4] = local_time->tm_min;
	date[5] = local_time->tm_sec;
}
