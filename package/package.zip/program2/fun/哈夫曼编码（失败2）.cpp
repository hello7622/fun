#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
using namespace std;

struct Node {
	char value;
	int weigh;
	Node *lchild, *rchild;
	Node(): value(0), weigh(0), lchild(nullptr), rchild(nullptr) {}
	Node(char ch, int da): value(ch), weigh(da), lchild(nullptr), rchild(nullptr) {}
	Node(char ch, int da, Node* l, Node* r): value(ch), weigh(da), lchild(l), rchild(r) {}
	Node(const Node& other): value(other.value), weigh(other.weigh), lchild(other.lchild), rchild(other.rchild) {}
	Node& operator=(const Node& other) {
		if (this == &other) return* this;
		value = other.value;
		weigh = other.weigh;
		lchild = other.lchild;
		rchild = other.rchild;
		return* this;
	}
	bool operator<(const Node& other) {
		return (weigh < other.weigh);
	}
	bool operator>(const Node& other) {
		return (weigh > other.weigh);
	}
	bool operator==(const Node& other) {
		return (weigh == other.weigh);
	}
	bool operator>=(const Node& other) {
		return (weigh >= other.weigh);
	}
	bool operator<=(const Node& other) {
		return (weigh <= other.weigh);
	}
};
struct BuildTree {
		Node* create(vector<Node*> array) {
			Node *p1 = nullptr, *p2 = nullptr, *p = nullptr;
			while (!array.empty()) {
				sort(array.begin(), array.end());
				if (array.empty()) break;
				p1 = array.front();
				array.erase(array.begin());
				if (array.empty()) break;
				p2 = array.front();
				array.erase(array.begin());
				p = merge(p1, p2);
				array.push_back(p);
			}
			return p1;
		}
	protected:
		Node* merge(Node* p1, Node* p2) {
			Node* left = (p1->weigh < p2->weigh) ? p1 : p2;
			Node* right = (p1->weigh < p2->weigh) ? p2 : p1;
			Node* p = new Node(0, p1->weigh + p2->weigh, left, right);
			return p;
		}
};
class Code {
		string str;
		string code[128], temp;
		int letter[128];
	public:
		Code(string p): str(p), code{0}, temp{"0"}, letter{0} {}
		void Coder() {
			for (int i = 0; i < int(str.size()); i++) ++letter[int(str[i])];	// ͳ���ַ�����
			vector<Node*> array;
			for (int i = 0; i < 128; i++) {
				if (letter[i] > 0) array.push_back(new Node(char(i), letter[i]));
			}
			BuildTree build;
			TraverTree(build.create(array), 0);
		}
		string GetChar(char ch) {
			return code[int(ch)];
		}
		void Output() {
			for (int i = 0; i < int(str.size()); i++) cout << code[int(str[i])];
			cout << endl;
		}
	protected:
		void TraverTree(Node* head, int count = 0) {
			if (!head) return ;
			if (head->value) code[int(head->value)] = temp;
			else --count;
			temp[count + 1] = '0';
			TraverTree(head->lchild, count + 1);
			temp[count + 1] = '1';
			TraverTree(head->rchild, count + 1);
		}
};

int main(void)
{
	string str;
	cin >> str;
	Code code(str);
	code.Coder();
	code.Output();
	return 0;
}
