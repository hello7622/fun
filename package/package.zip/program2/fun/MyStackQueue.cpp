#include "StructNode.h"

#include <vector>
template<typename T>
class MyStack {
		Node<T> * head;
		int num;
	public:
		MyStack(): head(new Node<T>), num(0) {}
		bool push(const T& data) {
			if (new Node<T>(data, head, head->next)) {
				++num;
				return true;
			}
			return false;
		}
		bool pop() {
			if (num) {
				delete head->next;
				--num;
				return true;
			}
			return false;
		}
		bool empty() {
			return (!num);
		}
		T top() {
			if (num) {
				return head->next->data;
			}
			return -1;
		}
		std::vector<T> list() {
			if (!num) {
				return {};
			}
			std::vector<T> list(num);
			Node<T> * ptr = head;
			for (int i = 0; i < num; i++, ptr = ptr->next) {
				list[i] = ptr->next->data;
			}
			return list;
		}
};

template<typename T>
class MyQueue {
		Node<T> *head, *tail;
		int num;
	public:
		MyQueue(): head(new Node<T>), tail(head), num(0) {}
		bool push(const T& data) {
			if (new Node<T>(data, tail)) {
				++num;
				tail = tail->next;
				return true;
			}
			return false;
		}
		bool pop() {
			if (num) {
				if (tail == head->next) {
					tail = head;
				}
				delete head->next;
				--num;
				return true;
			}
			return false;
		}
		bool empty() {
			return (!num);
		}
		T front() {
			if (num) {
				return head->next->data;
			}
			return -1;
		}
		T back() {
			if (num) {
				return tail->data;
			}
			return -1;
		}
		std::vector<T> list() {
			if (!num) {
				return {};
			}
			std::vector<T> list(num);
			Node<T> * ptr = head;
			for (int i = 0; i < num; i++, ptr = ptr->next) {
				list[i] = ptr->next->data;
			}
			return list;
		}
};

#include <iostream>
template<typename T>
std::ostream& operator<<(std::ostream& outo, const std::vector<T>& data) {
	outo << "\nvector = [ ";
	int size = data.size();
	if (size == 0) {
		outo << " ] len = 0\n";
		return outo;
	}
	outo << data[0];
	for (int i = 1; i < int(data.size()); i++) {
		outo << ", " << data[i];
		if (i != int(data.size()) - 1) {
			outo << ",";
		}
	}
	outo << " ] len = " << data.size() << "\n";
	return outo;
}

using namespace std;

int main() {
	MyQueue<int> s;
	cout << s.empty() << s.list();
	for (int i = 0; i < 50; i++) {
		s.push(i);

	}
	cout << s.list();
	s.pop();
	cout << s.list();
	cout << s.back() << s.empty();
	return 0;
}
