#ifndef SNAKE_H
#define SNAKE_H

#include <utility>	// ʹ�ü�ֵ�� std::pair
#include <vector>
#include "Cursor.h"

enum _dir {
	_up = -2,
	_left = -1,
	_stop = 0,
	_right = 1,
	_down = 2,
	_end
};
_dir operator-(_dir dir); 

class Snake {
		std::vector<std::pair<int, int>> body;	// ��������
		_color headColor, tailColor;	// ��ͷ��ɫ����β��ɫ
	public:
		Snake();

		std::pair<int, int> Head();
		std::vector<std::pair<int, int>> Body();

		_color HeadColor();
		_color TailColor();

		_color SetHeadColor(_color color);
		_color SetTailColor(_color color);

		bool CrashTail();

		void Move(_dir dir, bool longer = false);
		void Move(std::pair<int, int> pos, bool longer = true);	// ��Ծʽ�ƶ�

	protected:
};

#endif
