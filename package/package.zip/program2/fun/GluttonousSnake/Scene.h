#ifndef SCENE_H
#define SCENE_H

#include <utility>	// ʹ�ü�ֵ�� std::pair
#include <vector>

enum _kind {
	_null = 0,
	_snakeHead,
	_snakeTail,
	_fruit
};

class Scene {
		int height, width;
		std::vector<std::vector<int>> map;
		bool snakeGetFruit;
	public:
		Scene();

		std::vector<std::vector<int>> Map();

		int Height();
		int Width();
		std::pair<int, int> Size();

		void SetSize(int h);
		void SetSize(int h, int w);

		void LoadSnake(std::vector<std::pair<int, int>> snakeBody);
		void LoadFruit(std::pair<int, int> fruitPos);

		bool CrashBoundary(std::pair<int, int> headPos);

		bool IsSnakeGetFruit();

	protected:
};

#endif
