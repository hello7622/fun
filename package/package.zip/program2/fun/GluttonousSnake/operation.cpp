#include "Cursor.h"
#include "Fruit.h"
#include "Snake.h"
#include "Scene.h"
#include <conio.h>
#include <iostream>
#include <string>
using namespace std;

void Draw(std::vector<std::vector<int>> map,int score) {
	int width = map[0].size(), height = map.size();
	Gotoxy(0, 0);
	const char sign[4 + 1] {" OoF"};
	string top(width + 2, '#'), &bottom = top;
	cout << top << '\n';
	for (int i = 0; i < height; i++) {
		cout << '#';
		for (int j = 0; j < width; j++) {
			cout << sign[map[i][j]];
		}
		cout << "#\n";
	}
	cout << bottom << "\nScore:" << score - 1 << '\n';
}

_dir Input() {
	char ch = getch();
	if (ch == 'a') {
		return _left;
	} else if (ch == 'd') {
		return _right;
	} else if (ch == 'w') {
		return _up;
	} else if (ch == 's') {
		return _down;
	} else if (ch == 13) {
		return _end;
	} else {
		return _stop;
	}
}

int main(void) {
	HideCursor();
	Fruit fruit;
	Snake snake;
	Scene x;
	_dir dir;
	fruit.SetPos(5, 5);
	while (1) {
		x.LoadSnake(snake.Body());
		x.LoadFruit(fruit.Pos());
		Draw(x.Map(),fruit.NumOfGetting());
		if ((dir = Input()) == _end) {
			break;
		}
		snake.Move(dir,x.IsSnakeGetFruit());
		if(x.IsSnakeGetFruit()) {
			fruit.SetPos(x.Size());
		}
		if(x.CrashBoundary(snake.Head())) {
			snake.Move(-dir);
		}
	}
	return 0;
}
