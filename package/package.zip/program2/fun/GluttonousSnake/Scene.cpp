#include "Scene.h"

Scene::Scene(): height(10), width(20), map(10, std::vector<int>(20, _null)), snakeGetFruit(false) {}

std::vector<std::vector<int>> Scene::Map() {
	return map;
}

int Scene::Height() {
	return height;
}
int Scene::Width() {
	return width;
}
std::pair<int, int> Scene::Size() {
	return std::pair<int, int> {width, height};
}

void Scene::SetSize(int h) {
	height = h;
	width = 2 * h;
	map.resize(height, std::vector<int>(width, _null));
}
void Scene::SetSize(int h, int w) {
	height = h;
	width = w;
	map.resize(height, std::vector<int>(width, _null));
}

void Scene::LoadSnake(std::vector<std::pair<int, int>> snakeBody) {
	map.assign(height,std::vector<int>(width,_null));
	snakeGetFruit = false;
	auto it = snakeBody.begin();
	map[it->second][it->first] = _snakeHead;
	it++;
	for (; it < snakeBody.end(); it++) {
		map[it->second][it->first] = _snakeTail;
	}
}
void Scene::LoadFruit(std::pair<int, int> fruitPos) {
	if (map[fruitPos.second][fruitPos.first] == _snakeHead) {
		snakeGetFruit = true;
	} else {
		map[fruitPos.second][fruitPos.first] = _fruit;
	}
}

bool Scene::CrashBoundary(std::pair<int, int> headPos) {
	if (headPos.first < 0 || headPos.first >= width) {
		return true;
	}
	if (headPos.second < 0 || headPos.second >= height) {
		return true;
	}
	return false;
}

bool Scene::IsSnakeGetFruit() {
	return snakeGetFruit;
}
