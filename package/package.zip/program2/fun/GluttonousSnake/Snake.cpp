#include "Snake.h"

_dir operator-(_dir dir) {
	if (dir == _up) {
		return _down;
	} else if (dir == _left) {
		return _right;
	} else if (dir == _right) {
		return _left;
	} else if (dir == _down) {
		return _up;
	} else  {
		return dir;
	}
}

Snake::Snake(): body{{1, 1}}, headColor(green), tailColor(yellow) {}

std::pair<int, int> Snake::Head() {
	return body[0];
}

std::vector<std::pair<int, int>> Snake::Body() {
	return body;
}

_color Snake::HeadColor() {
	return headColor;
}
_color Snake::TailColor() {
	return tailColor;
}

_color Snake::SetHeadColor(_color color) {
	headColor = color;
	return headColor;
}
_color Snake::SetTailColor(_color color) {
	tailColor = color;
	return tailColor;
}

bool Snake::CrashTail() {
	for (auto it = body.begin() + 1; it < body.end(); it++) {
		if (body[0] == *it) {
			return true;
		}
	}
	return false;
}

void Snake::Move(_dir dir, bool longer) {
	if(dir == _stop) {
		return ;
	}
	std::pair<int, int> newHead{body[0].first + (dir % 2), body[0].second + (dir / 2)};
	body.insert(body.begin(), newHead);
	if (!longer) {
		body.pop_back();
	}
}
void Snake::Move(std::pair<int, int> pos, bool longer) {
	auto newHead = pos;
	body.insert(body.begin(), newHead);
	if (!longer) {
		body.pop_back();
	}
}
