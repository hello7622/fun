#include <deque>

template<typename T>
std::deque<T>& Add(std::deque<T>& a, const std::deque<T>& b) {
	for (const auto& x: b) {
		a.push_back(x);
	}
	return a;
}

template<typename T>
struct LinkNode {
	T val;
	LinkNode *prior, *next;
	LinkNode(T _val = 0,
	         LinkNode * _prior = nullptr,
	         LinkNode * _next = nullptr)
		: val(_val)
		, prior(_prior)
		, next(_next) {}
	LinkNode* AddNode(T val) {
		LinkNode * p = new LinkNode(val, this, this->next);
		if (this->next) {
			this->next->prior = p;
		}
		this->next = p;
		return this;
	}
	bool operator==(const LinkNode& other) {
		return (val == other.val);
	}
	~LinkNode() {
		if (this->prior) {
			this->prior->next = this->next;
		}
		if (this->next) {
			this->next->prior = this->prior;
		}
	}
	static std::deque<T> Traverse(LinkNode * node) {
		std::deque<T> result;
		for (auto ptr = node; ptr; ptr = ptr->next) {
			result.push_back(ptr->val);
		}
		return result;
	}
	static void DestroyBackNode(LinkNode * node) {
		if (node->next) {
			DestroyBackNode(node->next);
			delete node->next;
		}
	}
};

#include <iostream>
// 数据量大或多个相差n * table_len的数据进入, 变成线性查找, 时间爆炸 
class HashTable {
		const int table_len;
		LinkNode<int> * table;
		int elem_num;
		LinkNode<int> * pos;
	public:
		HashTable()
			: table_len(128)
			, table(new LinkNode<int>[table_len])
			, elem_num(0)
			, pos(nullptr) {}
		bool find(int val) {
//			int pos1 = (val % table_len + table_len) % table_len;
			int pos1 = val % table_len;
			if (pos1 < 0) {
				pos1 += table_len;
			}
			for (pos = &table[pos1]; pos->next; pos = pos->next) {
				if (pos->next->val == val) {
					pos = pos->next;
					return true;
				}
			}
			return false;
		}
		bool push(int val) {
			 if (find(val)) {
			 	return false;
			 }
			 pos->AddNode(val);
			 ++elem_num;
			 return true;
		}
		bool pop(int val) {
			 if (find(val)) {
			 	delete pos;
			 	pos = nullptr;
			 	--elem_num;
			 	return true;
			 }
			 return false;
		}
		int count() const {
			return elem_num;
		}
		std::deque<int> Traverse() const {
			std::deque<int> result;
			for (int i = 0; i < table_len; i++) {
				Add(result, LinkNode<int>::Traverse(table[i].next));
			}
			return result;
		}
		~HashTable() {
			if (table) {
				for (int i = 0; i < table_len; i++) {
					LinkNode<int>::DestroyBackNode(&table[i]);
				}
				delete[] table;
			}
		}
		friend std::ostream& operator<<(std::ostream& outo, const HashTable& data) {
			auto x = data.Traverse();
			outo << "\nHashTable = [\n";
			for (int i = 0; i < int(x.size()); i++) {
				outo << " " << x[i];
				if (i < int(x.size()) - 1) {
					outo << ",";
					if ((i + 1) % 10 == 0) {
						outo << "\n";
					}
				}
			}
			outo << "\n] count = " << data.count() << "\n";
			return outo;
		}
};

#include <time.h>

int main(void) {
	srand(time(NULL));
	HashTable t;
	std::cout << t;
	for (int i = 0; i < 1024; i++) {
		if (rand() & 1) {
			t.push(i % 256 - 128);
		} else {
			t.pop(i % 256 - 128);
		}
	}
	std::cout << t << t.find(3);
	return 0;
}
