#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>
#include<cstdlib>
#include<conio.h>
#include<ctime>
#include<pthread.h>
#include"Cursor.h" 
#include"GetTime_MinusTime.h"
using namespace std;

const int MAX_SIZE = (23 * 20) + 1;
int a[MAX_SIZE] = {0},Blank[MAX_SIZE] = {0};
int DeleteRepet(int* begin,int* end);
int length = MAX_SIZE - DeleteRepet(a,a + MAX_SIZE);
bool Output(int* begin,int* end,int* red,int* blue,int y = 0,int x = 0);
bool Output(int* begin,int* end,int* red,int* yellow,int* blue,int* p1 = a,int* p2 = a + MAX_SIZE,int y = 0,int x = 0);

// ����Ƿ�����
bool Test(int* begin,int* end)
{
	for(int* p = begin;p < end - 1;p++)
	{
		if(*p > *(p + 1))
		{
			return false;
		}
	}
	return true;
} 

// �����ظ�
int DeleteRepet(int* begin,int* end)
{
	int count = 0;
	for(int* p1 = begin;p1 <= end - 1 - count;p1++)
	{
		for(int* p2 = p1 + 1;p2 <= end - count;p2++)
		{
			if(*p2 == *p1)
			{
				++count;
				for(int* p3 = p2;p3 <= end - count;p3++)
				{
					*p3 = *(p3 + 1);
				}
				--p2;
			}
		}
	}
	return count;
} 

// endһ��Ϊ��ָ����end = begin + length 
// ����Ĭ��Ϊ����
// ѡ������ 
bool Sort1(int* begin,int* end)
{
	for(int* p1 = begin;p1 < end - 1;p1++)
	{
		int* temp = p1;
		for(int* p2 = p1 + 1;p2 < end;p2++)
		{
			Output(a,a + length,p1,p2,temp);			
			if(*p2 < *temp)
			{
				temp = p2;
			}
			if(p1 > begin && *temp - *(p1 - 1) <= 1)
			{
	  		    break;
			}			
		}
		if(temp != p1)
		{
			swap(*temp,*p1);
			Output(a,a + length,p1,temp);
		}
	}
	return true;
}
// ��������
bool Sort1Insert(int* begin,int* end,int gap = 1)
{
    for(int* ans = begin + gap;ans < end;ans += gap)
	{
		Output(a,a + length,nullptr,ans);
		int record = *ans,*s = ans;
		for(;s > begin;s -= gap)
		{
			Output(a,a + length,s - gap,s,ans);
			if(*(s - gap) < record) break;
			*s = *(s - gap);
			Output(a,a + length,s - gap,s,ans);
		}
		*s = record;
		Output(a,a + length,s - gap,s,ans);
	}	
	return true;
}
// ϣ������
bool Sort1Shell(int* begin,int* end)
{
	int gap = (end - begin) / 2;
	while(gap >= 1)
	{
		for(int i = 0;i < gap;i++)
		{
			Sort1Insert(begin + i,end,gap);
		}
		gap /= 2;
	}
	return true;
} 
// ˫ð������
bool Sort2(int* begin,int* end)
{
	int *p1 = begin,*p2 = --end;
	Output(a,a + length,p1,p2);
	for(;p1 <= p2;p1++,p2--)
	{
		int* p = p1;
		Output(a,a + length,p1,p,p2);
		while(p <= p2)
		{
			if(*p1 > *p)
			{
				swap(*p,*p1);
				Output(a,a + length,p1,p,p2);
			}
			if(*p2 < *p)
			{
				swap(*p,*p2);
				Output(a,a + length,p1,p,p2);
			}
			p++;
			Output(a,a + length,p1,p,p2);
		}
	}
	return true;
} 

// ��������
//bool Sort3(int* begin,int* end)
//{
//	if(end - begin <= 1)
//	{
//		return true;
//	}
//	int *p1 = begin,*p2 = end - 1;
//	Output(a,a + length,p1,p2,begin,end);
//	while(p1 < p2)
//	{
//		while(*p1 <= *p2 && p1 < p2)
//		{
//			++p1;
//			Output(a,a + length,p1,p2,p2,begin,end);
//		}
//		swap(*p1,*p2);
//		Output(a,a + length,p1,p1,p2,begin,end);
//		while(*p1 <= *p2 && p1 < p2)
//		{
//			--p2;
//			Output(a,a + length,p1,p1,p2,begin,end);
//		}
//		swap(*p1,*p2);
//		Output(a,a + length,p1,p2,p2,begin,end);
//	}
//	
//	Sort3(begin,p2);
//	Sort3(p1,end);
//	return true;
//} 
void *Sort3(void * arg) {
	pair<int*, int*> p = *reinterpret_cast<pair<int*, int*>*>(arg);
	int * begin = p.first;
	int * end = p.second;
	if(end - begin <= 1)
	{
		return NULL;
	}
	int *p1 = begin,*p2 = end - 1;
	Output(a,a + length,p1,p2,begin,end);
	while(p1 < p2)
	{
		while(*p1 <= *p2 && p1 < p2)
		{
			++p1;
//			Output(a,a + length,p1,p2,p2,begin,end);
		}
		swap(*p1,*p2);
		Output(a,a + length,p1,p1,p2,begin,end);
		while(*p1 <= *p2 && p1 < p2)
		{
			--p2;
//			Output(a,a + length,p1,p1,p2,begin,end);
		}
		swap(*p1,*p2);
		Output(a,a + length,p1,p2,p2,begin,end);
	}	
	pthread_t pth1,pth2;
	pair<int*,int*> a(begin,p2),b(p1,end);
	pthread_create(&pth1,NULL,Sort3,reinterpret_cast<void*>(&a));
	pthread_create(&pth2,NULL,Sort3,reinterpret_cast<void*>(&b));
	pthread_join(pth1,NULL);
	pthread_join(pth2,NULL);
	return NULL;
}
// �������� ���ѡȡkeyֵ 
bool Sort3Rand(int* begin,int* end)
{
	srand(time(NULL));
	if(end - begin <= 1)
	{
		return true;
	}
	int *p1 = begin,*p2 = end - 1;
	int *key = begin + rand() % (end - begin);
	Output(a,a + length,p1,key,p2,begin,end);
	while(p1 < p2)
	{
		while(p1 < key && *p1 <= *key)
		{
			++p1;
			Output(a,a + length,p1,key,p2,begin,end);
		}
		swap(*p1,*key);
		Output(a,a + length,p1,key,p2,begin,end);
		key = p1;
		Output(a,a + length,p1,key,p2,begin,end);
		while(key < p2 && *key <= *p2)
		{
			--p2;
			Output(a,a + length,p1,key,p2,begin,end);
		}
		swap(*key,*p2);
		Output(a,a + length,p1,key,p2,begin,end);
		key = p2;
		Output(a,a + length,p1,key,p2,begin,end);
	}
	Sort3Rand(begin,key);
	Sort3Rand(key,end);
	return true;
} 
// �鲢����
bool Sort4(int* begin,int* end)
{
// �ֿ�	
	if(end - begin <= 1)
	{
		return true;
	}
	int* mid = begin + (end - begin) / 2;
	Sort4(begin,mid);
	Sort4(mid,end);
// �ϲ�
    int *array = new int[end - begin + 1]{0},*temp = array;
    int *p1 = begin,*p2 = mid;
    Output(a,a + length,p1,p2);Output(array,temp,temp,temp,(MAX_SIZE - 1) / 23 + 2);
    Output(Blank,Blank + MAX_SIZE - 1,nullptr,nullptr,(MAX_SIZE - 1) / 23 + 2);
    while(p1 < mid && p2 < end)
    {
		*temp = (*p1 < *p2) ? *(p1++) : *(p2++);
		++temp;
		Output(a,a + length,p1,p2);Output(array,temp,temp,temp,(MAX_SIZE - 1) / 23 + 2);
	}
	while(p1 < mid || p2 < end)
	{
		*temp = (p1 < mid) ? *(p1++) : *(p2++);
		++temp;
		Output(a,a + length,p1,p2);Output(array,temp,temp,temp,(MAX_SIZE - 1) / 23 + 2);
	}
	for(int* p = begin;p < end;p++)
	{
		*p = array[p - begin];
		Output(a,a + length,p,p);Output(array,temp,array + (p - begin),temp,(MAX_SIZE - 1) / 23 + 2);
	}	
	delete array;
	Output(Blank,Blank + MAX_SIZE - 1,nullptr,nullptr,(MAX_SIZE - 1) / 23 + 2);
	return true;
} 
// ������ û�㶮ֻ�д���
// ���������
void adjustHeap(int arr[], int i, int len) {
    int temp = arr[i];
    for (int k = 2 * i + 1; k < len; k = 2 * k + 1) {
        if (k + 1 < len && arr[k] < arr[k + 1]) {
            k++;
        }
        if (arr[k] > temp) {
            arr[i] = arr[k];
            i = k;
        } else {
            break;
        }
    }
    arr[i] = temp;
}
void Sort5(int* begin,int* end) 
{
	int* arr = begin;
	int len  = end - begin;
	Output(a,a + length,arr,arr + len);
    // ���������
    for (int i = len / 2 - 1; i >= 0; i--) 
	{
        adjustHeap(arr, i, len);
      	Output(a,a + length,arr + i,arr + len);
    }

    // ����
    for (int i = len - 1; i > 0; i--) 
	{
        swap(arr[0], arr[i]);
        Output(a,a + length,arr + i,arr + len);
        adjustHeap(arr, 0, i);
        Output(a,a + length,arr + i,arr + len);
    }
} 
// �������� ����
bool Sort6(int* begin,int* end)
{
	int* counter = new int[MAX_SIZE]{0};
	Output(counter,counter + length,nullptr,nullptr,(MAX_SIZE - 1) / 23 + 2);
	for(int* p = begin;p < end;p++)
	{
		++counter[*p];
		Output(a,a + length,p,nullptr);
		Output(counter,counter + length,counter + *p,nullptr,(MAX_SIZE - 1) / 23 + 2);
	}
	int* p = begin;
	for(int i = 0;i < MAX_SIZE && p < end;i++)
	{
		Output(counter,counter + length,counter + i,nullptr,(MAX_SIZE - 1) / 23 + 2);
		while(counter[i] > 0)
		{
			*p = i;
			--counter[i];
			++p;
		Output(a,a + length,p,nullptr);		
		}
	}
	return true;
} 
// ԰������
bool Sort7(int* begin,int* end)
{
	int* p = begin;
	Output(a,a + length,p,nullptr,p + 1);
	while(p < end - 1)
	{
		while(p < end - 1 && *p <= *(p + 1))
		{
			++p;
			Output(a,a + length,p,nullptr,p + 1);
		}
		while(p >= begin && *p > *(p + 1) && p < end - 1)
		{
			swap(*p,*(p + 1));
			Output(a,a + length,p,nullptr,p + 1);
			--p;
			Output(a,a + length,p,nullptr,p + 1);
		}
	}
	return true;
} 
// ˫ð��2 
bool Sort8(int* begin,int* end)
{
	int n = end - begin,i = 0,j = n - 1;
	int* p = begin + i;
	Output(a,a + length,p,nullptr,p + 1,begin + i,begin + j);
	while(i < j)
	{
		while(p < begin + j)
		{
			if(*p > *(p + 1))
			{
				swap(*p,*(p + 1));
				Output(a,a + length,p,nullptr,p + 1,begin + i,begin + j);
			}
			++p;
			Output(a,a + length,p,nullptr,p + 1,begin + i,begin + j);
		}
		--j;
		Output(a,a + length,p,nullptr,p + 1,begin + i,begin + j);
		while(p > begin + i)
		{
			if(*p < *(p - 1))
			{
				swap(*p,*(p - 1));
				Output(a,a + length,p - 1,nullptr,p,begin + i,begin + j);
			}
			--p;
			Output(a,a + length,p - 1,nullptr,p,begin + i,begin + j);
		}
		++i;
		Output(a,a + length,p - 1,nullptr,p,begin + i,begin + j);	
	}
	return true;
}
// ��������
// �������ռ����������ޣ�0~MAX_SIZE 
void DisCol(int* begin,int* end,int sign)
{
	int f[10][MAX_SIZE] = {0};
	int e[MAX_SIZE] = {0};
	
	int temp = 0;
	for(int* p = begin;p < end;p++)
	{
		temp = *p % sign / (sign / 10);
		f[temp][e[temp]++] = *p;
	}
	int* p = begin;
	for(int i = 0;i < 10;i++)
	{
		for(int j = 0;j < e[i];j++)
		{
			*(p++) = f[i][j];
		}
		Output(a,a + length,p,nullptr);
	}
}
void Sort9(int* begin,int* end)
{
	for(int i = 10;i <= 1000;i *= 10)
	{
		Output(a,a + length,nullptr,nullptr); 
		DisCol(begin,end,i);
	}
} 

bool RandArray(int* begin,int* end)
{
	srand(time(NULL));
	for(int* p = begin;p < end;p++)
	{
//		*p = rand() % (end - begin);
		*p = p - begin;
	}
	int n = end - begin;
	for(int i = 0;i < n;i++)
	{
		swap(begin[rand() % n],begin[rand() % n]);
	}	
	return true;
}
bool ReversalArray(int* begin,int* end)
{
	for(int* p = begin;p < end;p++)
	{
		*p = MAX_SIZE - 1 - (p - begin);
	}
	return true;
}

bool Output(int* begin,int* end,int* red,int* blue,int y,int x)
{
	if(kbhit())
	{
		exit(0);
	} 
//*/		
	HideCursor();
	Gotoxy(x,y);
	for(int* p = begin;p < end;p++)
	{
		if(p == red)
		{
			SetColor(4);
		}
		else if(p == blue)
		{
			SetColor(11);
		}	
		Gotoxy((p - begin) % 23,(p - begin) / 23);
		cout << setw(6) << left << *p;
		SetColor(15);
	}
//	cout << endl;
//	Sleep(75);
//	getch();
	return true;
}
bool Output(int* begin,int* end,int* red,int* yellow,int* blue,int* p1,int* p2,int y,int x)
{
	if(kbhit())
	{
		exit(0);
	} 
//*/	
	HideCursor();
	Gotoxy(x,y);
	for(int* p = begin;p < end;p++)
	{
		if(p == red || p == p1 - 1)
		{
			SetColor(4);
		}
		else if(p == blue || p == p2)
		{
			SetColor(11);
		}	
		else if(p == yellow)
		{
			SetColor(8);
		}			
		Gotoxy((p - begin) % 23 * 6,(p - begin) / 23);	
		cout << setw(6) << left << *p;
		SetColor(15);
	}
//	cout << endl;
//	Sleep(75);
//	getch(); 
	return true;
}
bool Output(int* begin,int* end)
{
	for(int* p = begin;p < end;p++)
	{
		cout << setw(3) << *p << ' ';
	}
	cout << endl;
	return true;
}

bool Flow(int flag)
{
/*	ofstream fout("record.txt",ios::app);
	if(!fout.is_open()) exit(0);
	fout << (MAX_SIZE - 1) / 23 << "�������¼��\n";
	tm time1 = {},time2 = {};
	long long second;
	string line,record[10] = {"ѡ������","��������","ϣ������",
							"˫ð������","����������ֵ����",
							"�������������","�鲢����",
							"������","��������","԰������"};
//*/	
	RandArray(a,a + MAX_SIZE);
//	ReversalArray(a,a + MAX_SIZE);
	length = MAX_SIZE - DeleteRepet(a,a + MAX_SIZE);
//	time1 = GetTime();
	switch (flag % 12) 
	{
		case 0:
			Sort1(a,a + length);
			break;
		case 1:
			Sort1Insert(a,a + length);
			break;
		case 2:
			Sort1Shell(a,a + length);
			break;
		case 3:
			Sort2(a,a + length);
			break;
		case 4:
			pair<int*,int*> ptr(a,a + length);
			pthread_t pth;
			pthread_create(&pth,NULL,Sort3,reinterpret_cast<void*>(&ptr));
			pthread_join(pth,NULL);
//			Sort3(reinterpret_cast<void*>(&ptr));
			break;
//		case 5:
//			Sort3Rand(a,a + length);
//			break;
//		case 6:
//			Sort4(a,a + length);
//			break;
//		case 7:
//			Sort5(a,a + length);
//			break;
//		case 8:
//			Sort6(a,a + length);
//			break;
//		case 9:
//			Sort7(a,a + length);
//			break;
//		case 10:
//			Sort8(a,a + length);
//			break;
//		case 11:
//			Sort9(a,a + length);
//			break;
//		default:
//			break;		
	}
/*	time2 = GetTime();
	second = MinusTime(time1,time2);
	fout << record[flag % 9]
		 << setfill('0')
		 << setw(2) << second / 60 << ':'
		 << setw(2) << second % 60 << '\n';
    fout.close();
//*/    
	return true;
}

int main(void)
{
	srand(time(NULL));
	cout << "������ϽǵķŴ����Ȼ����㰴��ʲô����ʼ"; 
	getch();
//	int a[9 - 6] = {2,7,8};
	Flow(4);
/*	for(int i = 0;i < 6;i++)
	{
		if(kbhit())
		{
			break;
		}
		Gotoxy(0,(MAX_SIZE - 1) / 23 * 2 + 4);
		cout << "�������Ϊ��ʾ��ʵ���ٶ�Ӧ�ñ���ʾ�ÿ죬����ͬ�㷨֮��������ٶ�ȷʵ���ڲ���\n";
		switch (a[i % 2]) 
		{
		case 0:
			cout << "ѡ������\n"
				 << "����ʾ�п�����������\n"
				 << "����һ�㣺����ҵ���ֵ��ǰһ�����źõ�ֵ��ֵ<=1����ֱ��ֹͣ���ң�Ӧ���ǿ���ͨ�õ�\n";
			break;
		case 1:
			cout << "��������\n"; 
			break;
		case 2:
			cout << "˫ð������\n"
				 << "���ܻ��ѡ�������һ��\n";
			break;
		case 3:
			cout << "������������ֵΪkeyֵ\n"
				 << "�����￪ʼ�о��ٶ���������һ��̨��\n";
			break;
		case 4:
			cout << "�����������ȡkeyֵ";
			break;
		case 5:
			cout << "�鲢����\n"
				 << "˵ʵ�����о����ַ�ʽ�����⣬Ψ�������������������\n"
				 << "����û�뵽С�������ٶ���\n";
			break;
		case 6:
			cout << "������\n";
			break;
		default:
			cout << "��������\n";
			break;
		}
		Flow(a[i % 2]);
		system("cls");
	}
//*/	
	return 0;
}
