#include <windows.h>
//�ƶ����
void Gotoxy(int x, int y) {
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), {SHORT(x), SHORT(y)});
}
//���ع��,������˸����
void HideCursor(void) {
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(handle, &CursorInfo);         //��ÿ���̨�����Ϣ
	CursorInfo.bVisible = 0;                           //���ؿ���̨���
	SetConsoleCursorInfo(handle, &CursorInfo);         //���ÿ���̨���״̬
}
#include <random>
int Rand(int min, int max) {
	std::random_device rd;  // ���������������
	std::mt19937 gen(rd()); // ʹ�� Mersenne Twister ����
	std::uniform_int_distribution<int> distribution(min, max - 1); // ���巶Χ

	return distribution(gen); // ���������������
}

#include <utility>
#include <map>
#include <vector>
#include <string>
#include <iostream>
typedef std::pair<int, int> POS;

class T {
		const int row_count, col_count;
		std::string bottom;
		POS head;
		int len;
		std::map<char, POS> direction;
		std::vector<std::vector<int>> group;
		bool flag;
	public:
		T(int row, int col)
			: row_count(row), col_count(col)
			, bottom(col + 1, '#')
			, head{row / 2, col / 2}
			, len(1)
			, direction{{'w', {-1, 0}}, {'a', {0, -1}}, {'s', {1, 0}}, {'d', {0, 1}}}
		, group(row, std::vector<int>(col, 0)) {

		}
		POS HeadPos() {
			return head;
		}
		int RowCount() {
			return row_count;
		}
		int ColCount() {
			return col_count;
		}
		// ��ӡ��ͼ
		void OutputMap() {
			Gotoxy(0, 0);
			for (const auto& row : group) {
				for (const auto& col : row) {
					if (col > 0) {
						if (col == len) {
							std::cout << "*";
						} else {
							std::cout << "+";
						}
					} else if (col < 0) {
						std::cout << "&";
					} else {
						std::cout << " ";
					}
				}
				std::cout << "#\n";
			}
			std::cout << bottom;
		}
		// ����ͷ������
		bool UpdateHead(char g) {
			if (!direction.count(g)) {
				return false;
			}
			auto dir = direction[g];
			head.first += dir.first;
			head.second += dir.second;
			return true;
		}
		// ����ͷ��
		void SetHead() {
			group[head.first][head.second] = len;
		}
		// ����ʳ��
		bool SetFood(POS& food) {
			int row = Rand(0, row_count), col = Rand(0, col_count);
			if (group[row][col] > 0) {
				return false;
			}
			group[row][col] = -1;
			food = {row, col};
			return true;
		}
		// ˢ�µ�ͼ
		void UpdateMap() {
			for (auto& row : group) {
				for (auto& col : row) {
					if (col > 0 && !flag) {
						--col;
					}
				}
			}
			flag = false;
		}
		// �����ײ
		int Crash() {
			auto x = head.first, y = head.second;
			if (x < 0 || x >= row_count || y < 0 || y >= col_count) {
				return -1;		// ����
			}
			if (group[x][y]) {
				if (group[head.first][head.second] < 0) {
					++len;
					flag = true;
					return 1;	// ʳ��
				}
				return -2;		// ��ʳ
			}
			return 0;
		}
};

#include <queue>
#include <conio.h>
class Test_T {
		enum _crash {
			_eatself = -2,
			_bound,
			_nothing,
			_food,
			_esc
		};
		T test;
		POS food;
		int dir;
	public:
		Test_T(int row, int col): test(row, col) {
			test.SetHead();
			while (!test.SetFood(food));
			test.OutputMap();
		}
		bool Period(std::queue<char>& dir_q, std::queue<bool>& food_q) {
			if (test.UpdateHead(dir)) {
				dir_q.push(dir);
				food_q.push(false);
				switch (test.Crash()) {
					case _eatself:
						std::cout << "\n��ʳ";
						return false;
						break;
					case _bound:
						std::cout << "\n����";
						return false;
						break;
					case _nothing:
						break;
					case _food:
						food_q.back() = true;
						while (!test.SetFood(food));
						break;
					default:
						return false;
						break;
				}
				test.UpdateMap();
				test.SetHead();
				test.OutputMap();
			}
			return true;
		}
		std::pair<std::queue<bool>, std::queue<char>> Run() {
			std::queue<char> dir_q;
			std::queue<bool> food_q;
			char s[] = "wsad";
			for (int i = 0; i < 750; i++) {
				dir = s[Guide(dir)];
//			while ((dir = getch()) != 27) {
				if (!Period(dir_q, food_q)) {
					break;
				}
			}
			std::pair<std::queue<bool>, std::queue<char>> result = {food_q, dir_q};
			return result;
		}
		int Guide(const int& dir) {
			auto head = test.HeadPos();
			int x = food.first - head.first;
			int y = food.second - head.second;
			if (x > 0) {
				if (dir == 0) {
					return Rand(2, 4);
				}
				return 1;
			} else if (x < 0) {
				if (dir == 1) {
					return Rand(2, 4);
				}
				return 0;
			}
			if (y > 0) {
				return 3;
			} else if (y < 0) {
				return 2;
			}
			return Rand(0, 4);
		}
};

using namespace std;

int main(void) {
	HideCursor();
	Test_T t(35, 70);
	auto result = t.Run();
	int count = 0;
	cout << "\n";
	while (!result.second.empty()) {
		switch (result.second.front()) {
			case 'w':
				cout << "��";
				break;
			case 'a':
				cout << "��";
				break;
			case 's':
				cout << "��";
				break;
			case 'd':
				cout << "��";
				break;
			default:
				break;
		}
		if (result.first.front()) {
			cout << "+1";
		}
//		cout << " ";
		if (++count % 25 == 0) {
			cout << "\n";
		}
		result.second.pop();
		result.first.pop();
	}
	return 0;
}
