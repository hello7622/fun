#ifndef HASHTABLE_H
#define HASHTABLE_H

#include<iostream>

typedef struct Node {
	int data;
	Node* next;
	Node(int da = 0,Node* ne = nullptr);
	Node(const Node& other);
	bool operator<(const Node& other);
	bool operator<(int value);
	bool operator>(const Node& other);
	bool operator>(int value);
	bool operator==(const Node& other);
	bool operator==(int value);
	bool operator<=(const Node& other);
	bool operator<=(int value);
	bool operator>=(const Node& other);
	bool operator>=(int value);	
	Node operator=(const Node& other);
	Node operator=(int value);
} Node;

class HashTable {
		Node* table;					// ��ϣ��
		size_t loaded, max_size;			// ��װ��Ԫ�ظ������������
	public:
		HashTable();
		~HashTable();
		HashTable(std::initializer_list<int> values);
		int Hash(int value);
		bool empty();
		size_t size();
		bool push(int value);
		bool pop(int value);
		bool find(int value);
};

#endif
