#include "HashTable.h"

Node::Node(int da, Node* ne): data(da), next(ne) {}
Node::Node(const Node& other): data(other.data), next(nullptr) {}
bool Node::operator<(const Node& other) {
	return (data < other.data);
}
bool Node::operator<(int value) {
	return (data < value);
}
bool Node::operator>(const Node& other) {
	return (data > other.data);
}
bool Node::operator>(int value) {
	return (data > value);
}
bool Node::operator==(const Node& other) {
	return (data == other.data);
}
bool Node::operator==(int value) {
	return (data == value);
}
bool Node::operator<=(const Node& other) {
	return (data <= other.data);
}
bool Node::operator<=(int value) {
	return (data <= value);
}
bool Node::operator>=(const Node& other) {
	return (data >= other.data);
}
bool Node::operator>=(int value) {
	return (data >= value);
}
Node Node::operator=(const Node& other) {
	if (&other == this) {
		return* this;
	}
	data = other.data;
	return* this;
}
Node Node::operator=(int value) {
	data = value;
	return* this;
}

HashTable::HashTable(): table(new Node[100]), loaded(0), max_size(100) {}
HashTable::~HashTable() {
	if (table) {
		delete[] table;
	}
}
HashTable::HashTable(std::initializer_list<int> values): table(new Node[100]), loaded(0), max_size(100) {
	for (const auto& value : values) {
		int pos = Hash(value);
		Node* p = &table[pos];
		for (; p->next && *(p->next) < value; p = p->next);
		if (p->next && *(p->next) == value) continue;
		Node* temp = new Node(value, p->next);
		p->next = temp;
		loaded++;
	}
}
int HashTable::Hash(int value) {
	return value % max_size;
}
bool HashTable::empty() {
	return (!loaded);
}
size_t HashTable::size() {
	return loaded;
}
bool HashTable::push(int value) {
	int pos = Hash(value);
	Node* p = &table[pos];
	for (; p->next && *(p->next) < value; p = p->next);
	if (p->next && *(p->next) == value) {
		std::cout << "��������ֵΪ" << value << "��Ԫ��" << std::endl;
		return false;
	}
	Node* temp = new Node(value, p->next);
	p->next = temp;
	loaded++;
	return true;
}
bool HashTable::pop(int value) {
	int pos = Hash(value);
	Node* p = &table[pos];
	for (; p->next && *(p->next) < value; p = p->next);
	if (p->next && *(p->next) == value) {
		Node* temp = p->next;
		p->next = temp->next;
		delete temp;
		loaded--;
		return true;
	}
	std::cout << "������ֵΪ" << value << "��Ԫ��" << std::endl;
	return false;
}
bool HashTable::find(int value) {
	int pos = Hash(value);
	Node* p = &table[pos];
	for (; p->next && *(p->next) < value; p = p->next);
	if (p->next && *(p->next) == value) return true;
	return false;
}
