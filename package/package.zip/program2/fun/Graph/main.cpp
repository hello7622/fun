#include "AdjacencyList.h"
#include <iostream>
using namespace std;

int main() {
	AdjacencyList g;
	g.AddVertex("0");
	g.AddVertex("1");
	g.AddVertex("2");
	g.AddEdge("0", "1");
	g.AddEdge("1", "2");
	cout << g.HasEdge("0", "2") << g.HasPath("0", "2");
	g.RemoveVertex("0");
	cout << g.HasEdge("1", "2") << g.HasPath("0", "2");
	return 0;
}
