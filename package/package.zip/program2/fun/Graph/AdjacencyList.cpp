#include "AdjacencyList.h"
#include <queue>

AdjacencyList::AdjacencyList()
	: vertexNum(0) {

}

AdjacencyList::~AdjacencyList() {

}

bool AdjacencyList::AddVertex(const std::string& tag) {
	if (HasVertex(tag)) {
		return false;
	}
	vertexs[tag] = true;
	++vertexNum;
	list[tag] = std::map<std::string, int>();
	return true;
}

bool AdjacencyList::AddEdge(const std::string& v1, const std::string& v2) {
	if (!HasVertex(v1) || !HasVertex(v2)) {
		return false;
	}
	list[v1][v2] = true;
	return true;
}

bool AdjacencyList::RemoveVertex(const std::string& tag) {
	if (!HasVertex(tag)) {
		return false;
	}
	vertexs[tag] = false;
	--vertexNum;
	return true;
}

bool AdjacencyList::RemoveEdge(const std::string& v1, const std::string& v2) {
	if (!HasEdge(v1, v2)) {
		return false;
	}
	list[v1][v2] = false;
	return false;
}

bool AdjacencyList::HasVertex(const std::string& tag) {
	return vertexs.count(tag) && vertexs[tag];
}

bool AdjacencyList::HasEdge(const std::string& v1, const std::string& v2) {
	if (!HasVertex(v1) || !HasVertex(v2)) {
		return false;
	}
	if (!list[v1].count(v2) || !list[v1][v2]) {
		return false;
	}
	return true;
}

bool AdjacencyList::HasPath(const std::string& v1, const std::string& v2) {
	if (!HasVertex(v1) || !HasVertex(v2)) {
		return false;
	}
	std::map<std::string, bool> visited;
	std::queue<std::string> q;
	q.push(v1);
	std::string cur;
	while (!q.empty()) {
		cur = q.front();
		q.pop();
		visited[cur] = true;
		if (HasEdge(cur, v2)) {
			return true;
		}
		for (const auto& v : list[cur]) {
			if (v.second == false || visited.count(v.first)) {
				continue;
			}
			q.push(v.first);
		}
	}
	return false;
}
