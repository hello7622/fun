#ifndef ADJACENCYLIST_H
#define ADJACENCYLIST_H

#include <string>
#include <map>

class AdjacencyList
{
	public:
		AdjacencyList();
		virtual ~AdjacencyList();
		bool AddVertex(const std::string& tag);
		bool AddEdge(const std::string& v1, const std::string& v2);
		bool RemoveVertex(const std::string& tag);
		bool RemoveEdge(const std::string& v1, const std::string& v2);
		bool HasVertex(const std::string& tag);
		bool HasEdge(const std::string& v1, const std::string& v2);
		bool HasPath(const std::string& v1, const std::string& v2);
	private:
		std::map<std::string, std::map<std::string, int>> list;				
		std::map<std::string, bool> vertexs;
		int vertexNum;
};

#endif
