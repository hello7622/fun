#include<iostream>
#include<string>
#include<conio.h>
#include"Cursor.h"
using namespace std;

struct Node
{
	int data;
	Node *father,*lchild,*rchild;
	Node(int da,Node* fa): data(da), father(fa), lchild(nullptr), rchild(nullptr) {}
};
// Ϊ��ǰ�ڵ������ӽڵ㣬��0��1 
bool AddNode(Node* head,int data,bool flag)
{
	if(!head)
	{
		return false;
	}
	Node* p = new Node(data,head);
	if(flag)
	{
		head->rchild = p;
	}
	else
	{
		head->lchild = p;
	}
	return true;
}
// ����� 
bool ClearTree(Node* head)
{
	if(!head)
	{
		return true;
	}
	ClearTree(head->lchild);
	ClearTree(head->rchild);
	delete head;
	return true;
} 
// �����ǰ�ڵ�ֵ
void Output(Node* p)
{
	system("cls");
	Gotoxy(0,0);
	cout << p->data;
} 
// ������ӽڵ���ʾ����0��1 
bool Output(Node* p,bool flag) 
{
	string a[2] = {"��","��"};
	Gotoxy(0,2);
	cout << "����" << a[flag] << "�ڵ㣬���룺";
	int data;
	cin >> data;
	AddNode(p,data,flag);
	return true;
}

int main(void)
{
	Node* head = nullptr;
	int data,ch;
	Gotoxy(0,0);
	cout << "�����ڵ㣬���룺";
	cin >> data;
	head = new Node(data,nullptr);
	Node* p = head;
	Output(p);
	while(1)
	{
		ch = getch();
		if(ch == 'a')
		{
			if(p->lchild)
			{
				p = p->lchild;
			}
			else
			{
				if(Output(p,0))
				{
					p = p->lchild;
				}
			}
		}
		else if(ch == 'd')
		{
			if(p->rchild)
			{
				p = p->rchild;
			}
			else
			{
				if(Output(p,1))
				{
					p = p->rchild;
				}
			}
		}
		else if(ch == 'w' && p->father)
		{
			p = p->father;
		}
		else if(ch == 27)
		{
			break;
		}
		Output(p);
	} 
	ClearTree(head);
	return 0; 
}
