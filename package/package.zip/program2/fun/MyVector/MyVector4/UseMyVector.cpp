#include "MyVector.h"
#include "MyVector.cpp"

#include <iostream>

template<typename T>
std::ostream& operator<<(std::ostream& outo, const MyVector<T>& list) {
	for (const T& elem : list) {
		outo << elem;
	}
	return outo;
}

MyVector<int> range(int begin, int end, int step = 1) {
	MyVector<int> ans;
	for (; begin < end; begin += step) {
		ans.append(begin);
	}
	return ans;
}

#include <string>
using namespace std;
typedef string TestType;
// int, char, string, MyVector 测试成功 
int main() {
	MyVector<MyVector<int>> l(5, MyVector<int>(5, 5));
	for (const auto& row: l) {
		for (const int& elem: row) {
			cout << elem;
		}
		cout << endl;
	}
	MyVector<int> l1{1, 2, 3}, l2(3, 4);
	cout << (l1 + l2);
	return 0;
}
