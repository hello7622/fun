#include "MyVector.h"
#include<limits>
#include<conio.h>

// ���캯��
template<typename T>
MyVector<T>::MyVector()
: real(nullptr), temp(nullptr), arrayCount(0), arrayLength(0), rubbish(std::numeric_limits<T>::min())
{}

template<typename T>
MyVector<T>::MyVector(const std::initializer_list<T> values)
: real(nullptr), temp(new T[500]), arrayCount(0), arrayLength(0), rubbish(std::numeric_limits<T>::min())
{
	for(const auto& value : values)
	{
		temp[arrayCount] = value;
		++arrayCount;
	}
	arrayLength = arrayCount <= 5 ? 10 : arrayCount * 2;
	real = new T[arrayLength];
	for(int i = 0;i < arrayCount;i++)
	{
		real[i] = temp[i];
	}
	for(int i = arrayCount;i <= arrayCount + 1;i++)
	{
		real[i] = 0;
	}
	delete[] temp;
	temp = nullptr;
}	 

template<typename T>
MyVector<T>::MyVector(MyVector<T>& other)
: real(nullptr), temp(nullptr), arrayCount(other.size()), arrayLength(arrayCount <= 5 ? 10 : arrayCount * 2), rubbish(std::numeric_limits<T>::min())
{
	real = new T[arrayLength];
	for(int i = 0;i < arrayCount;i++)
	{
		real[i] = other[i];
	}
	real[arrayCount] = real[arrayCount + 1] = 0;
}

// �������� 
template<typename T>
MyVector<T>::~MyVector()
{
	if(real)
	{
		delete[] real;
		real = nullptr;
	}
	if(temp)
	{
		delete[] temp;
		temp = nullptr;
	}
	arrayCount = arrayLength = 0;
}

// ��
template<typename T>
void MyVector<T>::push_front(const T& data)
{
	++arrayCount;
	if(!real)
	{
		arrayLength = arrayCount <= 5 ? 10 : arrayCount * 2;
		real = new T[arrayLength];
		real[0] = data;
		real[1] = real[2] = 0;
	}	
	if((arrayLength - arrayCount) * 5 <= arrayLength)
	{
		arrayLength = arrayCount * 2;
		temp = CopyArray(real,temp,arrayCount - 1);
		delete[] real;
		real = nullptr;
		
		real = new T[arrayLength];
		T* pReal = real;
		*pReal = data;
		++pReal;
		
		pReal = CopyArray(temp,pReal,arrayCount - 1);
		delete[] temp;
		temp = nullptr;
		
		real[arrayCount] = real[arrayCount + 1] = 0;
		return ;
	}
	for(int i = arrayCount + 1;i > 0;i--)
	{
		real[i] = real[i - 1];
	}
	real[0] = data;
}

template<typename T>
void MyVector<T>::push_back(const T& data)
{
	++arrayCount;
	if(!real)
	{
		arrayLength = arrayCount <= 5 ? 10 : arrayCount * 2;
		real = new T[arrayLength];
		real[0] = data;
		real[1] = real[2] = 0;
	}	
	if((arrayLength - arrayCount) * 5 <= arrayLength)
	{
		arrayLength = arrayCount * 2;
		temp = CopyArray(real,temp,arrayCount - 1);
		delete[] real;
		real = nullptr;
		
		real = new T[arrayLength];
		real = CopyArray(temp,real,arrayCount - 1);
		real[arrayCount - 1] = data;
		delete[] temp;
		temp = nullptr;
		
		real[arrayCount] = real[arrayCount + 1] = 0;
		return ;		
	}
	real[arrayCount - 1] = data;
	real[arrayCount + 1] = 0;
}

template<typename T>
void MyVector<T>::insert(const T* position,const T& data)
{
	if(!position || !real)
	{
		if(arrayCount == 0)
		{
			arrayCount = 1;
			arrayLength = 10;
			real = new T[arrayLength];
			real[0] = data;
			real[1] = real[2] = 0;
		}
		return ;
	}
	++arrayCount;
	if((arrayLength - arrayCount) * 5 <= arrayLength)
	{
		arrayLength = arrayCount * 2;
		int num = ((position - real) > (arrayCount - 1)) ? (arrayCount - 1) : (position - real);
		temp = CopyArray(real,temp,arrayCount - 1);
		delete[] real;
		real = nullptr;
		
		real = new T[arrayLength];
		real = CopyArray(temp,real,num);
		
		T* pReal = real + num,*pTemp = temp + num;
		*pReal = data;
		++pReal;
		pReal = CopyArray(pTemp,pReal,arrayCount - 1 - num);
		delete[] temp;
		temp = nullptr;
		
		real[arrayCount] = real[arrayCount + 1] = 0;
		return ;
	}
	int num = ((position - real) > (arrayCount - 1)) ? (arrayCount - 1) : (position - real);
	for(int i = arrayCount + 1;i > num;i--)
	{
		real[i] = real[i - 1];
	}
	real[num] = data;
}

// ɾ
template<typename T>
void MyVector<T>::pop_front()
{
	if(!real)
	{
		return ;
	}
	--arrayCount;
	for(int i = 0;i <= arrayCount + 1;i++)
	{
		real[i] = real[i + 1];
	}
	if(arrayCount * 5 <= arrayLength && arrayLength > 10)
	{
		arrayLength = arrayCount * 2;
		T* pReal = real + arrayLength;
		delete[] pReal;
	}
}

template<typename T>
void MyVector<T>::pop_back()
{
	if(!real)
	{
		return ;
	}
	--arrayCount;
	real[arrayCount] = 0;
	if(arrayCount * 5 <= arrayLength && arrayLength > 10)
	{
		arrayLength = arrayCount * 2;
		T* pReal = real + arrayLength;
		delete[] pReal;
	}	
}

template<typename T>
void MyVector<T>::erase(const T* position)
{
	if(!position || !real || position - real > arrayCount || position < real)
	{
		return ;
	}
	--arrayCount;
	int num = position - real;
	for(int i = num;i <= arrayCount + 1;i++)
	{
		real[i] = real[i + 1];
	}
	if(arrayCount * 5 <= arrayLength && arrayLength > 10)
	{
		arrayLength = arrayCount * 2;
		T* pReal = real + arrayLength;
		delete[] pReal;
	}	
}

// ��
template<typename T>
T* MyVector<T>::begin()
{
	if(!real)
	{
		return nullptr;
	}	
	return real;
}

template<typename T>
T* MyVector<T>::end()
{
	if(!real)
	{
		return nullptr;
	}
	return (real + arrayCount);
}

template<typename T>
T& MyVector<T>::front()
{
	if(!real)
	{
		return rubbish;
	}
	return real[0];
}

template<typename T>
T& MyVector<T>::back()
{
	if(!real)
	{
		return rubbish;
	}
	return real[arrayCount - 1];
}

template<typename T>
int MyVector<T>::size()
{
	return arrayCount;
}

template<typename T>
bool MyVector<T>::empty()
{
	return !arrayCount;
}

// ���� 
template<typename T>
T& MyVector<T>::operator[](int num)
{
	if(num < 0)
	{
		return rubbish;
	}
	if(num >= arrayCount)
	{
		return real[arrayCount];
	}
	return real[num];
} 

template<typename T>
MyVector<T> MyVector<T>::operator=(MyVector<T>& other)
{
	if(this == &other)								// ���Ҹ�ֵ
	{
		return* this;
	} 
	if(real)
	{
		delete[] real;
	}
	arrayCount = other.size();
	arrayLength = arrayCount <= 5 ? 10 : arrayCount * 2;
	for(int i = 0;i < arrayCount;i++)
	{
		real[i] = other[i];
	}
	real[arrayCount] = real[arrayCount + 1] = 0;
	return* this;
}

template<typename T>
bool MyVector<T>::operator==(const MyVector<T>& other)
{
	if(arrayCount != other.size())
	{
		return false;
	}
	for(int i = 0;i < arrayCount;i++)
	{
		if(real[i] != other[i])
		{
			return false;
		}
	}
	return true;
}

//��Ԫ
template<typename T> 
std::ostream& operator<<(std::ostream& outo,MyVector<T>& other)
{
	for(int i = 0;i < other.size();i++)
	{
		outo << other[i] << ' ';
	}
	outo << std::endl;
	return outo;
}

// protected 
template<typename T> 
T* MyVector<T>::CopyArray(T* prim,T* buf,int num)
{
	if(!buf)
	{
		buf = new T[num + 1];
	}
	T* record = buf;
	T* pAim = prim,*pBuf = buf;
	for(;pAim < prim + num;pAim++,pBuf++)
	{
		*pBuf = *pAim;
	}
	return record;
}
