#include<iostream>
#include<limits>
#include"MyVector.h"
#include"MyVector.cpp"
using namespace std;

template<typename T>
void Output(MyVector<T> a)
{
	for(int i = 0;i < a.size();i++)
	{
		cout << a[i] << ' ';
	}
	cout << endl;
}

int main(void)
{
	MyVector<char> a({'1','2','3'});
	for(int i = 4;i < 10;i++)
	{
		a.push_back(i + '0');
		cout << a;
	}
	cout << a;
	return 0;
}
