#ifndef VECTOR_H
#define VECTOR_H

#include <cstddef>	// size_t
#include <initializer_list>
#include <iostream>

template<typename T>
class Vector {
		T *base, *temp;
		int eleNum, maxNum;
	public:
		Vector();
		Vector(std::initializer_list<T> values);
		Vector(const Vector<T>& other);
		~Vector();

		Vector<T>&& operator=(const Vector<T>& other);

		T& operator[](int num) const;
		size_t size() const;
		size_t length() const;
		T front() const;
		T back() const;
		T* begin() const;
		T* end() const;

		T& operator[](int num);
		size_t size();
		size_t length();
		T front();
		T back();
		T* begin();
		T* end();

		void insert(T* position, T value);
		void erase(T* position);
		void push_back(T value);
		void pop_back(T& putValue);

		Vector<T>& operator>>(T& putValue) {
			this->pop_back(putValue);
			return* this;
		}
		template<typename U>
		friend std::ostream& operator<<(std::ostream& outo, const Vector<U>& data);
		template<typename U>
		friend Vector<U>& operator<<(U& putValue, Vector<U>& data);

	protected:
		void Trans();
};
Vector<char>& operator<<(Vector<char>& data, const char* value) {
	for (int i = 0; value[i] != '\0'; i++) data.push_back(value[i]);
	return data;
}
template<typename T>
Vector<T>& operator<<(Vector<T>& data, T value) {
	data.push_back(value);
	return data;
}
template<typename U>
Vector<U>& operator<<(U& putValue, Vector<U>& data) {
	if (data.eleNum) {
		putValue = data.base[0];
		data.erase(data.base);
	}
	return data;
}
template<typename U>
std::ostream& operator<<(std::ostream& outo, const Vector<U>& data) {
	for (int i = 0; i < data.eleNum; i++) {
		outo << data.base[i];
		if (i < data.eleNum - 1) outo << ' ';
	}
	return outo;
}

#endif
