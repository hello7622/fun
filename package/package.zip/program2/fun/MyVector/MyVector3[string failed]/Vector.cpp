#include "Vector.h"

template<typename T>
Vector<T>::Vector()
	: base(new T[10]), temp(nullptr),
	  eleNum(0), maxNum(10) {
	base[eleNum] = 0;
}
template<typename T>
Vector<T>::Vector(std::initializer_list<T> values)
	: base(new T[10]), temp(nullptr),
	  eleNum(0), maxNum(10) {
	for (auto& value : values) {
		base[eleNum++] = value;
		if (eleNum + 2 >= maxNum) {
			maxNum = eleNum * 2;
			temp = new T[maxNum];
			for (int i = 0; i < eleNum; i++) temp[i] = base[i];
			delete[] base;
			base = temp;
			temp = nullptr;
		}
	}
	base[eleNum] = 0;
}
template<typename T>
Vector<T>::Vector(const Vector<T>& other)
	: base(new T[other.size()]), temp(nullptr),
	  eleNum(other.size()), maxNum(other.size() + 4) {
	for (int i = 0; i < eleNum; i++) base[i] = other[i];
}
template<typename T>
Vector<T>::~Vector() {
	if (base) delete[] base;
	if (temp) delete[] temp;
	eleNum = maxNum = 0;
}
template<typename T>
void Vector<T>::Trans() {
	maxNum = eleNum * 2;
	temp = new T[maxNum];
	for (int i = 0; i < eleNum; i++) temp[i] = base[i];
	delete[] base;
	base = temp;
	temp = nullptr;
}

template<typename T>
Vector<T>&& Vector<T>::operator=(const Vector<T>& other) {
	if (base && (other.size() + 1 + 2 >= maxNum)) {
		delete[] base;
		base = nullptr;
	}
	if (!base) {
		maxNum = other.size() + 4;
		base = new T[maxNum];
	}
	eleNum = other.size();
	for (int i = 0; i < eleNum; i++) base[i] = other[i];
	base[eleNum] = 0;
	if (eleNum + 2 + 1 < maxNum / 2)	{
		maxNum >>= 2;
		delete[] (base + maxNum);
	}
	return* this;
}

template<typename T>
T& Vector<T>::operator[](int num) const {
	if (num < 0 || num >= eleNum) return base[0];
	return base[num];
}
template<typename T>
size_t Vector<T>::size() const {
	return eleNum;
}
template<typename T>
size_t Vector<T>::length() const {
	return eleNum;
}
template<typename T>
T Vector<T>::front() const {
	return base[0];
}
template<typename T>
T Vector<T>::back() const {
	if (eleNum) return base[eleNum - 1];
	return base[0];
}
template<typename T>
T* Vector<T>::begin() const {
	return base;
}
template<typename T>
T* Vector<T>::end() const {
	return (base + eleNum);
}

template<typename T>
T& Vector<T>::operator[](int num) {
	if (num < 0 || num >= eleNum) return base[0];
	return base[num];
}
template<typename T>
size_t Vector<T>::size() {
	return eleNum;
}
template<typename T>
size_t Vector<T>::length() {
	return eleNum;
}
template<typename T>
T Vector<T>::front() {
	return base[0];
}
template<typename T>
T Vector<T>::back() {
	if (eleNum) return base[eleNum - 1];
	return base[0];
}
template<typename T>
T* Vector<T>::begin() {
	return base;
}
template<typename T>
T* Vector<T>::end() {
	return (base + eleNum);
}

template<typename T>
void Vector<T>::insert(T* position, T value) {
	if (eleNum + 1 + 2 >= maxNum) Trans();
	if (position < base) position = base;
	else if (position > (base + eleNum)) position = base + eleNum;
	for (T* p = base + eleNum; p > position; p--) *p = *(p - 1);
	*position = value;
	++eleNum;
	base[eleNum] = 0;
}
template<typename T>
void Vector<T>::erase(T* position) {
	if(eleNum <= 0) return ;
	if (position < base) position = base;
	else if (position > (base + eleNum)) position = base + eleNum;
	for (T* p = position; p < base + eleNum; p++) *p = *(p + 1);
	--eleNum;
	base[eleNum] = 0;
	if (eleNum + 2 + 1 < maxNum / 2) {
		maxNum >>= 2;
		delete[] (base + maxNum);
	}
}
template<typename T>
void Vector<T>::push_back(T value) {
	base[eleNum] = value;
	++eleNum;
	if (eleNum + 1 + 2 >= maxNum) Trans();
	base[eleNum] = 0;
}
template<typename T>
void Vector<T>::pop_back(T& putValue) {
	 if(eleNum <= 0) {
	 	putValue = 0;
	 	return ;
	 }
	putValue = base[eleNum - 1];
	base[eleNum - 1] = base[eleNum];
	--eleNum;
	if (eleNum + 2 + 1 < maxNum / 2) {
		maxNum >>= 2;
		delete[] (base + maxNum);
	}
}
