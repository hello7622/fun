#include "MyIntVector.h"

template<typename T>
MyVector<T>::MyVector()
    : head(nullptr), tail(nullptr), count(0), r(std::numeric_limits<T>::max()) 
{}

template<typename T>
MyVector<T>::MyVector(const std::initializer_list<T>& values)
    : head(nullptr), tail(nullptr), count(0), r(0)
{
	for(const auto& value : values)
	{
		++count;
		LinkNode<T>* p = new LinkNode<T>(value);
		if(head == nullptr)
		{
			head = p;
			tail = head;
			continue;
		}
		tail->next = p;
		p->last = tail;
		tail = p;
	}
}

template<typename T>
MyVector<T>::~MyVector()
{
	LinkNode<T>* temp;
	while(head)
	{
		temp = head->next;
		delete head;
		--count;
		head = temp;
	}
}

// �� 
template<typename T>
void MyVector<T>::push_front(const T value)
{
	++count;
	LinkNode<T>* p = new LinkNode<T>(value);
	if(head == nullptr)
	{
		head = p;
		tail = head;
		return ;
	}
	p->next = head;
	head->last = p;
	head = p;
}

template<typename T>
void MyVector<T>::push_back(const T value)
{
	++count;
	LinkNode<T>* p = new LinkNode<T>(value);
	if(head == nullptr)
	{
		head = p;
		tail = head;
		return ;
	}
	tail->next = p;
	p->last = tail;
	tail = p;
}

template<typename T>
void MyVector<T>::insert(const LinkNode<T>* link,const T value)
{
	++count;
	LinkNode<T>* p = new LinkNode<T>(value);
	LinkNode<T>* temp = head;
	for(;temp && temp != link;temp = temp + 1);
	if(!temp)
	{
		tail->next = p;
		p->last = tail;
		tail = p;
		return ;		
	}
	p->next = temp;
	p->last = temp->last;
	temp->last->next = p;
	temp->last = p;
}

// ɾ
template<typename T>
void MyVector<T>::pop_front()
{
	--count;
	LinkNode<T>* temp = head;
	head = head->next;
	head->last = nullptr;
	delete temp;
}

template<typename T>
void MyVector<T>::pop_back()
{
	--count;
	LinkNode<T>* temp = tail;
	tail = tail->last;
	tail->next = nullptr;
	delete temp;
}

template<typename T>
void MyVector<T>::erase(const LinkNode<T>* link)
{
	--count;
	LinkNode<T>* temp = nullptr;
	if(!link)
	{
		temp = tail;
		tail = tail->last;
		tail->next = nullptr;
		delete temp;
		return ;
	}
	for(temp = head;temp && temp != link;temp = temp + 1);
	if(!temp || temp->data == std::numeric_limits<T>::max())
	{
		++count;
		return ;		
	}
	if(temp == head)
	{
		head = temp->next;
		head->last = nullptr;
		delete temp;
		return ;
	}
	temp->next->last = temp->last;
	temp->last->next = temp->next;
	delete temp;
}

// �� 
template<typename T>
LinkNode<T>* MyVector<T>::begin()
{
	return head;
}

template<typename T>
LinkNode<T>* MyVector<T>::end()
{
	return tail->next;
}

template<typename T>
T& MyVector<T>::front()
{
	return head->data;
}

template<typename T>
T& MyVector<T>::back()
{
	return tail->data;
}

template<typename T>
int MyVector<T>::size()
{
	return count;
}

// ���� 
template<typename T>
T& MyVector<T>::operator[](int num)
{
	if(num >= count || num < 0)
	{
		return r;
	}
	LinkNode<T>* p;
	for(p = head;num > 0;p = p->next,num--);
	return p->data;
}

template<typename T>
std::ostream& operator<<(std::ostream& outo,const T& data)
{
	outo << data;
	return outo;
}
