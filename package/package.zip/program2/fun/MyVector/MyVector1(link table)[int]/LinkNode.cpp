#include<limits>
#include "LinkNode.h"

template<typename T>
LinkNode<T>::LinkNode(T da)
    : data(da), last(nullptr), next(nullptr)
{}

// ǰ���Լ� 
template<typename T>
LinkNode<T>* LinkNode<T>::operator++()
{
	return this;
}

// �����Լ� 
template<typename T>
LinkNode<T>* LinkNode<T>::operator++(int )
{
	return this;
}

// ǰ���Լ� 
template<typename T>
LinkNode<T>* LinkNode<T>::operator--()
{
	return last;
}

// �����Լ� 
template<typename T>
LinkNode<T>* LinkNode<T>::operator--(int )
{
	return this;
}

template<typename T>
LinkNode<T>* LinkNode<T>::operator+(int num)
{
	if(num <= 0)
	{
		return this;
	}
	
	LinkNode<T>* p = this;
	for(;num > 0;num--)
	{
		p = p->next;
		if(!p)
		{
			return new LinkNode<T>(std::numeric_limits<T>::max());
		}
	}
	return p;
}

template<typename T>
LinkNode<T>* LinkNode<T>::operator-(int num)
{
	if(num <= 0)
	{
		return this;
	}
	
	LinkNode<T>* p = this;
	for(;num > 0;num--)
	{
		p = p->last;
		if(!p)
		{
			return new LinkNode<T>(std::numeric_limits<T>::max());
		}
	}
	return p;
}
