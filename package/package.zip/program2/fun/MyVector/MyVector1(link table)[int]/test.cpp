#include"MyIntVector.h"
#include"MyIntVector.cpp"
using namespace std;

int main(void)
{
	MyVector<long long> a;
	for(int i = 0;i < 100;i++)
	{
		a.push_back(i);
	}
	for(int i = 0;i < a.size();i++)
	{
		cout << a[i];
	}
	cout << endl;
	cout << a.front() << a.back() << endl;
	a.pop_back();
	a.erase(a.begin());
	a.insert(*(a.begin()) + 50,10);
	for(int i = 0;i < a.size();i++)
	{
		cout << a[i];
	}
	cout << endl;
	return 0;
}
