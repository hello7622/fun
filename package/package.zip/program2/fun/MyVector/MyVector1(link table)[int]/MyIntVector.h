#ifndef MYVECTOR_H
#define MYVECTOR_H

#include<iostream>
#include"LinkNode.h"
#include"LinkNode.cpp"

template<typename T>
class MyVector
{
	private:
		LinkNode<T>* head;
		LinkNode<T>* tail;
		int count;
		T r;
	public:
		MyVector();	
		MyVector(const std::initializer_list<T>& values);
		~MyVector();
		// �� 
		void push_front(const T data);
		void push_back(const T value);
		void insert(const LinkNode<T>* link,const T value);
		// ɾ
		void pop_front();
		void pop_back();
		void erase(const LinkNode<T>* link);
		// �� 
		LinkNode<T>* begin();
		LinkNode<T>* end();
		T& front();
		T& back();
		int size();
		// ����
		T& operator[](int num); 
};


#endif
