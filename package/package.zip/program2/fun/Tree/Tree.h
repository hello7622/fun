#ifndef __FUN_TREE_H__
#define __FUN_TREE_H__

#include <map>
#include <set>

template <typename K, typename V>
class Tree {
public:
    Tree();
    Tree(Tree&& other);
    Tree& operator=(Tree&& other);
    Tree(const Tree&) = delete;
    Tree& operator=(const Tree&) = delete;
    virtual ~Tree();
    Tree copy() const;
    bool push(const K& key, const V& val);
    bool push(const K& key, const V& val, const K& father);
    bool SetFather(const K& key);
    bool SetFather(const K& key, const K& father);
    bool pop(const K& key, V& val);
    bool find(const K& key, V& val) const;
    bool modify(const K& key, const V& val);
protected:
    K ModifyMapAdd(const K& key, const V& val, const K& father);
    V ModifyMapDel(const K& key);
private:
    std::map<K, std::set<K>> children;
    std::map<K, K> fathers;
    std::map<K, V> values;
    K root;
};

#endif // __FUN_TREE_H__

template <typename K, typename V>
inline Tree<K, V>::Tree(): root() {
    children[root] = std::set<K>();
}

template <typename K, typename V>
inline Tree<K, V>::Tree(Tree &&other) {
    root = other.root;
    children = other.children;
    fathers = other.fathers;
    values = other.values;
}

template <typename K, typename V>
inline Tree<K, V> &Tree<K, V>::operator=(Tree &&other) {
    root = other.root;
    children = other.children;
    fathers = other.fathers;
    values = other.values;
    return *this;
}

template <typename K, typename V>
inline Tree<K, V>::~Tree() {
    
}

template <typename K, typename V>
inline Tree<K, V> Tree<K, V>::copy() const
{
    Tree<K, V> tree;
    tree.root = root;
    tree.children = children;
    tree.fathers = fathers;
    tree.values = values;
    return tree;
}

template <typename K, typename V>
inline bool Tree<K, V>::push(const K& key, const V& val) {
    ModifyMapAdd(key, val, root);
    return true;
}

template <typename K, typename V>
inline bool Tree<K, V>::push(const K& key, const V& val, const K& father) {
    ModifyMapAdd(key, val, father);
    return true;
}

template <typename K, typename V>
inline bool Tree<K, V>::SetFather(const K& key) {
    if (fathers.find(key) != fathers.end()) {
        return false;
    }
    ModifyMapAdd(key, values.at(key), root);
    return true;
}

template <typename K, typename V>
inline bool Tree<K, V>::SetFather(const K& key, const K& father) {
    if (fathers.find(key) != fathers.end()) {
        return false;
    }
    if (fathers.find(father) == fathers.end()) {
        return false;
    }
    ModifyMapAdd(key, values.at(key), father);
    return true;
}

template <typename K, typename V>
inline bool Tree<K, V>::pop(const K& key, V& val) {
    // 非叶子节点不能删除
    if (children.find(key) != children.end()) {
        val = values.at(key);
        return false;
    }
    val = ModifyMapDel(key);
    return true;
}

template <typename K, typename V>
inline bool Tree<K, V>::find(const K& key, V& val) const {
    if (values.find(key) == values.end()) {
        return false;
    }
    val = values.at(key);
    return true;
}

template <typename K, typename V>
inline bool Tree<K, V>::modify(const K& key, const V& val) {
    if (values.find(key) == values.end()) {
        return false;
    }
    values[key] = val;
    return true;
}

template <typename K, typename V>
inline K Tree<K, V>::ModifyMapAdd(const K &key, const V &val, const K &father) {
    // 修改子表-1
    children[father].insert(key);
    // 修改父表-1
    fathers[key] = father;
    // 修改值表-1
    values[key] = val;
    return key;
}

template <typename K, typename V>
inline V Tree<K, V>::ModifyMapDel(const K &key) {
    // 修改子表-0
    children[fathers[key]].erase(key);
    // 修改父表-0
    fathers.erase(key);
    // 修改值表-0
    V val = values[key];
    values.erase(key);
    return val;
}
