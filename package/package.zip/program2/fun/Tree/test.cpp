#include <iostream>
#include <string>
#include "Tree.h"
using namespace std;

int main() {
    Tree<string, int> tree;
    cout << tree.push("1", 1)
         << tree.push("2", 2, "1")
         << tree.push("3", 3)
         << tree.push("4", 4, "2")
         << tree.push("5", 5, "2")
         << tree.push("6", 6, "3");
    tree.SetFather("5", "3");
    int val;
    cout << endl << tree.find("3", val) << val << endl;
    Tree<string, int> tree2 = tree.copy();
    cout << tree2.find("3", val) << val << endl;
    cout << tree2.copy().find("3", val) << val << endl;
}