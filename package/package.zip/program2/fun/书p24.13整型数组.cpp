#include<iostream>
using namespace std;

const int MAX_SIZE = 36;

bool CreateArray(int* begin,int* end)
{
	int* p = begin;
	for(;p < end;p++)
	{
		*p = p - begin;
	}
	return true;
}

bool Exchange(int* begin,int* end,int p)
{
	int *p1 = begin,*p2 = begin + p;
	for(;p2 < end;p1++,p2++)
	{
		swap(*p1,*p2);
	}
	return true;
}

bool Output(int* begin,int* end)
{
	for(int* p = begin;p < end;p++)
	{
		cout << *p << ' ';
	}
	cout << endl;
	return true;
}

int main(void)
{
	int a[MAX_SIZE] = {0};
	CreateArray(a,a + MAX_SIZE);
	Output(a,a + MAX_SIZE);
	cout << endl;
	for(int i = 0;i < MAX_SIZE;i++)
	{
		CreateArray(a,a + MAX_SIZE);
	    Exchange(a,a + MAX_SIZE,i);
	    Output(a,a + MAX_SIZE);		
	}
	return 0;
}
