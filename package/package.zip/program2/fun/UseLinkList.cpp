#include <iostream>
#include "LinkList.h"
#include "LinkList.cpp"	// 若会自动链接，则无需此行 

template<typename T>
std::ostream& operator<<(std::ostream& outo, const LinkList<T>& data) {
	for (const T& val : data) {
		outo << val;
	}
	return outo;
}
LinkList<int> range(int begin, int end, int step = 1) {
	LinkList<int> ans;
	for (int i = begin; i < end; i += step) {
		ans.append(i);
	}
	return ans;
}

using namespace std;
int main() {
	LinkList<int> l{1, 2, 3};
	l += {4, 5, 6};
	cout << range(0, 10);
	return 0;
}
