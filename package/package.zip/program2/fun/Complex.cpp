class Complex {
	public:
		Complex(const double& _real = 0, const double& _imag = 0);
		Complex(const char * _complex);
		Complex(const Complex& _complex);
		Complex& operator=(const Complex& _complex);
		Complex& operator=(const double& _real);
		double Real() const;
		double Imag() const;
		void SetReal(const double& _real);
		void SetImag(const double& _imag);
		Complex operator+(const Complex& _complex) const;
		Complex& operator+=(const Complex& _complex);
		Complex operator-(const Complex& _complex) const;
		Complex& operator-=(const Complex& _complex);
		Complex operator*(const Complex& _complex) const;
		Complex& operator*=(const Complex& _complex);
		Complex operator/(const Complex& _complex) const;
		Complex& operator/=(const Complex& _complex);
		Complex operator+(const double& _real) const;
		Complex& operator+=(const double& _real);
		Complex operator-(const double& _real) const;
		Complex& operator-=(const double& _real);
		Complex operator*(const double& _real) const;
		Complex& operator*=(const double& _real);
		Complex operator/(const double& _real) const;
		Complex& operator/=(const double& _real);
		Complex operator^(const int& _pow) const;
		Complex& operator^=(const int& _pow);
	
		static double round(double num, int bit = 3);
	private:
		double real, imag;
};

Complex::Complex(const double& _real, const double& _imag)
	: real(_real)
	, imag(_imag) {

}
Complex::Complex(const char * _complex)
	: real(0)
	, imag(0) {
	int i = 0, op = 1, cur = 0;
	double tmp;
	double ans[2] = {0, 0};
	while (_complex[i] && cur < 2) {
		for (; _complex[i] == ' '; i++);
		if (_complex[i] == '-') {
			op = -1;
			++i;
		} else if (_complex[i] == '+') {
			op = 1;
			++i;
		}
		for (; _complex[i] == ' '; i++);
		for (; '0' <= _complex[i] && _complex[i] <= '9'; i++) {
			ans[cur] = ans[cur] * 10 + (_complex[i] - '0');
		}
		if (_complex[i] == '.') {
			++i;
			tmp = 10;
			for (; '0' <= _complex[i] && _complex[i] <= '9'; i++, tmp *= 10) {
				ans[cur] += (_complex[i] - '0') / tmp;
			}
		}
		for (; _complex[i] == ' '; i++);
		if (_complex[i] == 'i') {
			if (ans[cur] == 0) {
				ans[cur] = 1;
			}
			if (cur == 0) {
				ans[1] = ans[0] * op;
				ans[0] = 0;
				break;
			}
		}
		ans[cur] *= op;
		++cur;
	}
	real = ans[0];
	imag = ans[1];
}

Complex::Complex(const Complex& _complex)
	: real(_complex.Real())
	, imag(_complex.Imag()) {

}

Complex& Complex::operator=(const Complex& _complex) {
	real = _complex.Real();
	imag = _complex.Imag();
	return *this;
}

Complex& Complex::operator=(const double& _real) {
	real = _real;
	imag = 0;
	return *this;
}

double Complex::Real() const {
	return real;
}

double Complex::Imag() const {
	return imag;
}

void Complex::SetReal(const double& _real) {
	real = _real;
}

void Complex::SetImag(const double& _imag) {
	imag = _imag;
}

Complex Complex::operator+(const Complex& _complex) const {
	return Complex(real + _complex.Real(), imag + _complex.Imag());
}

Complex& Complex::operator+=(const Complex& _complex) {
	real += _complex.Real();
	imag += _complex.Imag();
	return *this;
}

Complex Complex::operator-(const Complex& _complex) const {
	return Complex(real - _complex.Real(), imag - _complex.Imag());
}

Complex& Complex::operator-=(const Complex& _complex) {
	real -= _complex.Real();
	imag -= _complex.Imag();
	return *this;
}

Complex Complex::operator*(const Complex& _complex) const {
	const double &a = real, &b = imag, &c = _complex.Real(), &d = _complex.Imag();
	return Complex(a * c - b * d, b * c + a * d);
}

Complex& Complex::operator*=(const Complex& _complex) {
	double a = real, b = imag, c = _complex.Real(), d = _complex.Imag();
	real = a * c - b * d;
	imag = b * c + a * d;
	return *this;
}

Complex Complex::operator/(const Complex& _complex) const {
	const double &a = real, &b = imag, &c = _complex.Real(), &d = _complex.Imag();
	return Complex(a * c + b * d, b * c - a * d) / (c * c + d * d);
}

Complex& Complex::operator/=(const Complex& _complex) {
	double a = real, b = imag, c = _complex.Real(), d = _complex.Imag();
	double tmp = c * c + d * d;
	real = a * c + b * d;
	real /= tmp;
	imag = b * c - a * d;
	imag /= tmp;
	return *this;
}

Complex Complex::operator+(const double& _real) const {
	return Complex(real + _real, imag);
}

Complex& Complex::operator+=(const double& _real) {
	real += _real;
	return *this;
}

Complex Complex::operator-(const double& _real) const {
	return Complex(real - _real, imag);
}

Complex& Complex::operator-=(const double& _real) {
	real -= _real;
	return *this;
}

Complex Complex::operator*(const double& _real) const {
	return Complex(real * _real, imag * _real);
}

Complex& Complex::operator*=(const double& _real) {
	real *= _real;
	imag *= _real;
	return *this;
}

Complex Complex::operator/(const double& _real) const {
	return Complex(real / _real, imag / _real);
}

Complex& Complex::operator/=(const double& _real) {
	real /= _real;
	imag /= _real;
	return *this;
}

Complex Complex::operator^(const int& _pow) const {
	if (_pow == 0) {
		return 1;
	}
	Complex base(*this);
	double pow = _pow;
	if (pow < 0) {
		base = Complex(1) / base;
		pow *= -1;
	}
	Complex ans(base);
	while ((--pow) > 0) {
		ans *= base;
	}
	return ans;
}

Complex& Complex::operator^=(const int& _pow) {
	if (real == 0 && imag == 0) {
		return *this;
	}
	if (_pow == 0) {
		real = 1;
		imag = 0;
		return *this;
	}
	Complex base(*this);
	double pow = _pow;
	if (pow < 0) {
		base = Complex(1) / base;
		pow *= -1;
	}
	while ((--pow) > 0) {
		operator*=(base);
	}
	return *this;
}

double Complex::round(double num, int bit) {
	int base = 1;
	while ((bit--) > 0) {
		base *= 10;
	}
	int tmp = int(num * base) % base, off = int(num * base * 10) % 10;
	if (off >= 5) {
		tmp += 1;
	}
	return int(num) + double(tmp) / base;
}

#include <iostream>
#include <string>
std::ostream& operator<<(std::ostream& outo, const Complex& complex) {
	double a = Complex::round(complex.Real(), 2), b = Complex::round(complex.Imag(), 2);
//	double a = complex.Real(), b = complex.Imag();
	if (b == 0) {
		outo << a;
		return outo;
	}
	if (a == 0) {
		if (b == 1) {
			outo << "i";
		} else if (b == -1) {
			outo << "-i";
		} else {
			outo << b << "i";
		}
		return outo;
	}
	outo << a;
	if (b > 0) {
		outo << "+";
	}
	if (b == 1) {
		outo << "i";
	} else if (b == -1) {
		outo << "-i";
	} else {
		outo << b << "i";
	}
	return outo;
}
using namespace std;
int main() {
	Complex x("1 + 1.732i"), y("1.732 + i");
	cout << x << endl << y << endl << (x * y);
	return 0;
}
