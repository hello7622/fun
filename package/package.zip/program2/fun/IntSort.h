#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;

const int MAX_SIZE = 100;

// ����Ƿ�����
bool Test(int* begin,int* end)
{
	for(int* p = begin;p < end - 1;p++)
	{
		if(*p > *(p + 1))
		{
			return false;
		}
	}
	return true;
} 

// �����ظ�
int DeleteRepet(int* begin,int* end)
{
	int count = 0;
	for(int* p1 = begin;p1 <= end - 1 - count;p1++)
	{
		for(int* p2 = p1 + 1;p2 <= end - count;p2++)
		{
			if(*p2 == *p1)
			{
				++count;
				for(int* p3 = p2;p3 <= end - count;p3++)
				{
					*p3 = *(p3 + 1);
				}
				--p2;
			}
		}
	}
	return count;
} 

// endһ��Ϊ��ָ����end = begin + length 
// ����Ĭ��Ϊ����
// ѡ������ 
bool Sort1(int* begin,int* end)
{
	for(int* p1 = begin;p1 < end - 1;p1++)
	{
		int* temp = p1;
		for(int* p2 = p1 + 1;p2 < end;p2++)
		{
			if(*p2 < *temp)
			{
				temp = p2;
			}
			if(p1 > begin && *temp - *(p1 - 1) <= 1)
			{
	  		    break;
			}			
		}
		if(temp != p1)
		{
			swap(*temp,*p1);
		}
	}
	return true;
}
// ��������
bool Sort1Insert(int* begin,int* end)
{
	int *p = begin + 1,*temp1 = begin,*temp2 = temp1,temp = *p;
	while(p < end)
	{
		for(temp1 = begin;*temp1 < *p;temp1++);			// ��������Ϊ*temp1 >= *p���������Ϊtemp1 == p 
		for(temp2 = p,temp = *p;temp2 > temp1;temp2--)
		{
			*temp2 = *(temp2 - 1);
		} 
		*temp1 = temp;
		++p;
	}
	return true;
} 
// ˫ð������
bool Sort2(int* begin,int* end)
{
	int *p1 = begin,*p2 = --end;
	for(;p1 <= p2;p1++,p2--)
	{
		int* p = p1;
		while(p <= p2)
		{
			if(*p1 > *p)
			{
				swap(*p,*p1);
			}
			if(*p2 < *p)
			{
				swap(*p,*p2);
			}
			p++;
		}
	}
	return true;
} 
// ��������
bool Sort3(int* begin,int* end)
{
	if(end - begin <= 1)
	{
		return true;
	}
	int *p1 = begin,*p2 = end - 1;
	while(p1 < p2)
	{
		while(*p1 <= *p2 && p1 < p2)
		{
			++p1;
		}
		swap(*p1,*p2);
		while(*p1 <= *p2 && p1 < p2)
		{
			--p2;
		}
		swap(*p1,*p2);
	}
	Sort3(begin,p2);
	Sort3(p1,end);
	return true;
} 
// �������� ���ѡȡkeyֵ 
bool Sort3Rand(int* begin,int* end)
{
	srand(time(NULL));
	if(end - begin <= 1)
	{
		return true;
	}
	int *p1 = begin,*p2 = end - 1;
	int *key = begin + rand() % (end - begin);
	while(p1 < p2)
	{
		while(*p1 <= *key && p1 < p2)
		{
			++p1;
		}
		swap(*p1,*key);
		key = p1;
		while(*p2 >= *key && p1 < p2)
		{
			--p2;
		}
		swap(*key,*p2);
		key = p2;
	}
	Sort3(begin,key);
	Sort3(key + 1,end);
	return true;
} 
// �鲢����
// �ϲ�����
bool Merge(int* begin,int* mid,int* end)
{
    int *array = new int[end - begin + 1]{0},*temp = array;
    int *p1 = begin,*p2 = mid;
    while(p1 < mid && p2 < end)
    {
		*temp = (*p1 < *p2) ? *(p1++) : *(p2++);
		++temp;
	}
	while(p1 < mid || p2 < end)
	{
		*temp = (p1 < mid) ? *(p1++) : *(p2++);
		++temp;
	}
	for(int* p = begin;p < end;p++)
	{
		*p = array[p - begin];
	}
	delete array;
	return true;	
} 
bool Sort4(int* begin,int* end)
{
// �ݹ���ֹ 
	if(end - begin <= 1)
	{
		return true;
	}
// �ֿ�		
	int* mid = begin + (end - begin) / 2;
	Sort4(begin,mid);
	Sort4(mid,end);
// �ϲ�
    Merge(begin,mid,end);
	return true;
} 
// �����������ڴ��ģ�������򣬸о���û����ȫ�㶮
// ���������
void adjustHeap(int arr[], int i, int len) 
{
    int temp = arr[i];
    for (int k = 2 * i + 1; k < len; k = 2 * k + 1) 
	{
        if (k + 1 < len && arr[k] < arr[k + 1]) 
		{
            k++;
        }
        if (arr[k] > temp) 
		{
            arr[i] = arr[k];
            i = k;
        } 
		else 
		{
            break;
        }
    }
    arr[i] = temp;
}
bool Sort5(int* begin,int* end)
{
	int len = end - begin;
// ���������
    for (int i = len / 2 - 1; i >= 0; i--) 
	{
        adjustHeap(begin, i, len);
    }	
// ����
    for (int i = len - 1; i > 0; i--) 
	{
        swap(begin[0], begin[i]);
        adjustHeap(begin, 0, i);
    }    
    return true;
} 
// �������� ����
bool Sort6(int* begin,int* end,int max)
{
	int* counter = new int[max]{0};
	for(int* p = begin;p < end;p++)
	{
		++counter[*p];
	}
	int* p = begin;
	for(int i = 0;i < max && p < end;i++)
	{
		while(counter[i] > 0)
		{
			*p = i;
			--counter[i];
			++p;	
		}
	}
	return true;
} 
