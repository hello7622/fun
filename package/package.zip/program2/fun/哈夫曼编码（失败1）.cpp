#include<iostream>
#include<queue>
using namespace std;

struct Node {
	char letter;
	int data;
	Node *left, *right;
	Node *lchild, *rchild;
	Node(): letter(0), data(0), left(nullptr), right(nullptr), lchild(nullptr), rchild(nullptr) {}
	Node(char ch, int da): letter(ch), data(da), left(nullptr), right(nullptr), lchild(nullptr), rchild(nullptr) {}
	Node(char ch, int da, Node* l, Node* r): letter(ch), data(da), left(l), right(r), lchild(nullptr), rchild(nullptr) {}
	Node(char ch, int da, Node* l1, Node* r1, Node* l2, Node* r2): letter(ch), data(da), left(l1), right(r1), lchild(l2), rchild(r2) {}
	Node(Node& other): letter(other.letter), data(other.data), left(other.left), right(other.right), lchild(other.lchild), rchild(other.rchild) {}
	Node& operator=(Node& other) {
		if (this == &other) return* this;
		letter = other.letter;
		data = other.data;
		left = other.left;
		right = other.right;
		lchild = other.lchild;
		rchild = other.rchild;
		return* this;
	}
};
class Array {
		Node* head;
		int length;
	public:
		Array(): head(new Node), length(0) {}
		bool push(Node* other) {		// �������
			Node* pNode = head;
			for (; pNode->right && pNode->right->data < other->data; pNode++);
			other->left = pNode;
			other->right = pNode->right;
			if(pNode->right) pNode->right->left = other;
			pNode->right = other;
			++length;
			return true;
		}
		Node* pop() {					// ����������Ԫ��
			if (!head->right) return nullptr;
			Node* p = head->right;
			head->right = p->right;
			if (p->right) p->right->left = head;
			--length;
			return p;
		}
		bool empty() {
			return !length;
		}
		~Array() {
			Node* p = nullptr;
			while (head->right) {
				p = head->right;
				head->right = p->right;
				delete p;
				--length;
			}
			delete head;
		}
};
class Tree {
	public:
		Node* Create(Array& other) {			// �Ը������鹹����������
			Node *p1 = nullptr, *p2 = nullptr, *temp = nullptr;
			while (!other.empty()) {
				p1 = other.pop();
				p2 = other.pop();
				if (p1 && p2) {
					temp = create(p1, p2);
					other.push(temp);
				}
			}
			return temp;
		}
	protected:
		Node* create(Node* p1, Node* p2) {		// ������ָ��Ȩֵ����һ��С��
			Node* left = (p1->data < p2->data) ? p1 : p2;
			Node* right = (p1->data < p2->data) ? p2 : p1;
			Node* p = new Node(0, p1->data + p2->data, nullptr, nullptr, left, right);
			return p;
		}
};
class Code {
	public:
		char** Coder(char* str) {				// �������ַ���ת���ɶ�Ӧ�ı��������str���е��ַ��ⲻ�������
  		    Array array = TransLetter(CountLetter(str));
			Tree tree;
			char** p = TransTree(tree.Create(array));
			
			return p;
		}
		bool Output(char* str, char** table) {	// �������ַ������ձ������
			for (char* p = str; *p; cout << table[int(*(p++))]);
			return true;
		}
		char* ReCoder(char ch, char** table) {	// ���ָ���ַ��ı���
			return table[int(ch)];
		}
	protected:
		int* CountLetter(char* str) {			// ͳ���ַ�������ĸ��
			int* letter = new int[128] {0};
			for (char* p = str; *p; ++letter[int(*(p++))]);
			return letter;
		}
		Array& TransLetter(int* table) {		// ����֪Ƶ�ε���ĸ��ת��ΪȨֵ����
			Array* array = new Array;
			for (int i = 0; i < 128; i++) {
				if (table[i] > 0) {
					Node* p = new Node(i, table[i]);
					array->push(p);
				}
			}
			return *array;
		}
		char** TransTree(Node* head) {			// ��������������ת���ɱ����������û�е��ַ����������
			
			char** p = new char*[128];
			for (int i = 0; i < 128; p[i++] = new char[50]);
			int count = 0;
			char code[50] = {0};
			queue<Node*> temp;
			Node *pHead = head, *ptr = nullptr;
			temp.push(pHead);
			
			while (!temp.empty() || pHead) {
				ptr = pHead;
				pHead = temp.front();
				code[count++] = (pHead == ptr->lchild) ? '0' : '1';
				temp.pop();
				temp.push(pHead->lchild);
				temp.push(pHead->rchild);
				if (pHead->letter) p[int(pHead->letter)] = code;
			}
			
			return p;
		}
};

int main(void) {
	Code code;
	char** table = nullptr;
	char str[50] = {0};
	cout << "�����ַ�����";
	cin >> str;
	table = code.Coder(str);
	
	code.Output(str, table);
	return 0;
}
